package com.lu.mobileacore.observer;

/**
 * Created by huangyinhuang on 16/6/3.
 */

public interface IAssertObservable {

    void addObserver(IAssertObserver observer);
    void deleteObserver(IAssertObserver observer);
    void notifyObservers(String message);

}
