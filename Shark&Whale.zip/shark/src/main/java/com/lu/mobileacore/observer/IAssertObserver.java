package com.lu.mobileacore.observer;

/**
 * Created by huangyinhuang on 16/6/3.
 */

public interface IAssertObserver {

    void onAssert(String message);

}
