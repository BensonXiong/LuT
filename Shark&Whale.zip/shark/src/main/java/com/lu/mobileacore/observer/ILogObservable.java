package com.lu.mobileacore.observer;

/**
 * Created by huangyinhuang on 16/6/12.
 */
public interface ILogObservable {

    void addObserver(ILogObserver observer);
    void deleteObserver(ILogObserver observer);
    void notifyObservers(String message);

}
