package com.lu.mobileacore.observer;

/**
 * Created by huangyinhuang on 16/6/12.
 */
public interface ILogObserver {

    void onLog(String message);

}
