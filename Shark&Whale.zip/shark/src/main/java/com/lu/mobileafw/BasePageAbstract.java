package com.lu.mobileafw;

import com.lu.mobileafw.app.LuDriverHelper;
import com.lu.mobileafw.assertion.LuAssert;
import com.lu.mobileafw.be.ILuTestBeEnv;
import com.lu.mobileafw.log.LuLogger;
import io.appium.java_client.AppiumDriver;
import org.apache.log4j.Logger;

/**
 * Created by huangyinhuang on 16/3/16.
 *
 * 基本页面
 *
 */


public abstract class BasePageAbstract {

    protected static AppiumDriver driver;
    protected static LuDriverHelper driverHelper;
    protected static TestConf testConf;
    protected static ILuTestBeEnv testBeEnv;
    protected static LuAssert testAssert;
    protected static LuLogger testLogger;
    protected Logger logger = Logger.getLogger(this.getClass().getName());

    public BasePageAbstract() {
    }

    public static void initDriver(AppiumDriver driver, LuDriverHelper driverHelper) {
        BasePageAbstract.driver = driver;
        BasePageAbstract.driverHelper = driverHelper;
    }

    public static void initAssert(LuAssert testAssert) {
        BasePageAbstract.testAssert = testAssert;
    }

    public static void initEnv(ILuTestBeEnv testBeEnv) {
        BasePageAbstract.testBeEnv = testBeEnv;
    }

    public static void initConf(TestConf testConf) {
        BasePageAbstract.testConf = testConf;
    }

    public static void initLogger(LuLogger testLogger) {
        BasePageAbstract.testLogger = testLogger;
    }

}
