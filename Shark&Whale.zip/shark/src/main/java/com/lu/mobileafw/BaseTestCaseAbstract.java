package com.lu.mobileafw;

import com.lu.mobileacore.observer.IAssertObserver;
import com.lu.mobileacore.observer.ILogObserver;
import com.lu.mobileafw.app.*;
import com.lu.mobileafw.assertion.LuAssert;
import com.lu.mobileafw.be.ILuTestBeEnv;
import com.lu.mobileafw.enumer.AppPlatformType;
import com.lu.mobileafw.enumer.EnvironmentType;
import com.lu.mobileafw.exception.InvalidPlatformException;
import com.lu.mobileafw.listener.LuAssertObserver;
import com.lu.mobileafw.listener.LuLogObserver;
import com.lu.mobileafw.listener.LuTestInfoObserver;
import com.lu.mobileafw.listener.LuTestListener;
import com.lu.mobileafw.log.LuLogger;
import com.lu.mobileafw.report.ShareLog;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.*;

import java.lang.reflect.Method;
import java.net.URL;

/**
 * Created by huangyinhuang on 16/3/14.
 * <p/>
 * 基本测试用例
 */

@ContextConfiguration(locations = {"classpath:mobile.context.xml"})
@Listeners({LuTestListener.class})
public abstract class BaseTestCaseAbstract extends AbstractTestNGSpringContextTests {

    private Logger logger = LoggerFactory.getLogger(BaseTestCaseAbstract.class);

    protected AppiumDriver driver;
    protected LuDriverHelper driverHelper;
    protected TestConf testConf;
    protected LuAssert testAssert;
    protected LuAssertObserver testAssertObserver;
    protected LuLogger testLogger;
    protected LuLogObserver testLoggerObserver;
    protected LuTestInfoObserver testInfoObserver;
    protected LuScreenShooter screenShooter;

    protected ILuTestBeEnv testBeEnv;

    public BaseTestCaseAbstract() {

        logger.debug("construct new objects before testing");

        driverHelper = new LuDriverHelper();
        testAssert = new LuAssert();
        testAssertObserver = new LuAssertObserver();
        testLogger = new LuLogger();
        testLoggerObserver = new LuLogObserver();
        testInfoObserver = new LuTestInfoObserver();
        screenShooter = new LuScreenShooter();

        // attach assert observer
        testAssert.addObserver(testAssertObserver);
        testLogger.addObserver(testLoggerObserver);

        IAssertObserver assertObs = (IAssertObserver) testInfoObserver;
        ILogObserver logObs = (ILogObserver) testInfoObserver;
        testAssert.addObserver(assertObs);
        testLogger.addObserver(logObs);

        // try to scan product list from backend environment
        testBeEnv = getBeEnvironment();
        try {
            testBeEnv.scanProductlist();
        } catch (Exception e) {
            logger.error("failed to scan product list from backend environment.", e);
        }

    }

    public abstract ILuTestBeEnv getBeEnvironment();

    @BeforeSuite
    public void initTestEnv() {
        logger.debug("initTestEnv()");
    }


    @BeforeClass
    @Override
    protected void springTestContextBeforeTestClass() throws Exception {
        logger.debug("springTestContextBeforeTestClass()");
        super.springTestContextBeforeTestClass();
    }

    @BeforeClass
    @Override
    protected void springTestContextPrepareTestInstance() throws Exception {
        logger.debug("springTestContextPrepareTestInstance()");
        super.springTestContextPrepareTestInstance();

        // read the configuration
        logger.debug("context = " + this.applicationContext);
        testConf = (TestConf) this.applicationContext.getBean("mtestconf");
        logger.debug("user name=" + testConf.getUserName());

        // start to initialize driver
        testConf.printConfInfo();

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("appium-version", testConf.appiumVer);
        capabilities.setCapability("unicodeKeyboard", testConf.unicodeKeyboard);
        capabilities.setCapability("resetKeyboard", testConf.resetKeyboard);
        capabilities.setCapability("deviceName", testConf.deviceName);
        capabilities.setCapability("platformName", testConf.devicePlatformName);
        capabilities.setCapability("platformVersion", testConf.devicePlatformVer);
        capabilities.setCapability("app", testConf.appPath);

        URL url = testConf.getURL();
        if (testConf.devicePlatformName.equals("android")) {

            capabilities.setCapability("appPackage", testConf.adAppPackage);
            capabilities.setCapability("appActivity", testConf.adAppActivity);
            driver = new LuAndroidDriver(url, capabilities);

        } else if (testConf.devicePlatformName.equals("ios")) {

            driver = new LuIosDriver(url, capabilities);

        } else {
            logger.error("An error is happend when trying to initialize driver by platform name property");
            throw new InvalidPlatformException("Unrecognized platform name. Please check the active platform is specified correctly.");
        }


        // initialize driver helper
        driverHelper.init(driver);
        TestHelper.init(driver, url);

        // initialize base page
        BasePageAbstract.initDriver(driver, driverHelper);
        BasePageAbstract.initEnv(testBeEnv);
        BasePageAbstract.initAssert(testAssert);
        BasePageAbstract.initConf(testConf);
        BasePageAbstract.initLogger(testLogger);

        // initialize screen shooter
        screenShooter.init(driver);
        LuTestListener.initScreenshot(screenShooter);
        LuAssertObserver.initScreenshot(screenShooter);
        LuLogObserver.initScreenshot(screenShooter);

        // set test info to be shared
        ShareLog.deviceName = testConf.deviceName;
        ShareLog.devicePlatformName = testConf.devicePlatformName;
        ShareLog.devicePlatformVer = testConf.devicePlatformVer;
        ShareLog.appVer = testConf.appVer;
        ShareLog.appPath = testConf.appPath;

    }


    @BeforeMethod
    @Override
    protected void springTestContextBeforeTestMethod(Method testMethod) throws Exception {

        logger.debug("springTestContextBeforeTestMethod()");
        super.springTestContextBeforeTestMethod(testMethod);

        try {

            EnvironmentType envType = testConf.getEnvironmentType();

            /**
             * 如果当前为运维监控（线上）环境，为了避免输入验证码，不重置App
             */
            if (envType != EnvironmentType.OPERATION) {
                logger.debug("reset app before test method");
                driver.resetApp();
            }

            logger.debug("sleep 10 seconds");
            driverHelper.sleep(10000);

        } catch (Exception e) {
            logger.error("failed to reset app before running test case.", e);
        }

    }

    @AfterMethod
    @Override
    protected void springTestContextAfterTestMethod(Method testMethod) throws Exception {
        logger.debug("springTestContextAfterTestMethod()");
        super.springTestContextAfterTestMethod(testMethod);
    }


    @AfterClass
    @Override
    protected void springTestContextAfterTestClass() throws Exception {
        logger.debug("springTestContextAfterTestClass()");
        super.springTestContextAfterTestClass();
    }

    @AfterTest
    public void cleanTestEnv() {

        logger.debug("cleanTestEnv()");
        try {
            //driver.close();
            driver.quit();
        } catch (Exception e) {
            logger.error("failed to clean test environment.", e);
        }

    }


    public AppPlatformType getPlatformType() {

        AppPlatformType type;

        if (driver instanceof LuAndroidDriver){
            type = AppPlatformType.ANDROID;
        }
        else if (driver instanceof LuIosDriver) {
            type = AppPlatformType.IOS;
        }
        else {
            type = AppPlatformType.UNKNOWN;
        }

        return type;
    }

    public String getAppBundleID() {


        String appBundleID = null;

        AppPlatformType type = getPlatformType();
        if (type == AppPlatformType.ANDROID) {
            appBundleID = testConf.adAppPackage;
        } else if (type == AppPlatformType.IOS) {
            //TODO: return app bundle id on ios platform
            appBundleID = null;
        }

        return appBundleID;

    }

    public String getAppPath() {

        return testConf.appPath;

    }

}
