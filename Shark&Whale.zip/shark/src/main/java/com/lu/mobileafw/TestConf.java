package com.lu.mobileafw;

import com.lu.mobileafw.enumer.EnvironmentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by huangyinhuang on 16/4/12.
 *
 * 测试环境配置
 *
 */

@Component
public class TestConf {

    private Logger logger = LoggerFactory.getLogger(TestConf.class);

    // environment
    @Value("${env.type}")
    private String environmentType;

    // appium
    @Value("${appium.version}")
    protected String appiumVer;
    @Value("${appium.url}")
    protected String appiumUrl;
    @Value("${appium.unicodeKeyboard}")
    protected String unicodeKeyboard;
    @Value("${appium.resetKeyboard}")
    protected String resetKeyboard;

    // device
    @Value("${device.name}")
    protected String deviceName;
    @Value("${device.platform.name}")
    protected String devicePlatformName;
    @Value("${device.platform.version}")
    protected String devicePlatformVer;

    // app
    @Value("${app.path}")
    protected String appPath;
    @Value("${app.version}")
    protected String appVer;

    // android properties
    @Value("${android.app.package}")
    protected String adAppPackage;
    @Value("${android.app.activity}")
    protected String adAppActivity;

    // ios properties


    // test properties
    @Value ("${appium.waitTimeout}")
    protected Integer AppiumWaitTimeout;
    @Value ("${user.name}")
    protected String UserName;
    @Value ("${user.invest.name}")
    protected String InvestorUserName;
    @Value ("${user.pwd}")
    protected String UserPwd;
    @Value ("${user.trdpwd}")
    protected String UserTradePwd;

    protected void printConfInfo() {
        logger.info("appiumVer=" + appiumVer);
        logger.info("appiumUrl=" + appiumUrl);
        logger.info("unicodeKeyboard=" + unicodeKeyboard);
        logger.info("resetKeyboard=" + resetKeyboard);
        logger.info("deviceName=" + deviceName);
        logger.info("devicePlatformName=" + devicePlatformName);
        logger.info("devicePlatformVer=" + devicePlatformVer);
        logger.info("appPath=" + appPath);
        logger.info("appVersion=" + appVer);
        logger.info("adAppPackage=" + adAppPackage);
        logger.info("adAppActivity=" + adAppActivity);
    }

    public int getAppiumWaitTimeout() {
        return AppiumWaitTimeout;
    }

    public String getUserName() {
        return UserName;
    }

    public String getInvestorUserName() {
        return InvestorUserName;
    }

    public String getUserPwd() {
        return UserPwd;
    }

    public String getUserTradePwd() {
        return UserTradePwd;
    }

    public String getDevicePlatformName() {return  devicePlatformName;}

    public URL getURL() {
        URL url = null;

        try {
            url = new URL(this.appiumUrl);
        } catch (MalformedURLException e) {
            logger.debug("failed to initialize URL instance", e);
        }

        return url;
    }

    public EnvironmentType getEnvironmentType() {

        if (environmentType.equals("dev")) {
            return EnvironmentType.DEV;
        } else if (environmentType.equals("test")) {
            return EnvironmentType.TEST;
        } else if (environmentType.equals("production")) {
            return EnvironmentType.PRODUCTION;
        } else if (environmentType.equals("operation")) {
            return EnvironmentType.OPERATION;
        } else {
            return EnvironmentType.UNKNOWN;
        }

    }

}
