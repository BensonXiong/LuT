package com.lu.mobileafw.app;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.Capabilities;

import java.net.URL;

/**
 * Created by huangyinhuang on 16/3/25.
 *
 * LuApp在android上的driver,用于添加android设备特有操作
 *
 */


public class LuAndroidDriver extends AndroidDriver {

    public LuAndroidDriver(URL remoteAddress, Capabilities desiredCapabilities) {
        super(remoteAddress, desiredCapabilities);
    }

}
