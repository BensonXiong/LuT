package com.lu.mobileafw.app;

import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by huangyinhuang on 16/5/9.
 *
 * 通用UI操作（作为driver的补充）
 *
 */


public class LuDriverHelper {

    private Logger logger = LoggerFactory.getLogger(LuDriverHelper.class);

    private AppiumDriver driver;
    private WebDriverWait driverWait;

    public LuDriverHelper() {

    }

    public LuDriverHelper(AppiumDriver driver) {
        this.driver = driver;
    }

    public void init(AppiumDriver driver) {
        this.driver = driver;
        int timeoutInSeconds = 60;
        driverWait = new WebDriverWait(driver, timeoutInSeconds);
    }

    public boolean trySearchElementByScroll(By locator, boolean bScrollDown, int maxScrollTimes) {

        boolean bFound = false;
        boolean bOnScreen = false;

        int nCount = 0;

        try {

            do {
                WebElement ele = driver.findElement(locator);

                bFound = checkExist(ele);
                logger.info("check if the element exist :" + bFound);
                if (bFound) {
                    bOnScreen = isDisplayedOnScreen(ele);
                    logger.info("check if the element isDisplayedOnScreen :" + bOnScreen);
                }


                if ( (bFound && bOnScreen) || nCount > maxScrollTimes ) {
                    break;
                }

                logger.info("scroll down the page, time = " + nCount);
                WebDriver.Window window = driver.manage().window();
                int width= window.getSize().width;
                int height= window.getSize().height;
                driver.swipe(width/2, (int)(height * 0.9), width/2, (int)(height * 0.1), 1000);

                nCount++;

            }while(true);

        } catch (Exception e) {
            logger.error("an exception is happened when try to search element by scrolling.", e);
        }

        return bFound;
    }

    public boolean trySearchElementByScroll(WebElement ele, boolean bScrollDown, int maxScrollTimes) {

        boolean bFound = false;
        boolean bOnScreen = false;

        int nCount = 0;
        do {


            bFound = checkExist(ele);
            logger.info("check if the element exist:" + bFound);
            if (bFound) {
                bOnScreen = isDisplayedOnScreen(ele);
                logger.info("check if the element isDisplayedOnScreen:" + bOnScreen);
            }


            if ((bFound && bOnScreen) || nCount > maxScrollTimes ) {
                break;
            }

            logger.info("scroll down the page, time = " + nCount);
            WebDriver.Window window = driver.manage().window();
            int width= window.getSize().width;
            int height= window.getSize().height;
//            driver.swipe(width/2, height-300, width/2, 300, 1000);
            driver.swipe(width/2, (int)(height * 0.9), width/2, (int)(height * 0.1), 1000);

            nCount++;

        }while(true);

        return bFound;
    }

    public boolean checkExist(WebElement element) {
        return TestHelper.checkExist(element);
    }

    public boolean isDisplayedOnScreen(WebElement element) {
        int eleY = element.getLocation().getY();
        int height= TestHelper.driver.manage().window().getSize().height;
        if (eleY > height) {
            return false;
        }else {
            return true;
        }
    }

    public void sleep(long millis) {

        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public void clickWhenExist(WebElement element) {

        clickWhenExist(element, 5000);

    }

    public void clickWhenExist(WebElement element, long millis) {

        // wait seconds before check
        sleep(millis);

        boolean bFound = checkExist(element);

        // click the element when found
        if(bFound) {
            element.click();
        }

    }

}
