package com.lu.mobileafw.app;

import com.lu.mobileafw.report.RunningCaseInfo;
import com.lu.mobileafw.utils.LuDateFormat;
import net.coobird.thumbnailator.Thumbnails;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by huangyinhuang on 16/6/8.
 */
public class LuScreenShooter {
    private Logger logger = LoggerFactory.getLogger(LuDriverHelper.class);

    protected TakesScreenshot screenshooter;
    private String fileBasePath = "./reports/capturedImg/";
    private List<String> fileList = new ArrayList<String>();

    public void init(TakesScreenshot screenshoter) {
        this.screenshooter = screenshoter;
    }

    public String takeScreenshot(String caseName) {

        String screenFilePath = null;

        try {
            logger.debug("start to capture the screen");
            // sleep 3 seconds before capture the screen
            Thread.sleep(3 * 1000);

            String timestamp = LuDateFormat.getTimestamp();
            String fileFullName = String.format("%s.%s.jpg", caseName, timestamp);
            screenFilePath = String.format("%s/%s", fileBasePath, fileFullName);

            logger.debug("image path:" + screenFilePath);
            File scrFile = screenshooter.getScreenshotAs(OutputType.FILE);
            File destFile = new File(screenFilePath);
            FileUtils.copyFile(scrFile, destFile);

            // resize the image
//            Thumbnails.of(destFile).size(640, 512).outputFormat("jpg").toFile(destFile);
            Thumbnails.of(destFile).scale(0.2f).outputFormat("jpg").toFile(destFile);
            //Thumbnails.of(screenFilePath).scale(0.2f).outputFormat("jpg").toFile(screenFilePath);

            logger.debug("saved screen shot image as file: " + screenFilePath);
            fileList.add(fileFullName);

        } catch (Exception e) {
            logger.error("An error is happened when trying to capture app screen", e);
        }

        return screenFilePath;

    }

    public List<String> getScreenshotFiles(String caseName) {

        List<String> fList = new ArrayList<String>();

        try{
            logger.debug("try to search file by case name: " + caseName);
            for (String fileName: fileList) {
                if (fileName.indexOf(caseName) != -1) {
                    logger.debug("found: " + fileName);
                    fList.add(fileName);
                }
            }

        } catch (Exception e) {
            logger.error("An error is happened when trying to search screenshot files", e);
        }

        return fList;

    }

    /**
     * @param infoType
     * info type: 信息类别，例如：｛assert, fail, success, skip, info｝等
     */
    public void takeScreenshotByCase(String infoType) {

        logger.debug("start to take screenshot");
        logger.debug("case name:" + RunningCaseInfo.caseInstanceName);
        logger.debug("case name:" + RunningCaseInfo.caseName);
        logger.debug("info type:" + infoType);

        String casePrefix = RunningCaseInfo.getCaseNamePrefix();
        if ( (null != casePrefix) && (null != infoType) ) {
            String caseFullName = String.format("%s.%s", casePrefix, infoType);
            takeScreenshot(caseFullName);
        }
        else {
            logger.error("test case info is null, failed to take screenshot by case");
        }

    }

    public List<String> getScreenshotFilesByCase() {
        String casePrefix = RunningCaseInfo.getCaseNamePrefix();
        List<String> screenFiles = getScreenshotFiles(casePrefix);
        return screenFiles;
    }


}
