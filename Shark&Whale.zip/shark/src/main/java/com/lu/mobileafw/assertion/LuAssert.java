package com.lu.mobileafw.assertion;


import com.lu.mobileacore.observer.IAssertObservable;
import com.lu.mobileacore.observer.IAssertObserver;
import com.lu.mobileafw.app.TestHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.util.*;


/**
 * Created by huangyinhuang on 16/3/14.
 *
 * 断言
 *
 */


public class LuAssert implements IAssertObservable {

    private Logger logger = LoggerFactory.getLogger(LuAssert.class);

    private WebElement trySearchElement(By locator) {
        WebElement ele = null;

        try{
            ele = TestHelper.element(locator);
        }
        catch (Exception e){
            logger.debug("appium is not able to position the element.");
        }

        return ele;
    }

    public void assertElementVisible(String message, By locator) {

        logger.debug(message);

        WebElement ele = trySearchElement(locator);

        if (ele == null) {
            Assert.fail(message + "expected:<element " + locator.toString() + " to be positioned> but was:<element not found, " + ele + ">");
        }

    }

    public void assertElementHidden(String message, By locator) {
        
        logger.debug(message);

        WebElement ele = trySearchElement(locator);

        if (ele != null) {
            Assert.fail(message + "expected:<element " + locator.toString() + " is null> but was:<" + ele + ">");
        }

    }

    /**
     * notify observers when on assertion
     */
    private void onAssert() {
        onAssert(null);
    }

    private void onAssert(String message) {
        notifyObservers(message);
    }

    /***
     * observer for assert
     */

    private Vector observersVector;

    public LuAssert() {
        observersVector = new Vector();
    }

    @Override
    public void addObserver(IAssertObserver o) {

        if (o == null) {
            throw new NullPointerException();
        }

        if (!observersVector.contains(o)) {
            observersVector.addElement(o);
        }

    }

    @Override
    public void deleteObserver(IAssertObserver o) {
        observersVector.removeElement(o);
    }

    @Override
    public void notifyObservers(String message) {
        Enumeration enumeration = observers();
        while (enumeration.hasMoreElements())
        {
            ((IAssertObserver) enumeration.nextElement()).onAssert(message);
        }
    }

    private Enumeration observers()
    {
        return ((Vector) observersVector.clone()).elements();
    }

    /**
     *
     * delegation for Assert methods
     *
     */

    public void info(String message) {
        logger.debug(message);
        onAssert(message);
    }

    /**
     * Asserts that a condition is true. If it isn't,
     * an AssertionError, with the given message, is thrown.
     * @param condition the condition to evaluate
     * @param message the assertion error message
     */
    public void assertTrue(boolean condition, String message) {
        Assert.assertTrue(condition, message);
        onAssert(message);
    }

    /**
     * Asserts that a condition is true. If it isn't,
     * an AssertionError is thrown.
     * @param condition the condition to evaluate
     */
    public void assertTrue(boolean condition) {
        Assert.assertTrue(condition);
        onAssert();
    }

    /**
     * Asserts that a condition is false. If it isn't,
     * an AssertionError, with the given message, is thrown.
     * @param condition the condition to evaluate
     * @param message the assertion error message
     */
    public void assertFalse(boolean condition, String message) {
        Assert.assertFalse(condition, message);
        onAssert(message);
    }

    /**
     * Asserts that a condition is false. If it isn't,
     * an AssertionError is thrown.
     * @param condition the condition to evaluate
     */
    public void assertFalse(boolean condition) {
        Assert.assertFalse(condition);
        onAssert();
    }

    /**
     * Fails a test with the given message and wrapping the original exception.
     *  @param message the assertion error message
     * @param realCause the original exception
     */
    public void fail(String message, Throwable realCause) {
        Assert.fail(message, realCause);
        onAssert(message);
    }

    /**
     * Fails a test with the given message.
     * @param message the assertion error message
     */
    public void fail(String message) {
        Assert.fail(message);
        onAssert(message);
    }

    /**
     * Fails a test with no message.
     */
    public void fail() {
        Assert.fail();
        onAssert();
    }

    /**
     * Asserts that two objects are equal. If they are not,
     * an AssertionError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEquals(Object actual, Object expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two objects are equal. If they are not,
     * an AssertionError is thrown.
     * @param actual the actual value
     * @param expected the expected value
     */
    public void assertEquals(Object actual, Object expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two Strings are equal. If they are not,
     * an AssertionError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEquals(String actual, String expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two Strings are equal. If they are not,
     * an AssertionError is thrown.
     * @param actual the actual value
     * @param expected the expected value
     */
    public void assertEquals(String actual, String expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two doubles are equal concerning a delta.  If they are not,
     * an AssertionError, with the given message, is thrown.  If the expected
     * value is infinity then the delta value is ignored.
     * @param actual the actual value
     * @param expected the expected value
     * @param delta the absolute tolerate value value between the actual and expected value
     * @param message the assertion error message
     */
    public void assertEquals(double actual, double expected, double delta, String message) {
        Assert.assertEquals(actual, expected, delta, message);
        onAssert(message);
    }

    /**
     * Asserts that two doubles are equal concerning a delta. If they are not,
     * an AssertionError is thrown. If the expected value is infinity then the
     * delta value is ignored.
     * @param actual the actual value
     * @param expected the expected value
     * @param delta the absolute tolerate value value between the actual and expected value
     */
    public void assertEquals(double actual, double expected, double delta) {
        Assert.assertEquals(actual, expected, delta);
        onAssert();
    }

    /**
     * Asserts that two floats are equal concerning a delta. If they are not,
     * an AssertionError, with the given message, is thrown.  If the expected
     * value is infinity then the delta value is ignored.
     * @param actual the actual value
     * @param expected the expected value
     * @param delta the absolute tolerate value value between the actual and expected value
     * @param message the assertion error message
     */
    public void assertEquals(float actual, float expected, float delta, String message) {
        Assert.assertEquals(actual, expected, delta, message);
        onAssert(message);
    }

    /**
     * Asserts that two floats are equal concerning a delta. If they are not,
     * an AssertionError is thrown. If the expected
     * value is infinity then the delta value is ignored.
     * @param actual the actual value
     * @param expected the expected value
     * @param delta the absolute tolerate value value between the actual and expected value
     */
    public void assertEquals(float actual, float expected, float delta) {
        Assert.assertEquals(actual, expected, delta);
        onAssert();
    }

    /**
     * Asserts that two longs are equal. If they are not,
     * an AssertionError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEquals(long actual, long expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two longs are equal. If they are not,
     * an AssertionError is thrown.
     * @param actual the actual value
     * @param expected the expected value
     */
    public void assertEquals(long actual, long expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two booleans are equal. If they are not,
     * an AssertionError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEquals(boolean actual, boolean expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two booleans are equal. If they are not,
     * an AssertionError is thrown.
     * @param actual the actual value
     * @param expected the expected value
     */
    public void assertEquals(boolean actual, boolean expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two bytes are equal. If they are not,
     * an AssertionError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEquals(byte actual, byte expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two bytes are equal. If they are not,
     * an AssertionError is thrown.
     * @param actual the actual value
     * @param expected the expected value
     */
    public void assertEquals(byte actual, byte expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two chars are equal. If they are not,
     * an AssertionFailedError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEquals(char actual, char expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two chars are equal. If they are not,
     * an AssertionError is thrown.
     * @param actual the actual value
     * @param expected the expected value
     */
    public void assertEquals(char actual, char expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two shorts are equal. If they are not,
     * an AssertionFailedError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEquals(short actual, short expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two shorts are equal. If they are not,
     * an AssertionError is thrown.
     * @param actual the actual value
     * @param expected the expected value
     */
    public void assertEquals(short actual, short expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two ints are equal. If they are not,
     * an AssertionFailedError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEquals(int actual, int expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two ints are equal. If they are not,
     * an AssertionError is thrown.
     * @param actual the actual value
     * @param expected the expected value
     */
    public void assertEquals(int actual, int expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Asserts that an object isn't null. If it is,
     * an AssertionError is thrown.
     * @param object the assertion object
     */
    public void assertNotNull(Object object) {
        Assert.assertNotNull(object);
        onAssert();
    }

    /**
     * Asserts that an object isn't null. If it is,
     * an AssertionFailedError, with the given message, is thrown.
     * @param object the assertion object
     * @param message the assertion error message
     */
    public void assertNotNull(Object object, String message) {
        Assert.assertNotNull(object, message);
        onAssert(message);
    }

    /**
     * Asserts that an object is null. If it is not,
     * an AssertionError, with the given message, is thrown.
     * @param object the assertion object
     */
    public void assertNull(Object object) {
        Assert.assertNull(object);
        onAssert();
    }

    /**
     * Asserts that an object is null. If it is not,
     * an AssertionFailedError, with the given message, is thrown.
     * @param object the assertion object
     * @param message the assertion error message
     */
    public void assertNull(Object object, String message) {
        Assert.assertNull(object, message);
        onAssert(message);
    }

    /**
     * Asserts that two objects refer to the same object. If they do not,
     * an AssertionFailedError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertSame(Object actual, Object expected, String message) {
        Assert.assertSame(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two objects refer to the same object. If they do not,
     * an AssertionError is thrown.
     * @param actual the actual value
     * @param expected the expected value
     */
    public void assertSame(Object actual, Object expected) {
        Assert.assertSame(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two objects do not refer to the same objects. If they do,
     * an AssertionError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertNotSame(Object actual, Object expected, String message) {
        Assert.assertNotSame(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two objects do not refer to the same object. If they do,
     * an AssertionError is thrown.
     * @param actual the actual value
     * @param expected the expected value
     */
    public void assertNotSame(Object actual, Object expected) {
        Assert.assertNotSame(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two collections contain the same elements in the same order. If they do not,
     * an AssertionError is thrown.
     *  @param actual the actual value
     * @param expected the expected value
     */
    public void assertEquals(Collection actual, Collection expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two collections contain the same elements in the same order. If they do not,
     * an AssertionError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEquals(Collection actual, Collection expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two arrays contain the same elements in the same order. If they do not,
     * an AssertionError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEquals(Object[] actual, Object[] expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two arrays contain the same elements in no particular order. If they do not,
     * an AssertionError, with the given message, is thrown.
     * @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEqualsNoOrder(Object[] actual, Object[] expected, String message) {
        Assert.assertEqualsNoOrder(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two arrays contain the same elements in the same order. If they do not,
     * an AssertionError is thrown.
     *  @param actual the actual value
     * @param expected the expected value
     */
    public void assertEquals(Object[] actual, Object[] expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two arrays contain the same elements in no particular order. If they do not,
     * an AssertionError is thrown.
     * @param actual the actual value
     * @param expected the expected value
     */
    public void assertEqualsNoOrder(Object[] actual, Object[] expected) {
        Assert.assertEqualsNoOrder(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two arrays contain the same elements in the same order. If they do not,
     * an AssertionError is thrown.
     *  @param actual the actual value
     * @param expected the expected value
     */
    public void assertEquals(byte[] actual, byte[] expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Asserts that two arrays contain the same elements in the same order. If they do not,
     * an AssertionError, with the given message, is thrown.
     *  @param actual the actual value
     * @param expected the expected value
     * @param message the assertion error message
     */
    public void assertEquals(byte[] actual, byte[] expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two sets are equal.
     * @param actual
     * @param expected
     */
    public void assertEquals(Set actual, Set expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    /**
     * Assert set equals
     * @param actual
     * @param expected
     * @param message
     */
    public void assertEquals(Set<?> actual, Set<?> expected, String message) {
        Assert.assertEquals(actual, expected, message);
        onAssert(message);
    }

    /**
     * Asserts that two maps are equal.
     * @param actual
     * @param expected
     */
    public void assertEquals(Map<?, ?> actual, Map<?, ?> expected) {
        Assert.assertEquals(actual, expected);
        onAssert();
    }

    public void assertNotEquals(Object actual1, Object actual2, String message) {
        Assert.assertNotEquals(actual1, actual2, message);
        onAssert(message);
    }

    public void assertNotEquals(Object actual1, Object actual2) {
        Assert.assertNotEquals(actual1, actual2);
        onAssert();
    }

    public void assertNotEquals(float actual1, float actual2, float delta, String message) {
        Assert.assertNotEquals(actual1, actual2, delta, message);
        onAssert(message);
    }

    public void assertNotEquals(float actual1, float actual2, float delta) {
        Assert.assertNotEquals(actual1, actual2, delta);
        onAssert();
    }

    public void assertNotEquals(double actual1, double actual2, double delta, String message) {
        Assert.assertNotEquals(actual1, actual2, delta, message);
        onAssert(message);
    }

    public void assertNotEquals(double actual1, double actual2, double delta) {
        Assert.assertNotEquals(actual1, actual2, delta);
        onAssert();
    }
}
