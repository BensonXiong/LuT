package com.lu.mobileafw.be;

import com.google.gson.JsonObject;
import com.lu.mobileafw.data.impl.UserParaData;
import com.lu.mobileafw.enumer.LuProductType;
import org.testng.annotations.Test;

import java.util.HashMap;

/**
 * Created by huangyinhuang on 16/6/21.
 */
public interface ILuTestBeEnv {

    // 清空验证码
    void clearCaptcha(String key);

    // 登录验证码
    String getCaptcha();

    // 短信验证码
    String getSms();

    // 短信验证码 需手机号
    String getSms(String mobileNum);

    // 检查保险列表
    void scanProductlist();

    HashMap getProductList();

    JsonObject getProuductName(LuProductType type);

    //转账激活绑定银行卡
    void activationBankCard(String userName);

    //获取零活宝账户
    String getUserNameLingHuoBao();

    //获取智能宝账户
    String getUserNameZhiNengBao();

    //获取富盈宝宝
    String getUserNameFuYinBaoBao();

    //获取基金
    String getUserNameFound();

    //获取彩虹转让
    String getUserNameCaiHongTransfer();

    //获取安鑫转让
    String getUserNameAnXinTransfer();

    //获取财富汇转让
    String getUserNameCaiHuHuiTransfer();

    //获取彩虹变现
    String getUserNameCaiHongCash();

    //获取安鑫变现
    String getUserNameAnXinCash();

    //获取财富汇变现
    String getUserNameCaiHuHuiCash();

    UserParaData getNewUserParameter();

    @Test
    //每次运行生成一个随机用户名和密码
    String createTestAccount();
}
