package com.lu.mobileafw.data;

import java.util.Date;

/**
 * Created by huangyinhuang on 16/5/25.
 */
public interface IUserParaData {

    String getUserName();

    void setUserName(String userName);

    String getLoginPwd();

    void setLoginPwd(String loginPwd);

    String getMobileNo();

    void setMobileNo(String mobileNo);

    String getRealName();

    void setRealName(String realName);

    String getCardNo();

    void setCardNo(String cardNo);

    String getBankCode();

    void setBankCode(String bankCode);

    String getCredentialsNo();

    void setCredentialsNo(String credentialsNo);

    String getBank();

    void setBank(String bank);

    Date getBirthDay();

    void setBirthDay(Date birthDay);

    String getAnswer();

    void setAnswer(String answer);

    String getIpAddress();

    void setIpAddress(String ipAddress);

    String getMarketCookie();

    void setMarketCookie(String marketCookie);

}
