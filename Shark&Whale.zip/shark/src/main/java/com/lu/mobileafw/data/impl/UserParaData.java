package com.lu.mobileafw.data.impl;

import com.lu.mobileafw.data.IUserParaData;

import java.util.Date;

/**
 * Created by huangyinhuang on 16/5/25.
 */
public class UserParaData implements IUserParaData {

    String userName;
    String loginPwd;
    String mobileNo;
    String realName;
    String cardNo;
    String credentialsNo;
    String bank;
    String bankCode;
    Date birthDay;
    String answer;
    String ipAddress;
    String marketCookie;

    @Override
    public String getBank() {
        return bank;
    }

    @Override
    public void setBank(String bank) {
        this.bank = bank;
    }

    @Override
    public String getBankCode() {
        return bankCode;
    }

    @Override
    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    @Override
    public Date getBirthDay() {
        return birthDay;
    }

    @Override
    public void setBirthDay(Date birthDay) {
        this.birthDay = birthDay;
    }

    @Override
    public String getAnswer() {
        return answer;
    }

    @Override
    public void setAnswer(String answer) {
        this.answer = answer;
    }

    @Override
    public String getIpAddress() {
        return ipAddress;
    }

    @Override
    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    @Override
    public String getMarketCookie() {
        return marketCookie;
    }

    @Override
    public void setMarketCookie(String marketCookie) {
        this.marketCookie = marketCookie;
    }

    public String getCredentialsNo() {
        return credentialsNo;
    }

    public void setCredentialsNo(String credentialsNo) {
        this.credentialsNo = credentialsNo;
    }

    @Override
    public String getUserName() {
        return userName;
    }

    @Override
    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public String getLoginPwd() {
        return loginPwd;
    }

    @Override
    public void setLoginPwd(String loginPwd) {
        this.loginPwd = loginPwd;
    }

    @Override
    public String getMobileNo() {
        return mobileNo;
    }

    @Override
    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    @Override
    public String getRealName() {
        return realName;
    }

    @Override
    public void setRealName(String realName) {
        this.realName = realName;
    }

    @Override
    public String getCardNo() {
        return cardNo;
    }

    @Override
    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

}
