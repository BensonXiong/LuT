package com.lu.mobileafw.enumer;

/**
 * Created by huangyinhuang on 16/6/3.
 *
 * app平台类别
 *
 */

public enum AppPlatformType {

    ANDROID,
    IOS,
    UNKNOWN

}
