package com.lu.mobileafw.enumer;

/**
 * Created by huangyinhuang on 16/6/16.
 *
 * 测试环境类型
 * DEV - 开发环境
 * TEST － 测试环境
 * PRODUCTION － 线上环境
 * OPERATION - 运维环境（等同于线上环境，此一般用于区别测试用途，该环境通常用于监控目的）
 * UNKNOWN
 */

public enum EnvironmentType {

    DEV,
    TEST,
    PRODUCTION,
    OPERATION,
    UNKNOWN

}
