package com.lu.mobileafw.enumer;

/**
 * Created by huangyinhuang on 16/5/20.
 */
public enum LuProductType {

    FYRS("富盈人生", 401),
    ZJRS("珠江人寿", 601),
    GHRS("国华人寿", 602),
    PARS("平安人寿", 603),
    SMRS("生命人寿", 604),
    BNRS("百年人寿", 605),
    XTRS("信泰人寿", 606),
    QHRS("前海人寿", 607),
    HXRS("华夏人寿", 608),
    JKRS("君康人寿", 609),
    YGRS("阳光人寿", 610),
    XZJRS("新珠江人寿", 611),
    HDRS("恒大人寿", 612),
    ZRRS("中融人寿", 613),
    BHRS("渤海人寿", 614),
    TARS("天安人寿", 615),
    HZRS("合众人寿", 616),
    HKRS("弘康人寿", 617);

    private String name;        // 产品类别名称
    private Integer code;       // 产品类别代码

    private LuProductType(String name, Integer code) {
        this.name = name;
        this.code = code;
    }

    @Override
    public String toString() {
        return this.code + "_" + this.name;
    }

    public String getName() {
        return name;
    }

    public Integer getCode() {
        return code;
    }

    public String getCodeString() {
        return code.toString();
    }

}
