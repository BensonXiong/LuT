package com.lu.mobileafw.exception;

/**
 * Created by huangyinhuang on 16/5/10.
 *
 * 异常：没有找到该产品
 *
 */


public class NoSuchProductException extends Exception {

    /**
     * Constructs a new exception with the specified detail message.  The
     * cause is not initialized, and may subsequently be initialized by
     * a call to {@link #initCause}.
     *
     * @param message the detail message. The detail message is saved for
     *                later retrieval by the {@link #getMessage()} method.
     */
    public NoSuchProductException(String message) {
        super(message);
    }

}
