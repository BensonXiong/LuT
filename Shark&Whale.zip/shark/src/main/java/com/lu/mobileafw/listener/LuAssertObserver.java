package com.lu.mobileafw.listener;

import com.lu.mobileacore.observer.IAssertObserver;
import com.lu.mobileafw.app.LuScreenShooter;
import com.lu.mobileafw.report.ShareLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by huangyinhuang on 16/6/3.
 */
public class LuAssertObserver implements IAssertObserver {

    private Logger logger = LoggerFactory.getLogger(LuAssertObserver.class);
    private static LuScreenShooter screenshooter;

    public static void initScreenshot(LuScreenShooter screenshoter) {
        LuAssertObserver.screenshooter = screenshoter;
    }

    @Override
    public void onAssert(String message) {

        logger.debug("receive an assert message...");
        if( screenshooter == null ) {
            logger.error("screen shooter has not been initialized.");
        }
        else if ( message != null && message.toLowerCase().contains(LuTagScreen.TAG) ) {
            // take an screen shot on assert
            screenshooter.takeScreenshotByCase("assert");
        }

    }


}
