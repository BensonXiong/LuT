package com.lu.mobileafw.listener;

import com.lu.mobileacore.observer.ILogObserver;
import com.lu.mobileafw.app.LuScreenShooter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by huangyinhuang on 16/6/12.
 */
public class LuLogObserver implements ILogObserver {

    private Logger logger = LoggerFactory.getLogger(LuLogObserver.class);
    private static LuScreenShooter screenshooter;

    public static void initScreenshot(LuScreenShooter screenshoter) {
        LuLogObserver.screenshooter = screenshoter;
    }

    @Override
    public void onLog(String message) {

        logger.debug("receive an log message from LuLogger...");
        if( screenshooter == null ) {
            logger.error("screen shooter has not been initialized.");
        }
        else if ( message != null && message.toLowerCase().contains(LuTagScreen.TAG) ) {
            // take an screen shot on assert
            screenshooter.takeScreenshotByCase("assert");
        }

    }

}
