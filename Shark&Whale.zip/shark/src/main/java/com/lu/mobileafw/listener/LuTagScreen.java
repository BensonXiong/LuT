package com.lu.mobileafw.listener;

/**
 * Created by huangyinhuang on 16/6/12.
 */
public final class LuTagScreen {
    public final static String TAG = "[screen]";
}
