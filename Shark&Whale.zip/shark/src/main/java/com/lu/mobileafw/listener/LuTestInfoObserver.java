package com.lu.mobileafw.listener;

import com.lu.mobileacore.observer.IAssertObserver;
import com.lu.mobileacore.observer.ILogObserver;
import com.lu.mobileafw.report.ShareLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by huangyinhuang on 16/6/14.
 */
public class LuTestInfoObserver implements ILogObserver, IAssertObserver {

    private Logger logger = LoggerFactory.getLogger(LuTestInfoObserver.class);

    @Override
    public void onAssert(String message) {
        logger.debug("receive an assert message...");
        addMessage(message);
    }

    @Override
    public void onLog(String message) {
        logger.debug("receive an log message...");
        addMessage(message);
    }

    private void addMessage(String message){
        if(message != null || message != ""){
            if (message.toLowerCase().contains(LuTagScreen.TAG)){
                message = message.replace(LuTagScreen.TAG,"");
                message = message.trim();
            }
            logger.debug(ShareLog.stepNumber + " " + message);
            if (message.trim() !=""){
                ShareLog.setReportLog(ShareLog.stepNumber + " " + message.trim() + "\r\n");
                ShareLog.setStepNumber(1);
            }

        }
    }

}
