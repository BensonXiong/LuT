package com.lu.mobileafw.listener;

import com.lu.mobileafw.app.LuScreenShooter;
import com.lu.mobileafw.report.LuReportHtml;
import com.lu.mobileafw.report.RunningCaseInfo;
import com.lu.mobileafw.report.ShareLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by huangyinhuang on 16/5/17.
 */
@Component
public class LuTestListener implements ITestListener {

    private Logger logger = LoggerFactory.getLogger(LuTestListener.class);

    private LuReportHtml reportHtml;

    protected static LuScreenShooter screenshooter;

    public LuTestListener() {
        reportHtml = new LuReportHtml();
    }

    public static void initScreenshot(LuScreenShooter screenshoter) {
        LuTestListener.screenshooter = screenshoter;
    }

    public void takeScreenshotByCase(String infoType) {

        if( screenshooter == null ) {
            logger.error("screen shooter has not been initialized.");
        }
        else {
            // take an screen shot
            screenshooter.takeScreenshotByCase(infoType);
        }

    }

    public List<String> getScreenshotFilesByCase() {

        List<String> screenFiles;

        if ( screenshooter == null) {
            logger.error("screen shooter has not been initialized. failed to fetch screen files.");
            screenFiles = new ArrayList<String>();
        }
        else {
            screenFiles = screenshooter.getScreenshotFilesByCase();
        }

        return screenFiles;

    }


    /**
     * Invoked each time before a test will be invoked.
     * The <code>ITestResult</code> is only partially filled with the references to
     * class, method, start millis and status.
     *
     * @param result the partially filled <code>ITestResult</code>
     * @see ITestResult#STARTED
     */
    @Override
    public void onTestStart(ITestResult result) {
        logger.debug("start to run test...");
        RunningCaseInfo.caseName = result.getName();
        RunningCaseInfo.caseInstanceName = result.getInstanceName();
    }

    /**
     * Invoked each time a test succeeds.
     *
     * @param result <code>ITestResult</code> containing information about the run test
     * @see ITestResult#SUCCESS
     */
    @Override
    public void onTestSuccess(ITestResult result) {

        logger.debug("test case is succeeded to complete, write test result into report");
        //takeScreenshotByCase("success");

        // add test case result into report
        RunningCaseInfo.caseStatusResult = "PASS";
//        RunningCaseInfo.caseErrorLog = ShareLog.reportLog;
        printErrorLog(ShareLog.reportLog);
        List<String> screenFiles = getScreenshotFilesByCase();
        reportHtml.incrementCaseCount(LuReportHtml.CaseResultType.PASS);
        reportHtml.addCaseDetail(RunningCaseInfo.caseName, RunningCaseInfo.caseStatusResult, RunningCaseInfo.caseInstanceName, RunningCaseInfo.caseErrorLog, screenFiles);

    }

    /**
     * Invoked each time a test fails.
     *
     * @param result <code>ITestResult</code> containing information about the run test
     * @see ITestResult#FAILURE
     */
    @Override
    public void onTestFailure(ITestResult result) {

        logger.debug("test case is failed to complete, write test result into report");
        takeScreenshotByCase("fail");

        // add test case result into report
        RunningCaseInfo.caseStatusResult = "FAIL";
//        RunningCaseInfo.caseErrorLog = ShareLog.reportLog + "\r\n" + result.getThrowable().toString();
        printErrorLog(ShareLog.reportLog + "\r\n" + result.getThrowable().toString());
        List<String> screenFiles = getScreenshotFilesByCase();
        reportHtml.incrementCaseCount(LuReportHtml.CaseResultType.FAIL);
        reportHtml.addCaseDetail(RunningCaseInfo.caseName, RunningCaseInfo.caseStatusResult, RunningCaseInfo.caseInstanceName, RunningCaseInfo.caseErrorLog, screenFiles);

    }

    /**
     * Invoked each time a test is skipped.
     *
     * @param result <code>ITestResult</code> containing information about the run test
     * @see ITestResult#SKIP
     */
    @Override
    public void onTestSkipped(ITestResult result) {

        logger.debug("test case is skipped to complete, write test result into report");
        //takeScreenshotByCase("skip");

        // add test case result into report
        RunningCaseInfo.caseStatusResult = "SKIP";
//        RunningCaseInfo.caseErrorLog = ShareLog.reportLog;
        printErrorLog(ShareLog.reportLog);
        List<String> screenFiles = getScreenshotFilesByCase();
        reportHtml.incrementCaseCount(LuReportHtml.CaseResultType.SKIP);
        reportHtml.addCaseDetail(RunningCaseInfo.caseName, RunningCaseInfo.caseStatusResult, RunningCaseInfo.caseInstanceName, RunningCaseInfo.caseErrorLog, screenFiles);

    }

    /**
     * Invoked each time a method fails but has been annotated with
     * successPercentage and this failure still keeps it within the
     * success percentage requested.
     *
     * @param result <code>ITestResult</code> containing information about the run test
     * @see ITestResult#SUCCESS_PERCENTAGE_FAILURE
     */
    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        logger.debug("onTestFailedButWithSuccessPercentage");
    }

    /**
     * Invoked after the test class is instantiated and before
     * any configuration method is called.
     *
     * @param context
     */
    @Override
    public void onStart(ITestContext context) {
        logger.debug("onStart");
    }

    /**
     * Invoked after all the tests have run and all their
     * Configuration methods have been called.
     *
     * @param context
     */
    @Override
    public void onFinish(ITestContext context) {
        logger.debug("onFinish");
        try{
            reportHtml.publishReport();
        }catch (Exception e) {
            logger.error("an error happened when try to publish test report.", e);
        }
    }

    private void printErrorLog(String log){
        //set caseErrorLog
        RunningCaseInfo.caseErrorLog = log;

        //clean ShareLog.reportLog
        ShareLog.reportLog ="";
        ShareLog.stepNumber = 1;
    }

}
