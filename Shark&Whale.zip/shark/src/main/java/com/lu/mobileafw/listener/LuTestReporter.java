package com.lu.mobileafw.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.xml.XmlSuite;

import java.util.List;

/**
 * Created by huangyinhuang on 16/5/17.
 */
public class LuTestReporter implements IReporter {

    private Logger logger = LoggerFactory.getLogger(LuTestReporter.class);

    /**
     * Generate a report for the given suites into the specified output directory.
     *
     * @param xmlSuites
     * @param suites
     * @param outputDirectory
     */
    @Override
    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
        logger.debug("generateReport");
    }
}
