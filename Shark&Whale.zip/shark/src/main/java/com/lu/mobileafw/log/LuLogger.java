package com.lu.mobileafw.log;

import com.lu.mobileacore.observer.ILogObservable;
import com.lu.mobileacore.observer.ILogObserver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Enumeration;
import java.util.Vector;

/**
 * Created by huangyinhuang on 16/6/12.
 */
public class LuLogger implements ILogObservable {

    private Logger logger = LoggerFactory.getLogger(LuLogger.class);

    public void info(String message) {
        logger.info(message);
        notifyObservers(message);
    }

    /***
     * observer for logger
     */

    private Vector observersVector;

    public LuLogger() {
        observersVector = new Vector();
    }

    @Override
    public void addObserver(ILogObserver o) {

        if (o == null){
            throw new NullPointerException();
        }

        if (!observersVector.contains(o)) {
            observersVector.addElement(o);
        }

    }

    @Override
    public void deleteObserver(ILogObserver o) {
        observersVector.removeElement(o);
    }

    @Override
    public void notifyObservers(String message) {
        Enumeration enumeration = observers();
        while (enumeration.hasMoreElements())
        {
            ((ILogObserver) enumeration.nextElement()).onLog(message);
        }
    }

    private Enumeration observers()
    {
        return ((Vector) observersVector.clone()).elements();
    }
}
