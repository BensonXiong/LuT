package com.lu.mobileafw.report;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by feiyong on 16/3/16.
 * <p/>
 * 测试报告
 */

public class LuReportHtml {

    private Logger logger = LoggerFactory.getLogger(LuReportHtml.class);

    private StringBuilder reportHtmlBodyCaseDetail = new StringBuilder();

    private int totalCase = 0;
    private int totalPassedCase = 0;
    private int totalSkippedCase = 0;
    private int totalFailedCase = 0;
    private int totalWarnCase = 0;


    public enum CaseResultType {
        PASS,
        SKIP,
        FAIL,
        WARN
    }

    public void incrementCaseCount(CaseResultType type) {

        totalCase++;
        switch (type) {
            case PASS:
                totalPassedCase++;
                break;
            case SKIP:
                totalSkippedCase++;
                break;
            case FAIL:
                totalFailedCase++;
                break;
            case WARN:
                totalWarnCase++;
                break;
            default:
                break;
        }

    }

    public void addCaseDetail(String caseName, String caseStatus, String caseLog, String errorLog, List<String> screenShotFileUrls) {

        logger.debug("save case result into report...");
        logger.debug("case name: " + caseName);
        logger.debug("case status: " + caseStatus);
        logger.debug("case log: " + caseLog);
        logger.debug("case error log: " + errorLog);

        String caseDetail = getHtmlBodyCaseDetail(caseName, caseStatus, caseLog, errorLog, screenShotFileUrls);
        this.reportHtmlBodyCaseDetail.append(caseDetail);

    }

    public void publishReport() {

        logger.debug("start to publish report...");

        String header = getHtmlHeader();
        String body = getHtmlBody();
        String footer = getHtmlEnd();

        StringBuilder report = new StringBuilder();
        report.append(header);
        report.append(body);
        report.append(this.reportHtmlBodyCaseDetail.toString());
        report.append(footer);

        String reportHtml = report.toString();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
        String reportsHistoryPath = "./reports" + "//test_hisreport_" + sdf.format(new Date()) + ".html";
        logger.debug("save report to " + reportsHistoryPath);
        writeFile(reportsHistoryPath, reportHtml);

        String reportsPath = "./reports" + "//test_report.html";
        logger.debug("save report to " + reportsPath);
        writeFile(reportsPath, reportHtml);

        logger.debug("end of publish report...");

    }


    private String getHtmlHeader() {
        StringBuilder html = new StringBuilder();

        html.append("<head>" + "\r\n");
        html.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />" + "\r\n");
        html.append("<script src=\"http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js\"></script>" + "\r\n");
        html.append("<style type=\"text/css\">" + "\r\n");
        html.append("th{border-style: solid; border-width: 1px;border-color: black;}" + "\r\n");
        html.append("td{border-style: solid; border-width: 1px;border-color: black;}" + "\r\n");
        html.append(".casedetail .table1 td{cursor: pointer;font-family:微软雅黑;}" + "\r\n");
        html.append(".table1 th{font-family:微软雅黑;}" + "\r\n");
        html.append(".table1 p{margin:5px 0px 0px 20px;font-weight:normal;}" + "\r\n");
        html.append(".passedfont{color: #0a0;font-weight:bold;}" + "\r\n");
        html.append(".failedfont{color: #d00;font-weight:bold;}" + "\r\n");
        html.append(".warnfont{color: orange;font-weight:bold;}" + "\r\n");
        html.append(".skippedfont{color: #ccc;font-weight:bold;}" + "\r\n");
        html.append(".percentagefont{font-weight:bold;}" + "\r\n");
        html.append(".title1{margin:0 0 0 10px;text-align: left;font-size:25px;}" + "\r\n");
        html.append(".title2{margin:0 0 10px 10px;text-align: left;font-size:20px;color: black;text-align: center;}" + "\r\n");
        html.append(".title2 a:link,.title2 a:visited{text-decoration:none;color: black;}" + "\r\n");
        html.append(".title2 a:hover{text-decoration:underline;}" + "\r\n");
        html.append(".table1{width: 950px;text-align: center;margin:2px;border-style: solid; border-width: 1px;border-color: black;}" + "\r\n");
        html.append(".passedcasestyle{background-color: #01AA01;}" + "\r\n");
        html.append(".failedcasestyle{background-color: #e4362d;}" + "\r\n");
        html.append(".warncasestyle{background-color: #FFFFBB;}" + "\r\n");
        html.append(".skippedcasestyle{background-color: #ccc;}" + "\r\n");
        html.append(".stacktrace{white-space:pre;}" + "\r\n");
        html.append(".pborder{border-style: dashed none none none; border-width: 1px;border-color: black;}" + "\r\n");
        html.append(".screenshot{width: 300px;text-align:center; margin: 5px; box-shadow: 6px 6px 3px #888888;}" + "\r\n");
        html.append(".paneOperaionLog,.paneTestNGLog{display:none;}" + "\r\n");

        return html.toString();
    }

    private String getHtmlBody() {

        StringBuilder reportHtml = new StringBuilder();

        BigDecimal skippedPercent = new BigDecimal(0.0);
        BigDecimal failedPercent = new BigDecimal(0.0);
        BigDecimal passedPercentB = new BigDecimal(0.0);

        if (totalCase != 0) {
            skippedPercent = new BigDecimal(1.0 * totalSkippedCase / totalCase);
            skippedPercent = skippedPercent.setScale(2, BigDecimal.ROUND_HALF_UP);

            failedPercent = new BigDecimal(1.0 * totalFailedCase / totalCase);
            failedPercent = failedPercent.setScale(2, BigDecimal.ROUND_HALF_UP);
        }

        double passedPercentD = 1.0 - skippedPercent.doubleValue() - failedPercent.doubleValue();
        passedPercentB = new BigDecimal(passedPercentD);
        passedPercentB = passedPercentB.setScale(2, BigDecimal.ROUND_HALF_UP);


        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String reportTime = sdf.format(new Date());

        for (int i = 1; i <= totalCase; i++) {
            if (i != totalCase) {
                reportHtml.append(".caseexceptiondetail" + i + ",");
            } else {
                reportHtml.append(".caseexceptiondetail" + i + "{display:none;}\r\n");
            }
        }

        reportHtml.append("</style>" + "\r\n");
        //head js
        reportHtml.append("<script type=\"text/javascript\">" + "\r\n");
        reportHtml.append("$(document).ready(function(){$(document).ready(function(){" + "\r\n");
        for (int i = 1; i <= totalCase; i++) {
            reportHtml.append("$(\".caseexceptionpanel" + i + "\").click(function(){$(\".caseexceptiondetail" + i + "\").slideToggle(\"fast\");});\r\n");
            reportHtml.append("$(\".caseexceptiondetail" + i + "\").dblclick(function(){$(\".caseexceptiondetail" + i + "\").slideToggle(\"fast\");});\r\n");
        }
        reportHtml.append("$(\".flipOperaionLog\").click(function(){$(\".paneOperaionLog\").slideToggle(\"fast\");});" + "\r\n");
        reportHtml.append("$(\".paneOperaionLog\").dblclick(function(){$(\".paneOperaionLog\").slideToggle(\"fast\");});" + "\r\n");
        reportHtml.append("$(\".flipTestNGLog\").click(function(){$(\".paneTestNGLog\").slideToggle(\"fast\");});" + "\r\n");
        reportHtml.append("$(\".paneTestNGLog\").dblclick(function(){$(\".paneTestNGLog\").slideToggle(\"fast\");});" + "\r\n");

        reportHtml.append("$(\".allOpen\").click(function(){$(\".caseexceptiondetail\").hide();$(\".caseexceptiondetail\").slideToggle(\"fast\");});" + "\r\n");
        reportHtml.append("$(\".allClose\").click(function(){$(\".caseexceptiondetail\").hide();});" + "\r\n");

        reportHtml.append("getCaseTime();" + "\r\n");
        reportHtml.append("});});</script>" + "\r\n");
        //head js for html5
        reportHtml.append("<script>" + "\r\n");
        reportHtml.append("function drawCircle(canvasId, data_arr, color_arr, text_arr){" + "\r\n");
        reportHtml.append("var c = document.getElementById(canvasId);" + "\r\n");
        reportHtml.append("var ctx = c.getContext(\"2d\");" + "\r\n");
        reportHtml.append("var radius = c.height / 2 - 20;" + "\r\n");
        reportHtml.append("var ox = radius + 20, oy = radius + 20;" + "\r\n");
        reportHtml.append("var width = 30, height = 10;" + "\r\n");
        reportHtml.append("var posX = ox * 2 + 20, posY = 30;" + "\r\n");
        reportHtml.append("var textX = posX + width + 5, textY = posY + 10;" + "\r\n");
        reportHtml.append("var startAngle = 0;" + "\r\n");
        reportHtml.append("var endAngle = 0;" + "\r\n");
        reportHtml.append("for (var i = 0; i < data_arr.length; i++){" + "\r\n");
        reportHtml.append("endAngle = endAngle + data_arr[i] * Math.PI * 2;" + "\r\n");
        reportHtml.append("ctx.fillStyle = color_arr[i];" + "\r\n");
        reportHtml.append("ctx.beginPath();" + "\r\n");
        reportHtml.append("ctx.moveTo(ox, oy);" + "\r\n");
        reportHtml.append("ctx.arc(ox, oy, radius, startAngle, endAngle, false);" + "\r\n");
        reportHtml.append("ctx.closePath();" + "\r\n");
        reportHtml.append("ctx.fill();" + "\r\n");
        reportHtml.append("startAngle = endAngle;" + "\r\n");
        reportHtml.append("ctx.fillStyle = color_arr[i];" + "\r\n");
        reportHtml.append("ctx.fillRect(posX, posY + 20 * i, width, height);" + "\r\n");
        reportHtml.append("ctx.moveTo(posX, posY + 20 * i);" + "\r\n");
        reportHtml.append("ctx.font = 'bold 16px 微软雅黑';" + "\r\n");
        reportHtml.append("ctx.fillStyle = color_arr[i];" + "\r\n");
        reportHtml.append("var percent = text_arr[i] + \"：\" + parseInt(100 * data_arr[i]) + \"%\";" + "\r\n");
        reportHtml.append("ctx.fillText(percent, textX, textY + 20 * i);" + "\r\n");
        reportHtml.append("}}" + "\r\n");

        reportHtml.append("function init() {" + "\r\n");
        reportHtml.append("var data_arr = [" + passedPercentB + "," + failedPercent + "," + skippedPercent + "];" + "\r\n");
        reportHtml.append("var text_arr = [\"通过的用例\", \"失败的用例\", \"跳过的用例\"];" + "\r\n");
        reportHtml.append("var color_arr = [\"#01AA01\", \"#e4362d\", \"#A7A7A7\"];" + "\r\n");
        reportHtml.append("drawCircle(\"canvas_circle\", data_arr, color_arr, text_arr);}" + "\r\n");

        reportHtml.append("window.onload = init;" + "\r\n");
        reportHtml.append("function getCaseTime(){" + "\r\n");
        reportHtml.append("var tr = $(\".casedetail tr\");" + "\r\n");
        reportHtml.append("var sum = 0;" + "\r\n");
        reportHtml.append("for(i = 1; i < tr.length; i= i+2){var td = $(tr[i]).find(\"td\");sum += parseInt($(td[2]).text());}" + "\r\n");
        reportHtml.append("$(\"#casetime\").text(sum);}" + "\r\n");

        reportHtml.append("</script>" + "\r\n");

        reportHtml.append("<body>" + "\r\n");
        reportHtml.append("<div style=\"background-color: #FFFFFF;margin: 0 auto;width: 980px;border-style: solid; border-width: 2px;border-color: black;\">" + "\r\n");
        reportHtml.append("<div id=\"reporttitle\" style=\"font-weight:bold;text-align:center;font-size:40px;color:red;margin:20px 0px 0px 0px;\">LU App测试报告</div><br/>" + "\r\n");

        // test environment
        reportHtml.append("<div class=\"title1\">测试环境</div><br/>" + "\r\n");
        reportHtml.append("<div align=\"center\">" + "\r\n");
        reportHtml.append("<table class=\"table1\">" + "\r\n");
        reportHtml.append("<tbody>" + "\r\n");
        reportHtml.append("<tr><th>移动平台</th><th>平台版本</th><th>移动设备名</th><th>App版本</th><th>App包路径</th></tr>" + "\r\n");
        reportHtml.append("<tr><td>" + ShareLog.devicePlatformName + "</td><td>" + ShareLog.devicePlatformVer + "</td><td>"
                + ShareLog.deviceName + "</td><td>" + ShareLog.appVer + "</td><td>" + ShareLog.appPath + "</td></tr>" + "\r\n");
        reportHtml.append("</tbody></table></div><br/>" + "\r\n");

        // test results
        reportHtml.append("<div class=\"title1\">报告综述</div><br/>" + "\r\n");
        reportHtml.append("<div align=\"center\">" + "\r\n");
        reportHtml.append("<p><canvas id=\"canvas_circle\" width=\"500\" height=\"300\">浏览器不支持canvas</canvas></p>" + "\r\n");
        reportHtml.append("<table class=\"table1\">" + "\r\n");
        reportHtml.append("<tbody>" + "\r\n");
        reportHtml.append("<tr><th>TestName</th><th>执行用例数</th><th>通过用例数</th><th>失败用例数</th><th>跳过用例数</th><th>报告生成时间</th><th>执行通过率</th></tr>" + "\r\n");
        reportHtml.append("<tr><td>LU APP Test</td><td class=\"percentagefont\">" + totalCase
                + "</td><td class=\"passedfont\">" + (totalPassedCase + totalWarnCase) + "</td><td class=\"failedfont\">" + totalFailedCase + "</td>"
                + "<td class=\"skippedfont\">" + totalSkippedCase + "</td><td>" + reportTime + "</td><td class=\"percentagefont\">" + (passedPercentB.doubleValue() * 100) + "%</td></tr>" + "\r\n");
        reportHtml.append("</tbody></table></div><br/>" + "\r\n");

        // test details
        reportHtml.append("<div class=\"title1\">执行用例明细</div><br/>" + "\r\n");
        reportHtml.append("<div class=\"title2\"><a class=\"allOpen\" style=\"margin:0px 0px 0px 10px;\">全部展开</a><a class=\"allClose\" style=\"margin:0px 0px 0px 10px;\">全部收起</a></div>" + "\r\n");
        reportHtml.append("<div class=\"casedetail\" align=\"center\">" + "\r\n");
        reportHtml.append("<table class=\"table1\"><tbody>" + "\r\n");
        reportHtml.append("<tr><th>用例编号</th><th>执行状态</th><th>执行时间</th></tr>" + "\r\n");

        return reportHtml.toString();
    }

    private String getHtmlBodyCaseDetail(String caseName, String caseStatus, String caseLog, String errorLog, List<String> screenshotFileUrls) {

        if (caseName.isEmpty() || caseName.length() == 0) {
            caseName = "unknown-" + totalCase;
        }

        String cssCaseStyle = "";
        if (caseStatus.equalsIgnoreCase("PASS")) {
            caseStatus = "通过";
            cssCaseStyle = "passedcasestyle";
        } else if (caseStatus.equalsIgnoreCase("FAIL")) {
            caseStatus = "失败";
            cssCaseStyle = "failedcasestyle";
        } else if (caseStatus.equalsIgnoreCase("SKIP")) {
            caseStatus = "跳过";
            cssCaseStyle = "skippedcasestyle";
        } else if (caseStatus.equalsIgnoreCase("WARN")) {
            caseStatus = "警告";
            cssCaseStyle = "warncasestyle";
        } else {
            caseStatus = "未知状态：" + caseStatus;
            cssCaseStyle = "";
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String caseDuration = sdf.format(new Date());

        StringBuilder caseHtml = new StringBuilder();
        caseHtml.append("<tr class=\"" + cssCaseStyle + " caseexceptionpanel" + totalCase + "\"><td><a>" + caseName + "</a></td><td>" + caseStatus + "</td><td>" + caseDuration + "</td></tr>" + "\r\n");
        caseHtml.append("<tr class=\"caseexceptiondetail" + totalCase + " caseexceptiondetail\"><th colspan=\"3\" style=\"text-align: left;\"><p style=\"margin:5px 0px 0px 10px;\">用例信息：</p>" + caseLog + "\r\n");
        caseHtml.append("<p class=\"pborder\" style=\"margin:5px 0px 0px 10px;\">步骤信息：</p><p class=\"stacktrace\"><textarea rows=\"5\"  cols=\"145\" readonly=\"readonly\">" + errorLog + "</textarea></p>" + "\r\n");
        if (null != screenshotFileUrls) {
            for (String screenshotFile : screenshotFileUrls) {
                caseHtml.append("<img class=\"screenshot\" src=\"capturedImg/" + screenshotFile + "\">" + "\r\n");
            }
        }
        caseHtml.append("</th></tr>" + "\r\n");

        return caseHtml.toString();

    }

    private String getHtmlEnd() {
        StringBuilder html = new StringBuilder();

        html.append("</tbody></table></div><br/>" + "\r\n");
        html.append("\r\n");
        html.append("<div class=\"title2\"><a href=\"#reporttitle\">返回顶部</a><a class=\"allOpen\" style=\"margin:0px 0px 0px 10px;\">全部展开</a><a class=\"allClose\" style=\"margin:0px 0px 0px 10px;\">全部收起</a></div>" + "\r\n");
        html.append("</div>" + "\r\n");
        html.append("</body>" + "\r\n");
        html.append("</html>" + "\r\n");

        return html.toString();
    }

    private void writeFile(String fileName, String s) {

        try {

            File f = new File(fileName);
            if (!f.exists()) {
                f.createNewFile();
            }

            FileOutputStream out = new FileOutputStream(f, false);
            byte[] b = s.getBytes("UTF-8");
            out.write(b);
            out.close();

        } catch (Exception e) {
            logger.error("Failed to write report to file - " + fileName, e);
        }
    }

}
