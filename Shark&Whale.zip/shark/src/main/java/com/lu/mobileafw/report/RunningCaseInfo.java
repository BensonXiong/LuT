package com.lu.mobileafw.report;

/**
 * Created by huangyinhuang on 16/6/12.
 */
public class RunningCaseInfo {

    public static String caseName;
    public static String caseInstanceName;
    public static String caseStatusResult;
    public static String caseErrorLog;

    public static String getCaseNamePrefix() {

        if ((null != caseName) && (null != caseInstanceName)) {
            return String.format("%s.%s", caseInstanceName, caseName);
        } else {
            return null;
        }

    }

}
