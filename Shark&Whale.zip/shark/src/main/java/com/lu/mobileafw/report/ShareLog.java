package com.lu.mobileafw.report;

/**
 * Created by liuyinping on 16/5/30.
 */
public class ShareLog {

    public static String reportLog = "";
    public static int stepNumber = 1;

    public static String devicePlatformName = "";
    public static String devicePlatformVer = "";
    public static String deviceName = "";
    public static String appVer = "";
    public static String appPath = "";

    public static void setReportLog(String log){
        ShareLog.reportLog =  ShareLog.reportLog + log;
    }

    public static String getReportLog(){
        return reportLog;
    }

    public static int getStepNumber() {
        return stepNumber;
    }

    public static void setStepNumber(int stepNumber) {
        ShareLog.stepNumber = ShareLog.stepNumber + stepNumber;
    }
}
