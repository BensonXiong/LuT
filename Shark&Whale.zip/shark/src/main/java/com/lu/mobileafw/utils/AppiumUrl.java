package com.lu.mobileafw.utils;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by huangyinhuang on 16/3/28.
 */
public class AppiumUrl {

    public static URL getURL(String uri, String port) {
        String url = String.format("http://%s:%s/wd/hub", uri, port);

        URL rt = null;
        try {
            rt = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        return rt;
    }
}
