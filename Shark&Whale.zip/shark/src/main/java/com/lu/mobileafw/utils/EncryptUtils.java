package com.lu.mobileafw.utils;

import org.apache.http.util.TextUtils;
import sun.misc.BASE64Encoder;

import java.security.MessageDigest;
import java.util.Random;

/**
 * Created by youlingfei on 16/3/18.
 */
public class EncryptUtils {
    public static final String RANDOM_STRING = "abcdefghiklmnopqrstuvwxyz0123456789";
    public static final String ALG_SHA256 = "SHA-256";

    public static String signature(String str, String method) {
        try {
            if (TextUtils.isEmpty(str) || TextUtils.isEmpty(method)) {
                return "";
            }
            String result = encodeSH256Base64String(str);
            if (TextUtils.isEmpty(result)) {
                return "";
            } else {
                String[] splitResult = method.split("\\|");
                for (String aSplitResult : splitResult) {
                    int m = Integer.parseInt(aSplitResult);
                    if (m == 1) {
                        result = confuseBefore(result);
                    }
                    if (m == 2) {
                        result = confuseAfter(result);
                    }
                    if (m == 3) {
                        result = reverse(result);
                    }
                    if (m == 4) {
                        result = oddBefore(result);
                    }
                    if (m == 5) {
                        result = evenBefore(result);
                    }
                }
                return result.toUpperCase();
            }
        } catch (Exception e) {
            return "";
        }

    }

    public static String oddBefore(String str) {
        String before = "";
        String after = "";
        for (int i = 0; i < str.length(); i++) {
            if (i % 2 == 0) {
                before = before.concat(String.valueOf(str.charAt(i)));
            } else {
                after = after.concat(String.valueOf(str.charAt(i)));
            }
        }
        return before.concat(after);
    }

    public static String evenBefore(String str) {
        String before = "";
        String after = "";
        for (int i = 0; i < str.length(); i++) {
            if (i % 2 == 1) {
                before = before.concat(String.valueOf(str.charAt(i)));
            } else {
                after = after.concat(String.valueOf(str.charAt(i)));
            }
        }
        return before.concat(after);
    }

    public static String reverse(String str) {
        return new StringBuilder(str).reverse().toString();
    }

    public static String encodeSH256Base64String(String data) {
        String encodeBase64URLSafeString = "";
        try {
            if (!TextUtils.isEmpty(data)) {
                byte[] input = data.getBytes();
                MessageDigest md = MessageDigest.getInstance(ALG_SHA256);
                if (md != null) {
                    encodeBase64URLSafeString = new BASE64Encoder().encode(md.digest(input));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
        return encodeBase64URLSafeString;
    }


    public static String confuseBefore(String str) {
        StringBuilder sb = new StringBuilder();
        Random r = new Random();
        int range = RANDOM_STRING.length();
        for (int i = 0; i < 20; i++) {
            sb.append(RANDOM_STRING.charAt(r.nextInt(range)));
        }
        return sb.toString().concat(str);
    }

    public static String confuseAfter(String str) {
        StringBuilder sb = new StringBuilder();
        Random r = new Random();
        int range = RANDOM_STRING.length();
        for (int i = 0; i < 20; i++) {
            sb.append(RANDOM_STRING.charAt(r.nextInt(range)));
        }
        return str.concat(sb.toString());
    }

    public static void main(String[]args){



        String str = "14376312832471437631283202";
        Long L = Long.valueOf(str);
        System.out.print(L);
    }
}
