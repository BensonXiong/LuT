package com.lu.mobileafw.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by huangyinhuang on 16/5/17.
 */
public class LuDateFormat {

    public static String getTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd-HHmmss");
        return sdf.format(new Date());
    }

}
