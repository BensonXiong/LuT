package com.lu.mobileainfra.demo;

import com.lu.mobileafw.BasePageAbstract;

/**
 * Created by huangyinhuang on 16/6/21.
 */
public class BasePage extends BasePageAbstract {

}
