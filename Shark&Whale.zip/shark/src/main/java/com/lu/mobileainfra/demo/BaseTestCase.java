package com.lu.mobileainfra.demo;

import com.lu.mobileafw.BaseTestCaseAbstract;
import com.lu.mobileafw.be.ILuTestBeEnv;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by huangyinhuang on 16/6/21.
 */
public class BaseTestCase extends BaseTestCaseAbstract {

    private Logger logger = LoggerFactory.getLogger(BaseTestCase.class);

    @Override
    public ILuTestBeEnv getBeEnvironment() {
        return null;
    }

}
