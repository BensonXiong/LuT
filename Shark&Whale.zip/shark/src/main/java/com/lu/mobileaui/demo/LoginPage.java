package com.lu.mobileaui.demo;

import com.lu.mobileainfra.demo.BasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

import static com.lu.mobileafw.app.TestHelper.checkExist;

/**
 * Created by huangyinhuang on 16/3/31.
 *
 * app 登录页面
 *
 */

public class LoginPage extends BasePage {

    @iOSFindBy(xpath="//UIATextField[1]")//UIAApplication[1]/UIAWindow[1]/UIATextField[1]
    @AndroidFindBy(id="et_loginname")
    public WebElement UsernameInput;

    @iOSFindBy(xpath="//UIASecureTextField[1]")//UIAApplication[1]/UIAWindow[1]/UIASecureTextField[1]
    @AndroidFindBy(id="et_loginpswd")
    public WebElement PasswordInput;

    @iOSFindBy(xpath = "//UIATextField[2]") //UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATextField[2]
    @AndroidFindBy(id="et_loginvalidator")
    public WebElement VerifyCodeInput;

    @iOSFindBy(xpath = "//UIAScrollView[1]/UIAImage[2]")//UIAApplication[1]/UIAWindow[1]/UIAImage[1]
    @AndroidFindBy(id="iv_validator")
    public WebElement RefreshVCodeBtn;

    @iOSFindBy(name = "登录")
    @AndroidFindBy(id="btn_login")
    public WebElement LoginBtn;

    @iOSFindBy(name = "找回用户名")
    @AndroidFindBy(id="btn_register_username_retrieve")
    public WebElement RetrieveAccountBtn;

    @iOSFindBy(name = "忘记密码")
    @AndroidFindBy(id="btn_register_pwd_retrieve")
    public WebElement RetrievePasswordBtn;

    @iOSFindBy(name = "NA")
    @AndroidFindBy(id="title_bar_left_tv")
    public WebElement CloseBtn;

    @iOSFindBy(name = "注册新账户")
    @AndroidFindBy(id="title_bar_right_tv")
    public WebElement RegisterNewAccountBtn;

    /**
     * 验证码错误弹出框
     */
    // 验证码错误消息
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id="tv_popup_content") // //android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]
    public WebElement PopMessageText;

    // 确定错误消息
    @iOSFindBy(name = "NA")
    //@AndroidFindBy(id="btn_ok") //     //android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[2]
    @AndroidFindBy(id="//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[2]")
    public WebElement ConfirmMessageButton;

    public void Login(String username, String password) {
        logger.info("成功进入登录页面");
        logger.info("username=" + username);
        UsernameInput.clear();
        UsernameInput.sendKeys(username);

        logger.info("password=" + password);
        PasswordInput.clear();
        PasswordInput.sendKeys(password);


        Boolean bExist = checkExist(VerifyCodeInput);
        String code = "无";
        if(bExist) {
            testBeEnv.clearCaptcha("USER:V1:CAPTCHA");
            this.RefreshCode();
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            code = testBeEnv.getCaptcha();
            logger.info("code = " + code);

            VerifyCodeInput.clear();
            VerifyCodeInput.sendKeys(code);
        }
        testLogger.info("当前登录用户名：" + username + "\r\n   密码：" + password + "\r\n   验证码：" + code);
        LoginBtn.click();

        // wait 5+ seconds after login page switch
        driverHelper.sleep(5000);
    }

    public void RefreshCode() {
        RefreshVCodeBtn.click();
    }

    //忘记密码
    public void clickRetrievePassword(){
        RetrievePasswordBtn.click();
    }

}
