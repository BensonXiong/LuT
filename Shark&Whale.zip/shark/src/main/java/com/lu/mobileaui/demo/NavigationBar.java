package com.lu.mobileaui.demo;

import com.lu.mobileainfra.demo.BasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by huangyinhuang on 16/4/11.
 *
 * app 导航栏
 *
 */

public class NavigationBar extends BasePage {

    private Logger logger = LoggerFactory.getLogger(NavigationBar.class);

    @iOSFindBy(name="\uE696 首页")
    @AndroidFindBy(id="layout_bottombar1")
    public WebElement HomeButton;

    @iOSFindBy(name="\uE695 会员俱乐部")
    @AndroidFindBy(id="layout_bottombar5")
    public WebElement VipClubButton;

    @iOSFindBy(name="\uE699 投资理财")
    @AndroidFindBy(id="layout_bottombar2")
    public WebElement InvestmentButton;

    @iOSFindBy(name="\uE69B 我的账户")
    @AndroidFindBy(id="layout_bottombar3")
    public WebElement MyAccountButton;

    @iOSFindBy(name="\uE693 更多")
    @AndroidFindBy(id="layout_bottombar4")
    public WebElement MoreInfoButton;

    public void clickHomeButton(){
        this.HomeButton.click();

        // 切换页面等待5秒
        driverHelper.sleep(5000);
    }

    public void clickVipClubButton(){
        this.VipClubButton.click();

        // 切换页面等待5秒
        driverHelper.sleep(5000);
    }


    public void clickInvestmentButton(){
        this.InvestmentButton.click();

        // 切换页面等待15秒
        driverHelper.sleep(15000);
    }


    public void clickMyAccountButton(){
        this.MyAccountButton.click();

        // 切换页面等待5秒
        driverHelper.sleep(5000);
    }

    public void clickMoreInfoButton(){
        this.MoreInfoButton.click();

        // 切换页面等待5秒
        driverHelper.sleep(5000);
    }

}
