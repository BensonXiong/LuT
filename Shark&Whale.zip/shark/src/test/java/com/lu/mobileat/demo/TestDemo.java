package com.lu.mobileat.demo;

import com.lu.mobileainfra.demo.BaseTestCase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Created by huangyinhuang on 16/5/10.
 */
public class TestDemo extends BaseTestCase {
    Logger logger = LoggerFactory.getLogger(this.getClass().getName());


    @BeforeClass
    public void init() {
    }

    @BeforeMethod
    public void setup() {
    }

    @AfterMethod
    public void teardown() {


    }

    @Test
    public void test() {
        testLogger.info("demo-test()-failure");
        testAssert.assertNull("", "the value is null.");
    }

    @Test
    public void test2() {
        testLogger.info("demo-test2()-success");
        testAssert.assertNull(null, "the value is null.");
    }

    @Test
    public void test3() {
        testLogger.info("demo-test3()-failure");
        testAssert.assertNull("", "the value is null.");
    }

    @Test
    public void test4() {
        testLogger.info("demo-test4()-success");
        testAssert.assertNull(null, "the value is null.");
    }

}
