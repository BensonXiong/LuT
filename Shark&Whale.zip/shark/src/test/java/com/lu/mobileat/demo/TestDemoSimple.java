package com.lu.mobileat.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.*;

/**
 * Created by huangyinhuang on 16/4/7.
 */
public class TestDemoSimple {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @BeforeClass
    public static void beforeClass() {
        System.out.print("demo-beforeClass()");
    }

    @AfterClass
    public static void afterClass() {
        System.out.print("demo-afterClass()");
    }

    @BeforeTest
    public void before() {
        logger.info("demo-before()");
    }

    @AfterTest
    public void after() {
        logger.info("demo-after()");
    }

    @Test
    public void test() {
        logger.info("demo-test()-failure");
        Assert.assertNull("", "the value is null.");
    }

    @Test
    public void test2() {
        logger.info("demo-test2()-success");
        Assert.assertNull(null, "the value is null.");
    }

    @Test
    public void test3() {
        logger.info("demo-test3()-failure");
        Assert.assertNull("", "the value is null.");
    }

    @Test
    public void test4() {
        logger.info("demo-test4()-success");
        Assert.assertNull(null, "the value is null.");
    }
}
