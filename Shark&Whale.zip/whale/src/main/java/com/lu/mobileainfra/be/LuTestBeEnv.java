package com.lu.mobileainfra.be;

import com.google.gson.JsonObject;
import com.lu.mobileafw.be.ILuTestBeEnv;
import com.lu.mobileafw.data.impl.UserParaData;
import com.lu.mobileafw.enumer.LuProductType;
import com.lu.mobileainfra.laf.*;
import com.lufax.laf.biz.domain.NewUserParameters;
import com.lufax.laf.biz.generator.UserGenerator;
import com.lufax.laf.core.config.ConfigManager;
import com.lufax.laf.core.utils.ThreadContextUtil;
import com.lufax.laf.core.utils.lang.StringUtils;
import com.lufax.laf.user.domain.User;
import org.apache.log4j.Logger;
import org.testng.annotations.Test;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisShardInfo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/**
 * Created by huangyinhuang on 16/5/6.
 *
 * 测试环境管理：产品制造，后台数据获取
 *
 */

public class LuTestBeEnv implements ILuTestBeEnv {

    private CaptchaTool captchaTool = new CaptchaTool();
    private SmsTool smsTool = new SmsTool();
    private ProductTool productTool = new ProductTool();
    private BankTool bankTool = new BankTool();
    private GetUser getUser = new GetUser();
    private UserTool userTool = new UserTool();
    public Jedis jedis = null;

    private Logger logger = Logger.getLogger(this.getClass().getName());

    protected UserGenerator userGenerator = new UserGenerator();

    // 清空验证码
    @Override
    public void clearCaptcha(String key) {
        captchaTool.clearCaptCha(key);
//        String redisServer = ConfigManager.getEnvConfigValue("redis.sentinels.url", ThreadContextUtil.getEnv());
//        JedisShardInfo shardInfo = new JedisShardInfo(redisServer.substring(0, redisServer.indexOf(":")), 31000);
//        shardInfo.setPassword("redis1");
//        jedis = new Jedis(shardInfo);
//
//        Set<String> caches = jedis.keys(key + "*");
//
//        Iterator<String> iterator = caches.iterator();
//
//        while (iterator.hasNext()){
//            jedis.del(iterator.next());
//        }
    }


    // 登录验证码
    @Override
    public String getCaptcha() {
        String code = captchaTool.getCaptCha();
        return code;
    }

    // 短信验证码
    @Override
    public String getSms() {
        String msg = smsTool.getOneTimePasswordByLatest();
        return msg;
    }

    // 短信验证码 需手机号
    @Override
    public String getSms(String mobileNum) {
        String msg = smsTool.getOneTimePassword(mobileNum);
        return msg;
    }

    // 检查保险列表
    @Override
    public void scanProductlist() {
        productTool.scanProductList();
    }

    @Override
    public HashMap getProductList() {
        return productTool.getProductMap();
    }

    @Override
    public JsonObject getProuductName(LuProductType type) {
        HashMap productMap = getProductList();

        String productCode = type.getCodeString();
        JsonObject product = (JsonObject) productMap.get(productCode);

        try {

            if (product != null) {
                logger.info("product's info");
                logger.info("id=" + product.get("id").getAsString());
                logger.info("code=" + product.get("code").getAsString());
                logger.info("productCategory=" + product.get("productCategory").getAsString());
                logger.info("displayName=" + product.get("displayName").getAsString());
                logger.info("listType=" + product.get("listType").getAsString());
                logger.info("listTypeName=" + product.get("listTypeName").getAsString());
            }
            else {
                logger.error("product object is null.");
            }

        }catch (Exception e) {
            logger.error("an error is happened when try to print product info.");
        }

        return product;
    }

    //转账激活绑定银行卡
    @Override
    public void activationBankCard(String userName){
        bankTool.activationBankCard(userName);
    }

    //获取零活宝账户
    @Override
    public String getUserNameLingHuoBao(){
        return  getUser.getHuoQiUserNameSql("801");
    }

    //获取智能宝账户
    @Override
    public String getUserNameZhiNengBao(){
        return  getUser.getHuoQiUserNameSql("806");
    }


    //获取富盈宝宝
    @Override
    public String getUserNameFuYinBaoBao(){
        return  getUser.getHuoQiUserNameSql("803");
    }


    //获取基金
    @Override
    public String getUserNameFound(){
        return  getUser.getHuoQiUserNameSql("802");
    }


    //获取彩虹转让
    @Override
    public String getUserNameCaiHongTransfer(){
        return  getUser.getTransferUserNameSql("203");
    }

    //获取安鑫转让
    @Override
    public String getUserNameAnXinTransfer(){
        return  getUser.getTransferUserNameSql("204");
    }


    //获取财富汇转让
    @Override
    public String getUserNameCaiHuHuiTransfer(){
        return  getUser.getTransferUserNameSql("301");
    }

    //获取彩虹变现
    @Override
    public String getUserNameCaiHongCash(){
        return  getUser.getCashUserNameSql("203");
    }

    //获取安鑫变现
    @Override
    public String getUserNameAnXinCash(){
        return  getUser.getCashUserNameSql("204");
    }


    //获取财富汇变现
    @Override
    public String getUserNameCaiHuHuiCash(){
        return  getUser.getCashUserNameSql("301");
    }


    @Override
    public UserParaData getNewUserParameter() {
        return userTool.getUserData();
    }

    @Override
    @Test
    //每次运行生成一个随机用户名和密码
    public String createTestAccount() {

        String userNamePrefix = "uia";
        String loginPwd = "mima123";
        String tradePwd = "pwd123";
        String userRealName = "测试用户";

//        for(int i=0; i<1; i++) {

            String userName = String.format("%s%s", userNamePrefix, StringUtils.getRandomString("0123456789", 10));

            try{

                NewUserParameters newUserParas = new NewUserParameters();
                newUserParas.setUserName(userName);
                newUserParas.setLoginPwd(loginPwd);
                newUserParas.setTradePwd(tradePwd);
//                newUserParas.setRealName(userRealName);
//                newUserParas.setIsSetTradePwd(true);
//                newUserParas.setSetSaveQuestion(true);
//                newUserParas.setIdentityAuth(true);
//                newUserParas.setBindCard(true);

                User p2pUsersDto = userGenerator.generateLufaxUser(newUserParas);

                userName = newUserParas.getUserName();

                logger.info(userName + " is created.");

            }
            catch(Exception e) {
                logger.info("failed to create " + userName);
            }

        return userName;

//        }

    }

}
