package com.lu.mobileainfra.laf;

import com.lufax.laf.base.dao.QaDao;
import com.lufax.laf.core.utils.lang.DataMap;
import com.lufax.laf.entity.dota.acmsdata.AcmsDataDao;
import com.lufax.laf.entity.dota.p2popr.P2pOprDao;
import com.lufax.laf.payment.app.becapitalapp.BeCapitalAppCaller;
import com.lufax.laf.perf.core.utils.MapUtils;
import com.lufax.laf.user.dao.memberdata.MemberDataDao;
import com.lufax.laf.user.dao.memberopr.MemberOprDao;

import java.math.BigDecimal;

/**
 * Created by liuyinping on 16/5/13.
 * 银行卡转账激活
 *
 */
public class BankTool {

    private MemberDataDao memberDataDao = new MemberDataDao();
    private MemberOprDao memberOprDao = new MemberOprDao();
    private P2pOprDao p2pOprDao = new P2pOprDao();
    private AcmsDataDao acmsDataDao = new AcmsDataDao();

    public void activationBankCard(String userName){
        QaDao qaDao = new QaDao();
        String selSql = "select id from p2pusers where username = '" + userName +"'";
        DataMap map = qaDao.fetchOneRow(selSql);
        String userId = map.get("id");
        String AuthAmount1 = memberDataDao.getAuthAmountByUserId(userId).get("AUTH_AMOUNT").get(0);
        String authMount = String.valueOf(new BigDecimal(AuthAmount1).add(new BigDecimal(1)));
        String BankAccountNo = memberDataDao.getAuthAmountByUserId(userId).get("BANK_ACCOUNT").get(0);
        String BankName = memberOprDao.getUserNameByUserId(userId);
        String BankTransactionNo = (int) (Math.random() * 10000) + "-" + (int) (Math.random() * 10000000) + (int) (Math.random() * 1000) + "PHF3N027A";

        p2pOprDao.insertSMEOfflineOpration(authMount, BankName, BankAccountNo, BankTransactionNo);


        BeCapitalAppCaller beCapitalAppCaller = new BeCapitalAppCaller();
        beCapitalAppCaller.triggerJob("offline/matchJob");
        acmsDataDao.commonTriggerJob("s2_qrtz_triggers", "be_capital_jobs_preMatchJob_Trigger");
        p2pOprDao.commonWaitWithAssurance(String.format("select * from sme_offline_operation where status in ('RECHARGING','SUCCESS') and user_id='%s'", userId));
        acmsDataDao.commonTriggerJob("s2_qrtz_triggers", "be_capital_jobs_offlinerecharge_Trigger");
        beCapitalAppCaller.triggerJob("offline/rechargeJob");
        memberDataDao.commonWait("member_bank_bind_auth", MapUtils.buildKeyValueMapStr("STATUS", "SUCCESS", "USER_ID", userId));
        memberDataDao.getAuthAmountByUserId(userId).get("STATUS").get(0);

    }

}
