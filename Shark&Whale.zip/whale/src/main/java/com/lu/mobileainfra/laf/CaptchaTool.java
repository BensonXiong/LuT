package com.lu.mobileainfra.laf;

import com.lufax.laf.core.config.ConfigManager;
import com.lufax.laf.core.utils.ThreadContextUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisShardInfo;

import java.util.Iterator;
import java.util.Set;

/**
 * Created by huangyinhuang on 16/5/6.
 *
 * 验证码
 *
 */

public class CaptchaTool {

    Logger logger = LoggerFactory.getLogger(CaptchaTool.class);

    public Jedis jedis = null;

    public void clearCaptCha(String key) {
        logger.debug("start to clear captcha code");
        String redisServer = ConfigManager.getEnvConfigValue("redis.sentinels.url", ThreadContextUtil.getEnv());
        JedisShardInfo shardInfo = new JedisShardInfo(redisServer.substring(0, redisServer.indexOf(":")), 31000);
        shardInfo.setPassword("redis1");
        jedis = new Jedis(shardInfo);

        Set<String> caches = jedis.keys(key + "*");

        Iterator<String> iterator = caches.iterator();

        while (iterator.hasNext()) {
            jedis.del(iterator.next());
        }

    }

    public String getCaptCha() {
        logger.debug("try to get captcha code");

        String captCha = null;

        Iterator<String> iterator;
        try {

            Set<String> caches = jedis.keys("USER:V1:CAPTCHA*");
            iterator = caches.iterator();
            final String captChaString = jedis.get(iterator.next());

            captCha = captChaString.substring(89, 93);
            System.out.println(captCha);

        } catch (Exception e) {
            logger.error("an exception happened when try to fetch captcha code.", e);
        }

        if (null != jedis) {
            jedis.close();
        }

        return captCha;

    }
}
