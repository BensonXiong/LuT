package com.lu.mobileainfra.laf;

import com.lufax.laf.base.dao.QaDao;
import com.lufax.laf.core.utils.lang.DataMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by liuyinping on 16/5/23.
 *
 * 查询持有产品的账户
 *
 */
public class GetUser {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());


    /**
     * 查询用户名
     * @param selSql
     * @return
     */
    public String  getUser(String selSql){
        QaDao qaDao = new QaDao();
        DataMap map = qaDao.fetchOneRow(selSql);
        String username = map.get("username");
        logger.info("username:"+ username);
        return username;
    }

    /**
     * 活期产品用户名查询语句   灵活宝  富盈宝宝  智能宝  基金
     *
     * 无冻结资金  余额大于1000
     * 可赎回金额大于0
     * 名称以 mobiletest laf  autouser
     *
     * @param product_category  产品码
     * @return
     */
    public String getHuoQiUserNameSql(String product_category){
        String sql = "select us.username from p2pusers us,accounts ac where us.id in \n" +
                "  (select DISTINCT buyer_user_id from product_multiple_trx where product_category = '"+product_category+"' and status='SUCCESS' ) \n" +
                "  and (us.username like 'mobiletest%' or us.username like 'laf%' or us.username like 'autouser%' or us.username like 'jijin%')\n" +
                "  and rownum = 1 \n" +
                "  and ac.BALANCE_AMOUNT >1000\n" +
                "  and ac.FROZEN_AMOUNT =0\n" +
                "  and us.id(+) = ac.user_id\n" +
                "  order by us.id desc";
//        String sql = "select us.username from p2pusers us,accounts ac where \n" +
//                "  us.id in (select b.USER_ID from bus_fund_account b where b.product_category = '"+product_category+"' and b.balance > '0') \n" +
//                "  and us.id in (select DISTINCT buyer_user_id from product_multiple_trx where product_category = '"+product_category+"' and status='SUCCESS' ) \n" +
//                "  and (us.username like 'mobiletest%' or us.username like 'laf%' or us.username like 'autouser%')\n" +
//                "  and rownum = 1 \n" +
//                "  and ac.BALANCE_AMOUNT >1000\n" +
//                "  and ac.FROZEN_AMOUNT =0\n" +
//                "  and us.id(+) = ac.user_id\n" +
//                "  order by us.id desc";

        return getUser(sql);
    }

    /**
     * 查询持有转让的用户  安鑫  彩虹  财富汇
     * @param product_category
     * @return
     */
    public String getTransferUserNameSql(String product_category){
//        String sql = "select username from p2pusers where id in \n" +
//                "  (select i.LOANER_ID from investments i where i.id in \n" +
//                "    (select ip.investment_id from investment_pledge_rule ip where ip.pledge_rule_id in \n" +
//                "      (select id from pledge_rule pr where pr.status = '2'))\n" +
//                "  and i.product_category = '"+ product_category +"' and i.transfer_request_status = 'TRANSFERABLE')\n" +
//                "and (username like 'mobiletest%' or username like 'laf%' or username like 'autouser%')\n" +
//                "and rownum = 1\n" +
//                "order by id desc";
        String sql = "select username from p2pusers where id in \n" +
                "(select i.loaner_id from investments i where i.product_category = '"+ product_category+"' and i.transfer_request_status = 'TRANSFERABLE' \n" +
                "and i.id in (select bt.INVESTMENT_ID from BUS_PART_TRANSFER_REQUESTS bt where status != 'TRANSFER_APPLIED')\n" +
                ")";
        return getUser(sql);
    }

    /**
     * 查询持有变现的用户  安鑫  彩虹  财富汇
     * @param product_category
     * @return
     */
    public String getCashUserNameSql(String product_category){
        String sql = "select username from p2pusers where id in (\n" +
                "select i.LOANER_ID from investments i where i.id in \n" +
                "(select ip.investment_id from investment_pledge_rule ip where ip.pledge_rule_id in (select id from pledge_rule pr where pr.status = '2'))\n" +
                "and i.product_category = '"+ product_category +"' and i.transfer_request_status = 'TRANSFERABLE') " +
                "and username like 'laf%' " +
                "and rownum = 1\n" +
                "order by id desc";
        return getUser(sql);
    }





}

