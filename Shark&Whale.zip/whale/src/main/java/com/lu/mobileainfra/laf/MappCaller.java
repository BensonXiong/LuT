package com.lu.mobileainfra.laf;

import com.google.gson.JsonObject;
import com.lu.mobileafw.utils.EncryptUtils;
import com.lufax.laf.app.mobileapp.MobileAppCaller;
import com.lufax.laf.user.app.userapp.UserAppCaller;
import com.lufax.laf.user.utils.UserUtils;
//import com.lufax.laf.app.userapp.UserAppCaller;
//import com.lufax.laf.app.userapp.UserUtils;
import com.lufax.laf.base.app.BaseServiceCaller;
import com.lufax.laf.biz.Constants;
import com.lufax.laf.core.config.AppConfigUtil;
import com.lufax.laf.core.config.ConfigManager;
import com.lufax.laf.core.http.InterfaceCallObject;
import com.lufax.laf.core.utils.json.JsonHelper;
import com.lufax.laf.entity.dota.p2popr.P2pUsersDto;


import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by youlingfei on 15/8/11.
 */

@Component
public class MappCaller extends BaseServiceCaller {



    @Override
    protected String getHostUriFromConfig(String env) {
        return ConfigManager.getEnvConfigValue("mapp.web.host.url", env);
    }


    private final String VERSION = "3.2.9";

    private final String PUBLIC = "public";
    private final String PUBLIC_V2 = "v2/public";

    private final String PRIVATE = "private";
    private final String PRIVATE_V2 = "v2/private";



    /**
     * 登录
     */
    public String Login(String requestCode, String params,String cookie){
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .withHeader("Cookie", cookie)
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", VERSION)
                .addFormValue("params", params)
                .withUrl(PUBLIC);
        return post(interfaceCallObject, null, null, "1");
    }

    public static JsonObject mappLogin(String userName){
        MappCaller MappCaller = new MappCaller();
        UserAppCaller uac = new UserAppCaller();
        JsonObject res = new JsonObject();
        String cookie = "";

        String requestCode = "M8001";
        String params = "";
        String ePassword = UserUtils.getEncryptedPwd(Constants.defaultLoginPwd);
        String vcode = UserUtils.generateVcode();
        String imageId = UserUtils.generateImageId();
        String ipAddress = "127.0.0.1";
        String source = "0";//weblogin 0
        uac.saveCaptcha(vcode, ipAddress, source, imageId);
        params = "{\"userNameLogin\":"+ userName + ",\"password\":" + ePassword +
                ",\"validNum\":"+ vcode +",\"from\":\"app\",\"mobileSerial\":\"iphoneSimulatortokenteststring\"}";

        cookie = MappCaller.Login(requestCode, params, MappConstant.LOGINCOOKIE+imageId);

        String iMVC = MappConstant.LOGINCOOKIE+imageId + ";";

        cookie = cookie + iMVC ;
        res = getSignature(userName);

        res.addProperty("cookie", cookie);

        return res;


    }

    public static JsonObject getSignature(String userName){
        JsonObject res = new JsonObject();
        P2pUsersDto user = new P2pUsersDto("",userName);
        String mobileTime = "";
        String mobileSignature = "";
        MobileAppCaller mobileAppCaller = new MobileAppCaller();
        JsonObject signAlgor = mobileAppCaller.getSignAlgor();
        JsonObject SynTime = mobileAppCaller.getSynchronizeTime();
        String time = (System.currentTimeMillis()) + "";
        String signature = "{\"userId\":" + user.getId() + ",\"_t\":" + time + "}";
        mobileTime = time;
        mobileSignature = EncryptUtils.signature(signature, signAlgor.get("type").getAsString());

        res.addProperty("mobileTime", mobileTime);
        res.addProperty("mobileSignature", mobileSignature);

        return res;

    }

    /**
     * post public
     */
    public JsonObject postPublic(String requestCode, String params){
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", VERSION)
                .addFormValue("params", params)
                .withUrl(PUBLIC);
        return post(interfaceCallObject).getAsJsonObject();
    }


    public JsonObject postPublic(String requestCode, String params, String version){
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", version)
                .addFormValue("params", params)
                .withUrl(PUBLIC);
        return post(interfaceCallObject).getAsJsonObject();
    }
    public JsonObject postPublicMobileAgent(String requestCode, String params, String version){
        version = VERSION;
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .withHeader(MappConstant.MOBILE_AGENT, "appVersion:"+version+",platform:android,osVersion:19,device:MI NOTE LTE,resourceVersion:2.7.0,channel:XIAOMIAPP")
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", version)
                .addFormValue("params", params)
                .withUrl(PUBLIC);
        return post(interfaceCallObject).getAsJsonObject();
    }

    public JsonObject postPublicV2(String requestCode, String params, String version){
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", version)
                .addFormValue("params", params)
                .withUrl(PUBLIC_V2);
        return post(interfaceCallObject).getAsJsonObject();
    }

    public JsonObject postPublicCookie(String requestCode, String params, String cookie, String mobileTime, String mobileSignature) {
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .withHeader(MappConstant.X_LUFAX_MOBILE_T, mobileTime)
                .withHeader(MappConstant.X_LUFAX_MOBILE_SIGNATURE, mobileSignature)
                .withHeader("Cookie", cookie)
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", VERSION)
                .addFormValue("params", params)
                .withUrl(PUBLIC);
        return post(interfaceCallObject).getAsJsonObject();
    }

    public JsonObject postPublicWithLogin(String requestCode, String params, String cookie, String mobileTime, String mobileSignature){
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .withHeader(MappConstant.MOBILE_AGENT, "appVersion:"+VERSION+",platform:android,osVersion:19,device:MI NOTE LTE,resourceVersion:2.7.0,channel:XIAOMIAPP")
                .withHeader(MappConstant.X_LUFAX_MOBILE_T, mobileTime)
                .withHeader(MappConstant.X_LUFAX_MOBILE_SIGNATURE, mobileSignature)
                .withHeader("Cookie", cookie)
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", VERSION)
                .addFormValue("params", params)
                .withUrl(PUBLIC);
        return post(interfaceCallObject).getAsJsonObject();
    }

    public JsonObject postPublicMobileAgentAndCookie(String requestCode, String params, String version, String cookie, String mobileTime, String mobileSignature){
        version = VERSION;
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .withHeader(MappConstant.MOBILE_AGENT, "appVersion:"+version+",platform:android,osVersion:19,device:MI NOTE LTE,resourceVersion:2.7.0,channel:XIAOMIAPP")
                .withHeader(MappConstant.X_LUFAX_MOBILE_T, mobileTime)
                .withHeader(MappConstant.X_LUFAX_MOBILE_SIGNATURE, mobileSignature)
                .withHeader("Cookie", cookie)
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", VERSION)
                .addFormValue("params", params)
                .withUrl(PUBLIC);
        return post(interfaceCallObject).getAsJsonObject();
    }


    /**
     * private
     */


    public JsonObject postPrivate(String requestCode, String params,String cookie){
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .withHeader("Cookie", cookie)
                .withHeader("Cookie", cookie)
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", VERSION)
                .addFormValue("params", params)
                .withUrl(PRIVATE);
        return post(interfaceCallObject).getAsJsonObject();
    }

    public JsonObject postPrivate(String requestCode, String params,String cookie, String mobileTime, String mobileSignature){
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .withHeader(MappConstant.MOBILE_AGENT, "appVersion:" + VERSION + ",platform:android,osVersion:19,device:MI NOTE LTE,resourceVersion:2.7.0,channel:XIAOMIAPP")
                .withHeader(MappConstant.X_LUFAX_MOBILE_T, mobileTime)
                .withHeader(MappConstant.X_LUFAX_MOBILE_SIGNATURE, mobileSignature)
                .withHeader("Cookie", cookie)
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", VERSION)
                .addFormValue("params", params)
                .withUrl(PRIVATE);
        return post(interfaceCallObject).getAsJsonObject();
    }

    public JsonObject postPrivateMobilAgent(String requestCode, String params,String cookie, String mobileTime, String mobileSignature){
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .withHeader(MappConstant.MOBILE_AGENT, "appVersion:"+VERSION+",platform:android,osVersion:19,device:MI NOTE LTE,resourceVersion:2.7.0,channel:XIAOMIAPP")
                .withHeader(MappConstant.X_LUFAX_MOBILE_T, mobileTime)
                .withHeader(MappConstant.X_LUFAX_MOBILE_SIGNATURE, mobileSignature)
                .withHeader("Cookie", cookie)
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", VERSION)
                .addFormValue("params", params)
                .withUrl(PRIVATE);

        return post(interfaceCallObject).getAsJsonObject();
    }

    public JsonObject postPrivateV2(String requestCode, String params,String cookie, String mobileTime, String mobileSignature){
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .withHeader(MappConstant.X_LUFAX_MOBILE_T, mobileTime)
                .withHeader(MappConstant.X_LUFAX_MOBILE_SIGNATURE, mobileSignature)
                .withHeader("Cookie", cookie)
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", VERSION)
                .addFormValue("params", params)
                .withUrl(PRIVATE_V2);
        return post(interfaceCallObject).getAsJsonObject();
    }

    public JsonObject postPrivateV2MobileAgent(String requestCode, String params,String cookie, String mobileTime, String mobileSignature, String appVersion){
        InterfaceCallObject interfaceCallObject = new InterfaceCallObject()
                .withHeader(MappConstant.X_LUFAX_MOBILE_T, mobileTime)
                .withHeader(MappConstant.X_LUFAX_MOBILE_SIGNATURE, mobileSignature)
                .withHeader(MappConstant.MOBILE_AGENT, "appVersion:" + appVersion)
                .withHeader("Cookie", cookie)
                .addFormValue("requestCode", requestCode)
                .addFormValue("version", VERSION)
                .addFormValue("params", params)
                .withUrl(PRIVATE_V2);
        return post(interfaceCallObject).getAsJsonObject();
    }

    /**
     * 设置基金服务
     * 设置平安付
     *
     */
    public static void jiJinEnvConfig() throws UnknownHostException {
        String PAFHostServerURL = "";
        String YFDHostServerURL = "";
        String LFXHostServerURL = "";
        String HTFHostServerURL = "";

        String PAF_JIJIN_HOST_URL = "http://%s/ffastpay";
        String PAF_JIJIN_MERCHANT_KEY = "03faabef8bf0405bbf6c3115b64c27a8";

        String JIJIN_YFD101_HOST_URL = "http://%s/webtrade";
        String JIJIN_YFD101_PUBLIC_KEY = "MIIBIDANBgkqhkiG9w0BAQEFAAOCAQ0AMIIBCAKCAQEAxNbUau4aGXnU3kftAglIHURB65seWJedh/A7UHqWZnlhcRXNIsIX7eu8IojtdbEO6Qm7OSdhgyTL2/M+VfsiFkm0+L1ieLTFevoOrD4sNosXs76XJw5oQ2KYEpiPRJU1wVWBtWwm7h/uwQWa7FrjG+JvJdYmcMAvaPuTQOgQubyswXPmJxT5wHr8R6GBGA8AjVk0rAORUBjWkxNmYSMpj6g8FoNE2Dp1YQPZtD56km3uN5Ok0w2J3iTor1KTOBI373/wIPwXS7j96ie7s1KyY2zCmC5wY5Vcm7PI0Qn6gVBvPqTZzXSxaJTCW0Rw4P4g7SIdV49Y1FdnJcWt1I8oWwIBAw==";

        String JIJIN_LFX201_HOST_URL = "http://%s/fund_front/service/receiveRequestData";
        String JIJIN_LFX201_PUBLIC_KEY = "MIIBIDANBgkqhkiG9w0BAQEFAAOCAQ0AMIIBCAKCAQEAxNbUau4aGXnU3kftAglIHURB65seWJedh/A7UHqWZnlhcRXNIsIX7eu8IojtdbEO6Qm7OSdhgyTL2/M+VfsiFkm0+L1ieLTFevoOrD4sNosXs76XJw5oQ2KYEpiPRJU1wVWBtWwm7h/uwQWa7FrjG+JvJdYmcMAvaPuTQOgQubyswXPmJxT5wHr8R6GBGA8AjVk0rAORUBjWkxNmYSMpj6g8FoNE2Dp1YQPZtD56km3uN5Ok0w2J3iTor1KTOBI373/wIPwXS7j96ie7s1KyY2zCmC5wY5Vcm7PI0Qn6gVBvPqTZzXSxaJTCW0Rw4P4g7SIdV49Y1FdnJcWt1I8oWwIBAw==";

        String JIJIN_HTF102_HOST_URL = "http://%s/hop/lufax";
        String JIJIN_HTF102_PUBLIC_KEY = "MIIBIDANBgkqhkiG9w0BAQEFAAOCAQ0AMIIBCAKCAQEAxNbUau4aGXnU3kftAglIHURB65seWJedh/A7UHqWZnlhcRXNIsIX7eu8IojtdbEO6Qm7OSdhgyTL2/M+VfsiFkm0+L1ieLTFevoOrD4sNosXs76XJw5oQ2KYEpiPRJU1wVWBtWwm7h/uwQWa7FrjG+JvJdYmcMAvaPuTQOgQubyswXPmJxT5wHr8R6GBGA8AjVk0rAORUBjWkxNmYSMpj6g8FoNE2Dp1YQPZtD56km3uN5Ok0w2J3iTor1KTOBI373/wIPwXS7j96ie7s1KyY2zCmC5wY5Vcm7PI0Qn6gVBvPqTZzXSxaJTCW0Rw4P4g7SIdV49Y1FdnJcWt1I8oWwIBAw==";

        String ip = InetAddress.getLocalHost().getHostAddress();
//        String ip = "172.19.16.29";
        ip = String.format("%s:%s", ip, ConfigManager.getConfigValue("mock.httpServlet.port"));
        PAFHostServerURL = String.format(PAF_JIJIN_HOST_URL, ip);
        YFDHostServerURL = String.format(JIJIN_YFD101_HOST_URL, ip);
        LFXHostServerURL = String.format(JIJIN_LFX201_HOST_URL, ip);
        HTFHostServerURL = String.format(JIJIN_HTF102_HOST_URL, ip);


        AppConfigUtil appConfigUtil = new AppConfigUtil();
        Map<String,Object> keyvalus = new HashMap<String, Object>();
        keyvalus.put("PAF_JIJIN_HOST_URL", PAFHostServerURL);
        keyvalus.put("PAF_JIJIN_MERCHANT_KEY",PAF_JIJIN_MERCHANT_KEY);
        String params = JsonHelper.buildMapToJsonString(keyvalus);
        appConfigUtil.setAppEnvConfig("gwpaf-gw",params);

        appConfigUtil = new AppConfigUtil();
        keyvalus = new HashMap<String, Object>();
        keyvalus.put("JIJIN_HTF102_HOST_URL", HTFHostServerURL);
        keyvalus.put("JIJIN_HTF102_PUBLIC_KEY",JIJIN_HTF102_PUBLIC_KEY);
        params = JsonHelper.buildMapToJsonString(keyvalus);
        appConfigUtil.setAppEnvConfig("jijin-gw",params);

        appConfigUtil = new AppConfigUtil();
        keyvalus = new HashMap<String, Object>();
        keyvalus.put("JIJIN_YFD101_HOST_URL", YFDHostServerURL);
        keyvalus.put("JIJIN_YFD101_PUBLIC_KEY",JIJIN_YFD101_PUBLIC_KEY);
        params = JsonHelper.buildMapToJsonString(keyvalus);
        appConfigUtil.setAppEnvConfig("jijin-gw",params);

        appConfigUtil = new AppConfigUtil();
        keyvalus = new HashMap<String, Object>();
        keyvalus.put("JIJIN_LFX201_HOST_URL", LFXHostServerURL);
        keyvalus.put("JIJIN_LFX201_PUBLIC_KEY",JIJIN_LFX201_PUBLIC_KEY);
        params = JsonHelper.buildMapToJsonString(keyvalus);
        appConfigUtil.setAppEnvConfig("jijin-gw",params);
    }

    /**
     * 修改私募基金的mock配置
     */
    public static void peEnvConfig() throws UnknownHostException{
        //获取本机ip
        String ip = InetAddress.getLocalHost().getHostAddress();
        ip = String.format("%s:%s", ip, ConfigManager.getConfigValue("mock.httpServlet.port"));
        String B_SYSTEM_HOST_URL = String.format("http://%s/service",ip);
        //修改远端mock ip指向
        AppConfigUtil appConfigUtil = new AppConfigUtil();
        appConfigUtil = new AppConfigUtil();
        Map<String,Object> keyvalus = new HashMap<String, Object>();
        keyvalus = new HashMap<String, Object>();
        keyvalus.put("B_SYSTEM_HOST_URL", B_SYSTEM_HOST_URL);
        String params = JsonHelper.buildMapToJsonString(keyvalus);
        appConfigUtil.setAppEnvConfig("operation-gw",params);
    }
}
