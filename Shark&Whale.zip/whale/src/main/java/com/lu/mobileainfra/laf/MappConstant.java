package com.lu.mobileainfra.laf;

/**
 * Created by youlingfei on 16/3/18.
 */

public class MappConstant {
    public static final String X_LUFAX_MOBILE_T ="x-lufax-mobile-t";
    public static final String X_LUFAX_MOBILE_SIGNATURE ="x-lufax-mobile-signature";
    public static final String MOBILE_AGENT ="mobile_agent";
    public static final String LOGINCOOKIE = "_g=dec5fbc4-f754-406c-b82c-9eee6fc2fe0b; _g2=3734b0c8-dfdd-45eb-8f96-ccd3dcb8d675; IMVC=";
    public static final String USERID = "591250";
    public static final String USERNAME = "'jijin1";
    public static final String PASSWORD = "password001";
    public static final String TRADEPASSWORD = "pwd123";
    public static final String PRODUCTID = "12359251";
}
