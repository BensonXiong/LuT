package com.lu.mobileainfra.laf;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.lufax.laf.entity.dota.p2popr.P2pUsersDto;
import com.lufax.laf.user.app.userapp.UserGroup;
import com.lufax.laf.user.dao.memberdata.TUserGroupRelationDto;
import com.lufax.laf.user.dao.memberopr.MemberOprDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Iterator;

/**
 * Created by huangyinhuang on 16/5/9.
 *
 * 测试产品列表
 *
 */

public class ProductTool {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    //@Autowired
    private MemberOprDao memberOprDao;

    //@Autowired
    private MappCaller mAppCaller;

    private HashMap productMap;

    public ProductTool() {
        memberOprDao = new MemberOprDao();
        mAppCaller = new MappCaller();
        productMap = new HashMap();
    }

    public void scanProductList() {

        String isForNewUser = "true";
        String version = "3.2.7";


        // 获取产品列表 － 定期保险
        try{

            // 实名用户
            TUserGroupRelationDto tUserGroupRelationDto = memberOprDao.getLastUserGroupRelationByGroup(UserGroup.DEFAULT);
            Long userId = tUserGroupRelationDto.getUserId();
            P2pUsersDto p2pUser = new P2pUsersDto(userId.toString(), "");
            String userName = p2pUser.getUsername();
            JsonObject loginRes = mAppCaller.mappLogin(userName);

            String mobileTime = loginRes.get("mobileTime").getAsString();
            String mobileSignature = loginRes.get("mobileSignature").getAsString();
            String cookie = loginRes.get("cookie").getAsString();

            // 发送请求
            String paramsM3024 = "{\"listType\":\"fixed\",\"currentPage\":\"1\",\"pageIndex\":\"1\",\"pageSize\":\"1000\",\"isForNewUser\":\"" + isForNewUser + "\",\"ver\":\"1\",\"source\":\"android\",\"productCategory\":\"INSURANCE\"}";
            JsonObject resM3024_list = mAppCaller.postPublicMobileAgentAndCookie("M3024", paramsM3024, version, cookie, mobileTime, mobileSignature);

            JsonObject result = resM3024_list.getAsJsonObject("result");
            JsonArray products = result.getAsJsonArray("products");
            JsonArray productList = products.get(0).getAsJsonObject().getAsJsonArray("productList");
            Iterator it = productList.iterator();

            Integer prdIndex = 1;
            while(it.hasNext()) {

                JsonElement ele = (JsonElement) it.next();
                JsonObject product = ele.getAsJsonObject();
                String productCategoryCode = product.get("productCategory").getAsString();

                try {
                    logger.debug("");
                    logger.debug("---prdIndex[" + prdIndex + "]---");
                    logger.debug("id=" + product.get("id").getAsString());
                    logger.debug("code=" + product.get("code").getAsString());
                    logger.debug("productCategory=" + product.get("productCategory").getAsString());
                    logger.debug("displayName=" + product.get("displayName").getAsString());
                    logger.debug("listType=" + product.get("listType").getAsString());
                    logger.debug("listTypeName=" + product.get("listTypeName").getAsString());
                    logger.debug("");
                } catch (Exception ex) {
                    logger.debug("An exception is happened when printing product information", ex);
                }

                // 一个产品类别获取一个产品，用于后续测试
                if( !productMap.containsKey(productCategoryCode) ) {
                    logger.debug("add one product into list, type=" + productCategoryCode);
                    productMap.put(productCategoryCode, product);
                }else{
                    logger.debug("one product of same type is existed in the list already, type=" + productCategoryCode);
                }

                prdIndex++;

            }

        }catch (Exception ex) {
            logger.debug("An exception is happened when fetching product list", ex);
        }


    }

    public HashMap getProductMap() {
        return productMap;
    }
}
