package com.lu.mobileainfra.laf;

import com.lufax.laf.base.dao.QaDao;
import com.lufax.laf.core.utils.lang.DataMap;

/**
 * Created by huangyinhuang on 16/5/6.
 *
 * 短信动态码
 *
 */


public class SmsTool {

    //短信动态码获取方法
    //通过手机号码 qaDao.commonSelectOneRow("one_time_password","rownum =1 order by id desc");
    //最新 qaDao.commonSelectOneRow(String.format("select OTP_CODE from one_time_password  where MOBILE_NO='%s' order by id desc","12998230720"));

    //从数据库查询验证码,并输入到文本框
//        QaDao qaDao = new QaDao();
//        String selSql = "select otp_code from one_time_password where  MOBILE_NO = '" + mobileNo + "' and rownum=1 order by id desc";
//        DataMap map = qaDao.fetchOneRow(selSql);
//        System.out.println(map.get("otp_code"));
//        registerPage.InputTextDyncode(map.get("otp_code"));

    public String getOneTimePasswordByLatest() {

        QaDao qaDao = new QaDao();
        String selSql = "select otp_code from one_time_password where rownum=1 order by id desc";
        DataMap map = qaDao.fetchOneRow(selSql);
        return map.get("otp_code");

    }

    public String getOneTimePassword(String mobilenum) {

        QaDao qaDao = new QaDao();
        String selSql = String.format("select otp_code from one_time_password  where MOBILE_NO='%s' and rownum=1 order by id desc", mobilenum);
        DataMap map = qaDao.fetchOneRow(selSql);
        return map.get("otp_code");

    }


}
