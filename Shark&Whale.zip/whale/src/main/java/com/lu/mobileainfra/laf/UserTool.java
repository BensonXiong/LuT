package com.lu.mobileainfra.laf;

import com.lu.mobileafw.data.impl.UserParaData;
import com.lufax.laf.biz.domain.NewUserParameters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;

/**
 * Created by huangyinhuang on 16/5/25.
 */
public class UserTool {

    Logger logger = LoggerFactory.getLogger(UserTool.class);

    public UserParaData getUserData() {

        // 获取新用户账号
        UserParaData userData = new UserParaData();

        NewUserParameters newUserParameters = new NewUserParameters();
        BeanUtils.copyProperties(newUserParameters, userData);

        logger.debug("user name: " + userData.getUserName());
        logger.debug("user password: " + userData.getLoginPwd());
        logger.debug("user phoneNo: " + userData.getMobileNo());
        logger.debug("user real name: " + userData.getRealName());
        logger.debug("user card number: " + userData.getCardNo());
        logger.debug("user bank: " + userData.getBank());
        logger.debug("user bank code: " + userData.getBankCode());
        logger.debug("user birthday: " + userData.getBirthDay());
        logger.debug("user answer: " + userData.getAnswer());
        logger.debug("user credential: " + userData.getCredentialsNo());
        logger.debug("user ip address: " + userData.getIpAddress());
        logger.debug("user market cookie: " + userData.getMarketCookie());

        return userData;

    }



}
