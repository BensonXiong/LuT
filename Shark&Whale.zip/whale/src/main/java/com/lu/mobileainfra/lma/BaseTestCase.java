package com.lu.mobileainfra.lma;

import com.lu.mobileafw.BaseTestCaseAbstract;
import com.lu.mobileafw.be.ILuTestBeEnv;
import com.lu.mobileainfra.be.LuTestBeEnv;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by huangyinhuang on 16/6/21.
 */
public class BaseTestCase extends BaseTestCaseAbstract {

    private Logger logger = LoggerFactory.getLogger(BaseTestCase.class);

    @Override
    public ILuTestBeEnv getBeEnvironment() {

        testBeEnv = new LuTestBeEnv();
        return testBeEnv;

    }

}
