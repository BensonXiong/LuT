package com.lu.mobileaui.android;

import com.lu.mobileafw.BasePageAbstract;

import static com.lu.mobileafw.app.TestHelper.*;

/**
 * Created by huangyinhuang on 16/3/14.
 *
 * app 登录页
 *
 */


public class AdLoginPage extends BasePageAbstract {

    private String id_close_btn = "title_bar_left_tv";
    private String id_register_new_account = "title_bar_right_tv";

    private String id_login_name = "et_loginname";
    private String id_login_pwd = "et_loginpswd";
    private String id_login_btn = "btn_login";

    private String id_verify_code = "et_loginvalidator";
    private String id_refresh_code = "com.lufax.android:id/iv_validator";

    private String id_retrieve_account = "btn_register_username_retrieve";
    private String id_retrieve_pwd = "btn_register_pwd_retrieve";

    public void fillUserName(String username) {
        logger.info("fill the user name");
        waitFor(for_id(id_login_name)).clear();
        element(for_id(id_login_name)).sendKeys(username);
    }

    public void fillUserPassword(String password) {
        logger.info("fill the user password");
        waitFor(for_id(id_login_pwd)).clear();
        element(for_id(id_login_pwd)).sendKeys(password);
    }

    public void fillVerifyCode(String code) {
        logger.info("fill the verify code");
        waitFor(for_id(id_verify_code)).clear();
        element(for_id(id_verify_code)).sendKeys(code);
    }

    public void refreshCode() {
        logger.info("click the code image and refresh the code");
        waitFor(for_id(id_refresh_code)).click();
    }

    public void clickLoginButton() {
        logger.info("click the login button");
        waitFor(for_id(id_login_btn)).click();
    }

    public void clickCloseButton() {
        logger.info("click close button");
        waitFor(for_id(id_close_btn)).click();
    }

    public void clickRegisterNewAccount() {
        logger.info("select register new account option");
        waitFor(for_id(id_register_new_account)).click();
    }

    public void clickRetrieveAccount() {
        logger.info("select retrieve account option");
        waitFor(for_id(id_retrieve_account)).click();
    }

    public void checkAndFillVerifyCode() {

        Boolean bExist = checkExist(for_id(id_verify_code));

        if(bExist){
            testBeEnv.clearCaptcha("USER:V1:CAPTCHA");
            this.refreshCode();
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            String code = testBeEnv.getCaptcha();
            logger.info("code = " + code);
            this.fillVerifyCode(code);
        }
        else{
            logger.info("this test run doesn't require verify code.");
        }

    }

    public void loginApp()  {
        this.fillUserName("mobileuitest1");
        this.fillUserPassword("mima123");
        this.checkAndFillVerifyCode();
        this.clickLoginButton();
    }


}
