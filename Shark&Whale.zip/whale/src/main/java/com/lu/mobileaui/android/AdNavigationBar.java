package com.lu.mobileaui.android;

import com.lu.mobileafw.BasePageAbstract;
import org.apache.log4j.Logger;

import static com.lu.mobileafw.app.TestHelper.for_id;
import static com.lu.mobileafw.app.TestHelper.waitFor;

/**
 * Created by huangyinhuang on 16/3/14.
 *
 * app 导航栏
 *
 */

public class AdNavigationBar extends BasePageAbstract {

    public AdNavigationBar() {
    }

    protected Logger logger = Logger.getLogger(this.getClass().getName());

    private String id_home_button = "com.lufax.android:id/layout_bottombar1";
    private String id_investment_button = "com.lufax.android:id/layout_bottombar2";
    private String id_vipclub_button = "com.lufax.android:id/layout_bottombar5";
    private String id_myaccount_button = "com.lufax.android:id/layout_bottombar3";
    private String id_more_button = "com.lufax.android:id/layout_bottombar4";

    public void clickHomeButton() {
        logger.info("click the home button");
        waitFor(for_id(id_home_button)).click();
    }

    public void clickInvestmentButton() {
        logger.info("click investment button");
        waitFor(for_id(id_investment_button)).click();
    }

    public void clickVipClubButton() {
        logger.info("click the vipclub button");
        waitFor(for_id(id_vipclub_button)).click();
    }

    public void clickMyAccountButton()  {
        logger.info("click the my account button");
        waitFor(for_id(id_myaccount_button)).click();
    }

    public void clickMoreButton() {
        logger.info("click the more button");
        waitFor(for_id(id_more_button)).click();
    }

}