package com.lu.mobileaui.android;

import com.lu.mobileafw.app.TestHelper;
import com.lu.mobileafw.BasePageAbstract;

import static com.lu.mobileafw.app.TestHelper.*;

/**
 * Created by huangyinhuang on 16/3/14.
 *
 * app 启动页
 *
 */


public class AdStartPage extends BasePageAbstract {

    private String id_welcome_page = "com.lufax.android:id/welcome_pager";
    private String id_start_btn = "com.lufax.android:id/start_button";
    private String id_bottom_layout = "com.lufax.android:id/bottom_layout";


    public void SwipeStartupPage() {

        waitFor(for_id(id_welcome_page));

        logger.info("swipe the page");
        int width= TestHelper.driver.manage().window().getSize().width;
        int height= TestHelper.driver.manage().window().getSize().height;
        TestHelper.driver.swipe(width - 1, height / 2, 1, height / 2, 1000);
        TestHelper.driver.swipe(width - 1, height / 2, 1, height / 2, 1000);

        logger.info("click the start button");
        waitFor(for_id(id_start_btn)).click();

        logger.info("click the bottom button");
        waitFor(for_find(id_bottom_layout)).click();

    }

}
