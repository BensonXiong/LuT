package com.lu.mobileaui.android.home;

import com.lu.mobileafw.BasePageAbstract;


import static com.lu.mobileafw.app.TestHelper.*;

/**
 * Created by huangyinhuang on 16/3/14.
 *
 * 首页列表页
 *
 */

public class AdHomePage extends BasePageAbstract {

    private String id_login_button = "title_bar_right_tv";

    public void clickLoginButton() {
        waitFor(for_id(id_login_button)).click();
    }

}
