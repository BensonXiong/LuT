package com.lu.mobileaui.android.invest;

import com.lu.mobileafw.BasePageAbstract;

import static com.lu.mobileafw.app.TestHelper.for_id;
import static com.lu.mobileafw.app.TestHelper.waitFor;

/**
 * Created by huangyinhuang on 16/3/16.
 *
 * 投资理财页 -> 现金管理页
 *
 */


public class AdCashManagementPage extends BasePageAbstract {

    private String id_product = "com.lufax.android:id/product_name";
    private String id_withdraw_anytime = "随时提取";

    public void clickProudct() {
        logger.info("select the first product in the list");
        waitFor(for_id(id_product)).click();
    }
}
