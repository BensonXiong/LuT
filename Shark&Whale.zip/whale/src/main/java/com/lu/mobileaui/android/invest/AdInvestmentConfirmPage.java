package com.lu.mobileaui.android.invest;

import com.lu.mobileafw.BasePageAbstract;

import static com.lu.mobileafw.app.TestHelper.*;

/**
 * Created by huangyinhuang on 16/3/17.
 *
 * 投资理财页 -> 现金管理页 -> 项目详情页 -> 投资页
 *
 */

public class AdInvestmentConfirmPage extends BasePageAbstract {

    // 确认风险合约
    private String id_check_agreement = "com.lufax.android:id/chkEnable";
    private String id_invest_option = "com.lufax.android:id/btn_invest";

    // 交易
    private String id_trade_password = "com.lufax.android:id/pwPlaceHodler";
    private String id_confirm_btn = "com.lufax.android:id/confirmButton";

    public void confirmAgreement() {
        waitFor(for_id(id_check_agreement)).click();
        //scroll_to(id_invest_option);
        waitFor(for_id(id_invest_option)).click();
    }

    public void confirmTrade() {
        waitFor(for_id(id_trade_password)).clear();
        element(for_id(id_trade_password)).sendKeys("pwd123");

        waitFor(for_id(id_confirm_btn)).click();
    }

}
