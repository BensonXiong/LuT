package com.lu.mobileaui.android.invest;

import com.lu.mobileafw.BasePageAbstract;

import static com.lu.mobileafw.app.TestHelper.for_text;
import static com.lu.mobileafw.app.TestHelper.waitFor;

/**
 * Created by huangyinhuang on 16/3/16.
 *
 * 投资理财首页
 *
 */


public class AdInvestmentPage extends BasePageAbstract {

    private String text_new_customer_zone = "新客专区";
    private String text_cash_management = "现金管理";

    public void clickNewCustomerZone() {
        logger.info("select the new customer zone option");
        waitFor(for_text(text_new_customer_zone)).click();
    }

    public void clickCashManagement() {
        logger.info("click the cash management option");
        waitFor(for_text(text_cash_management)).click();
    }

}
