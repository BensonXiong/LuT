package com.lu.mobileaui.android.invest;

import com.lu.mobileafw.BasePageAbstract;

import static com.lu.mobileafw.app.TestHelper.for_id;
import static com.lu.mobileafw.app.TestHelper.waitFor;

/**
 * Created by huangyinhuang on 16/3/17.
 *
 * 投资理财页 -> 现金管理页 -> 项目详情页 -> 投资页 -> 投资申请已提交页（最后提示页）
 *
 */

public class AdLastPromptPaget extends BasePageAbstract {

    // 浏览其它项目
    private String id_view_other_product_btn = "com.lufax.android:id/to_other_product_btn";

    // 查看详情
    private String id_details_btn = "com.lufax.android:id/to_details_btn";

    // 完成
    private String id_complete_btn = "com.lufax.android:id/title_bar_right_tv";

    public void clickDetailsButton() {
        waitFor(for_id(id_details_btn)).click();
    }

}
