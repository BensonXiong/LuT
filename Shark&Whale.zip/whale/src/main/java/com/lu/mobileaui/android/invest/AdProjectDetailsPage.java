package com.lu.mobileaui.android.invest;

import com.lu.mobileafw.BasePageAbstract;

import static com.lu.mobileafw.app.TestHelper.*;

/**
 * Created by huangyinhuang on 16/3/16.
 *
 * 投资理财页 -> 现金管理页 -> 项目详情页
 *
 */

public class AdProjectDetailsPage extends BasePageAbstract {

    private String id_investment_amount = "com.lufax.android:id/etPrice";
    private String id_ok_button = "com.lufax.android:id/btnAction";
    private String id_investment_amount2 = "com.lufax.android:id/input_etPrice";
    private String id_ok_button2 = "com.lufax.android:id/input_btnAction";
    private String id_freshguide = "com.lufax.android:id/reserverd_freshguide_bottom";

    private String text_investment_scheduled = "定期投资";
    private String text_investment_now = "立即投资";


    public void fillPrice(Integer price) {
        logger.info("fill price");
        waitFor(for_id(id_investment_amount)).clear();
        //element(for_id(id_investment_amount)).sendKeys(price.toString());
    }

    public void clickOkButton() {
        logger.info("click the confirm button for the investment");
        waitFor(for_text(id_ok_button)).click();
    }

    public void fillPrice2(Integer price) {
        logger.info("fill price");
        waitFor(for_id(id_investment_amount2)).clear();
        element(for_id(id_investment_amount2)).sendKeys(price.toString());
    }

    public void clickOkButton2() {
        logger.info("click the confirm button for the investment");
        waitFor(for_id(id_ok_button2)).click();
    }

    public void clickFreshGuide() {
        waitFor(for_id(id_freshguide)).click();
    }

    public void clickInvestmentNow() {
        //waitFor(for_text(text_investment_now)).click();
        waitFor(for_name(text_investment_now)).click();
    }

}
