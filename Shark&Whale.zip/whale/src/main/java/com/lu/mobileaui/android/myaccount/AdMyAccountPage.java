package com.lu.mobileaui.android.myaccount;

import com.lu.mobileafw.BasePageAbstract;
import org.openqa.selenium.WebElement;

import static com.lu.mobileafw.app.TestHelper.for_id;
import static com.lu.mobileafw.app.TestHelper.waitFor;

/**
 * Created by feiyong on 16/3/16.
 *
 * 我的账号首页
 *
 */

public class AdMyAccountPage extends BasePageAbstract {

    // 我的消息
    private String id_my_message_btn = "title_bar_left_tv";

    // 账户名字
    private String id_account_Name = "title_bar_title_tv";

    // 安全退出
    private String id_quit_btn = "title_bar_right_tv";

    // 引导页
    private String id_freshguide_pre_btn = "account_freshguide_pre_btn";
    private String id_freshguide_next_btn = "account_freshguide_next_btn";

    // 取现
    private String id_withdraw_btn = "account_assest_withdraw";

    // 充值
    private String id_charge_btn = "account_assest_charge";

    // 资产总价值
    private String id_assets_value = "account_general_assests_value";

    public void clickAccountName() {
        logger.info("click AccountName");
        waitFor(for_id(id_account_Name)).click();
    }

    public String getAccountName() {
        logger.info("get AccountName");
        return waitFor(for_id(id_account_Name)).getText();
    }

    public void solveHomePagehandleGuide() throws InterruptedException {
        Thread.sleep(2000);
        logger.info("at my account,tag middle centre");
        driver.tap(1, driver.manage().window().getSize().width / 2, driver.manage().window().getSize().height / 2, 1000);
        Thread.sleep(2000);
        logger.info("at my account,tag kown bottom");
        System.out.println("at my account,tag kown bottom");
        driver.tap(1, driver.manage().window().getSize().width / 2, driver.manage().window().getSize().height * 3 / 4, 1000);
        Thread.sleep(1000);
    }

    public void solveHomePagehandleGuideById() {

        logger.info("at my account,tag middle centre");
        waitFor(for_id(id_freshguide_pre_btn)).click();

        logger.info("at my account,tag kown bottom");
        waitFor(for_id(id_freshguide_next_btn)).click();

    }

    public void clickQuitButton() {
        waitFor(for_id(id_quit_btn)).click();
    }

    public Double getAssetValue() {
        WebElement ele = waitFor(for_id(id_assets_value));
        String asset = ele.getText().replace(",", "");
        Double assetValue = Double.parseDouble(asset);
        return assetValue;
    }

}
