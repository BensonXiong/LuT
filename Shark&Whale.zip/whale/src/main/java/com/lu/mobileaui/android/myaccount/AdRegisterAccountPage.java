package com.lu.mobileaui.android.myaccount;

import com.lu.mobileafw.BasePageAbstract;

/**
 * Created by huangyinhuang on 16/3/15.
 *
 * 账号注册页
 *
 */

public class AdRegisterAccountPage extends BasePageAbstract {

}
