package com.lu.mobileaui.android.myaccount;

import com.lu.mobileafw.BasePageAbstract;

/**
 * Created by huangyinhuang on 16/3/15.
 *
 * 找回用户名
 *
 */


public class AdRetrieveAccountPage extends BasePageAbstract {
}
