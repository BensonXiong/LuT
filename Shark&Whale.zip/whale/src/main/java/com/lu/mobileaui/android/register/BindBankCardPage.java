package com.lu.mobileaui.android.register;

import com.lu.mobileafw.BasePageAbstract;

import static com.lu.mobileafw.app.TestHelper.for_id;
import static com.lu.mobileafw.app.TestHelper.waitFor;

/**
 * Created by huangyinhuang on 16/3/18.
 */
public class BindBankCardPage extends BasePageAbstract {

    // 启动银行APP
    private String id_start_bank_app = "com.lufax.android:id/btn_startapp";
    //private String name_start_bank_app = "启动银行APP";

    // 返回按钮
    private String id_return_btn = "com.lufax.android:id/title_bar_left_container";

    public void clickReturnButton() {
        waitFor(for_id(id_return_btn)).click();
    }

    public void clickStartBankAppButton() {
        waitFor(for_id(id_start_bank_app)).click();
    }

}
