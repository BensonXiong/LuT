package com.lu.mobileaui.android.register;

import com.lu.mobileafw.BasePageAbstract;
import com.lu.mobileaui.common.SafeKeyboard;
import com.lufax.laf.biz.domain.NewUserParameters;
import com.lufax.laf.biz.service.OtpService;
import com.lufax.laf.core.utils.lang.StringUtils;

import static com.lu.mobileafw.app.TestHelper.element;
import static com.lu.mobileafw.app.TestHelper.for_id;
import static com.lu.mobileafw.app.TestHelper.waitFor;

/**
 * Created by huangyinhuang on 16/3/18.
 */

/**
 * 注册账号页面
 */
public class RegisterNewAccountPage extends BasePageAbstract {

    // 登录名，手机
    private String id_user_name = "com.lufax.android:id/et_loginname";


    // 登录密码
    private String id_login_pwd = "com.lufax.android:id/et_loginpswd";
    private String id_login_pwd_validator = "com.lufax.android:id/et_loginvalidator";

    private String id_phone_number = "com.lufax.android:id/et_phonenum";

    // 动态码
    private String id_dyn_code = "com.lufax.android:id/et_dyncode";
    private String id_get_validator_btn = "com.lufax.android:id/btn_getvalidator";

    // 服务协议
    private String id_register_claim_confirm = "com.lufax.android:id/tv_register_claim";
    private String id_register_btn = "com.lufax.android:id/btn_register";

    private SafeKeyboard safeKeyboard = new SafeKeyboard();

    public void registerNewAccount(NewUserParameters newUserParameters) {

        //newUserParameters = new NewUserParameters();

        String randomNo = StringUtils.getRandomString(10);
        String username = String.format("mobiletest%s", randomNo);
        String userpwd = newUserParameters.getLoginPwd();
        String phoneNo = newUserParameters.getMobileNo();

//        logger.info("user name: " + username);
//        logger.info("user password: " + userpwd);
//        logger.info("user phoneNo: " + phoneNo);

//        logger.info("fill dynamic code");
//        waitFor(for_id(id_dyn_code)).clear();
//        element(for_id(id_dyn_code)).sendKeys("123456");
//
//        // 退出安全键盘
//        safeKeyboard.clickOkButton();
//        //safeKeyboard.clickOkButton();
//
//        logger.info("click register button");
//        waitFor(for_id(id_register_btn)).click();


        logger.info("fill user name");
        waitFor(for_id(id_user_name)).clear();
        element(for_id(id_user_name)).sendKeys(username);

        logger.info("fill password");
        waitFor(for_id(id_login_pwd)).clear();
        element(for_id(id_login_pwd)).sendKeys(userpwd);

        logger.info("fill password validator");
        waitFor(for_id(id_login_pwd_validator)).clear();
        element(for_id(id_login_pwd_validator)).sendKeys(userpwd);

        logger.info("fill phone number");
        waitFor(for_id(id_phone_number)).clear();
        element(for_id(id_phone_number)).sendKeys(phoneNo);

        logger.info("click retrieve dynamic code button");
        waitFor(for_id(id_get_validator_btn)).click();

        OtpService otpService = new OtpService();
        String optCode = otpService.getOTPCodeByMobileNo(phoneNo);
        logger.info("dynamic code: " + optCode);

        logger.info("fill dynamic code");
        waitFor(for_id(id_dyn_code)).clear();
        element(for_id(id_dyn_code)).sendKeys(optCode);

        // 退出安全键盘
        safeKeyboard.clickOkButton();
        driver.hideKeyboard();


        logger.info("click register button");
        waitFor(for_id(id_register_btn)).click();

    }
}
