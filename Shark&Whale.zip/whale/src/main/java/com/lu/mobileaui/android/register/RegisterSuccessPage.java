package com.lu.mobileaui.android.register;

/**
 * Created by huangyinhuang on 16/3/18.
 */

/**
 * 注册成功页面
 */
public class RegisterSuccessPage {


    // 注册成功
    private String id_reg_success_logo = "com.lufax.android:id/tv_ok_hint";

    // 3秒后引用
    private String id_reg_success_info = "com.lufax.android:id/tv_reg_success_introduce";

    // 投资前准备
    private String id_redirect_to_preparation = "com.lufax.android:id/tv_reg_success_gesture";


}
