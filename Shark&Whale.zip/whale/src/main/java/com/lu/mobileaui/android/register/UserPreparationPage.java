package com.lu.mobileaui.android.register;

import com.lu.mobileafw.BasePageAbstract;
import com.lufax.laf.biz.domain.NewUserParameters;

import static com.lu.mobileafw.app.TestHelper.*;

/**
 * Created by huangyinhuang on 16/3/18.
 */

/**
 * 投资前准备
 */
public class UserPreparationPage extends BasePageAbstract {

    // step - 1 实名认证
    // 用户真实姓名
    private String id_real_name = "real_name";
    private String name_real_name = "真实姓名";

    // 用户身份证号码
    private String id_card_num = "id_card_num";
    private String name_id_card = "身份证号码";

    // 认证按钮
    private String id_authenticate_name_btn = "btn";
    private String name_authenticate_name_btn = "认证";


    // step - 2 设置交易密码
    private String xpath_trade_code = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.webkit.WebView[1]/android.webkit.WebView[1]/android.widget.EditText[2]";
    private String xpath_trade_code_confirm = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.webkit.WebView[1]/android.webkit.WebView[1]/android.widget.EditText[3]";
    private String name_trade_code_confirm_btn = "确定";

    // step - 3 银行卡认证
    private String name_bank_card_num = "银行卡号";
    private String name_next_step = "下一步";

    // 弹出框 － 返回投资钱准备
    private String id_cancel_btn = "com.lufax.android:id/title_bar_left_tv";
    private String id_author_btn = "author_button";

    // 弹出框 － 核对银行卡信息
    private String id_return_for_modify = "com.lufax.android:id/btn_left";
    private String name_return_for_modify = "返回修改";
    private String xpath_return_for_modify = "//android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]";
    private String id_confirm_bank_card_info = "com.lufax.android:id/btn_right";
    private String name_confirm_bank_card_info = "确认无误";

    public void authenticatUserName(NewUserParameters newUserParameters) {

        String real_name = newUserParameters.getRealName();
        String trade_pwd = newUserParameters.getTradePwd();
        String id_card_num = newUserParameters.getCredentialsNo();
        String bank_card_num = newUserParameters.getBankCode();

//        logger.info("user real name: " + real_name);
//        logger.info("user card number: " + card_num);

        // step - 1 实名认证

        //
        logger.info("fill real name: " + real_name);
        waitFor(for_name(name_real_name)).clear();
        element(for_name(name_real_name)).sendKeys(real_name);
        //StringDecoder
        //element(for_name(text_real_name)).getText();


        //
        logger.info("fill card number: " + id_card_num);
        waitFor(for_name(name_id_card)).clear();
        element(for_name(name_id_card)).sendKeys(id_card_num);

        //
        logger.info("click authenticate button");
        waitFor(for_name(name_authenticate_name_btn)).click();


        // step - 2 设置交易密码
        waitFor(for_xpath(xpath_trade_code)).sendKeys(trade_pwd);
        waitFor(for_xpath(xpath_trade_code_confirm)).sendKeys(trade_pwd);
        waitFor(for_name(name_trade_code_confirm_btn)).click();


        // step - 3 银行卡认证
        waitFor(for_name(name_bank_card_num)).sendKeys(bank_card_num);
        waitFor(for_name(name_next_step)).click();

        waitFor(for_name(id_confirm_bank_card_info)).click();
    }

    public void clickReturnPreparation() {
        waitFor(for_id(id_author_btn)).click();
    }
}
