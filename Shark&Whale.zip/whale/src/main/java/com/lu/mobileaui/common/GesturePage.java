package com.lu.mobileaui.common;

import com.lu.mobileainfra.lma.BasePage;
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/4/15.
 *
 * 手势密码页面
 *
 */

public class GesturePage extends BasePage {

    // 标题
    @iOSFindBy(xpath = "NA")
    //@AndroidFindBy(name = "手势密码登录")
    //@AndroidFindBy(name = "设置手势密码")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement TitleText;

    // 手势图形界面
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "lock_pattern")
    public WebElement GestureLockArea;

    // 忘记手势密码
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "forget_lock")
    public WebElement ForgetLockButton;

    // 用其他账号登录
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "other_account_login")
    public WebElement LoginWithOtherAccountButton;

    // 弹出框－设置成功
    @iOSFindBy(name = "知道了")
    @AndroidFindBy(id = "btn_ok")
    public WebElement GestureReadyOkButton;

    public Boolean isGesturePageReady() {
        return false;
    }

    public void loginGesture() {

        logger.info("start to draw the login gesture...");


        if(testConf.getDevicePlatformName().equals("android")){
            logger.info("login gesture on android device");

            // Following coordination is from Android Xiaomi 4C
            // 1 (260, 790)    2 (550, 790)    3 (820, 790)
            // 3 (260, 1080)   4 (550, 1080)   5 (820, 1080)
            // 6 (260, 1350)   7 (550, 1350)   8 (820, 1350)

            driverHelper.sleep(5000);
            TouchAction t = new TouchAction(driver);
            t.press(260, 790).waitAction(300).moveTo(0, 600).waitAction(300).moveTo(300, 0).waitAction(300).release().perform();
            t.waitAction();
            driverHelper.sleep(5000);
        }else {
            logger.info("login gesture on ios device");

            //320,586
            // Following coordination is from ios iPod
            // 1 (56, 180)   2 (149, 180)   3 (232, 180)
            // 3 (56, 273)   4 (149, 273)   5 (232, 273)
            // 6 (56, 366)   7 (149, 366)   8 (232, 366)

            driverHelper.sleep(5000);
            TouchAction t = new TouchAction(driver);
            t.press(56, 180).waitAction(300).moveTo(0, 100).waitAction(300).moveTo(180, 0).waitAction(300).release().perform();
            t.waitAction();
            driverHelper.sleep(5000);
        }


    }

    public void setGesture() {

        logger.info("start to set the login gesture...");

        // Following coordination is from Android Xiaomi 4C
        // 1 (260, 760)    2 (550, 760)    3 (820, 760)
        // 3 (260, 1050)   4 (550, 1050)   5 (820, 1050)
        // 6 (260, 1320)   7 (550, 1320)   8 (820, 1320)
        if (testConf.getDevicePlatformName().equals("android")){
            logger.info("draw gesture on android device");
            driverHelper.sleep(5000);
            TouchAction t = new TouchAction(driver);
            t.press(260, 760).waitAction(300).moveTo(0, 600).waitAction(300).moveTo(300, 0).waitAction(300).release().perform();
            t.waitAction();
            driverHelper.sleep(5000);
        }else {
            logger.info("draw gesture on ios device");
            //320,586
            // Following coordination is from ios iPod
            // 1 (56, 188)   2 (149, 188)   3 (232, 188)
            // 3 (56, 282)   4 (149, 282)   5 (232, 282)
            // 6 (56, 375)   7 (149, 375)   8 (232, 375)
            driverHelper.sleep(5000);
            TouchAction t = new TouchAction(driver);
            t.press(56, 188).waitAction(300).moveTo(0, 100).waitAction(300).moveTo(180, 0).waitAction(300).release().perform();
            t.waitAction();
            driverHelper.sleep(5000);
        }



    }
}
