package com.lu.mobileaui.common;

import com.lu.mobileainfra.lma.BasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/4/28.
 *
 * 页面头部标题
 *
 */

public class HeaderBar extends BasePage {

    // 左边容器
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_left_container")
    public WebElement LeftContainer;

    // 中间标题容器
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIANavigationBar[1]")
    @AndroidFindBy(id = "title_bar_middle_container")
    public WebElement MiddleContainer;

    // 右边容器
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_right_container")
    public WebElement RightContainer;

    // 左边按钮
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement LeftButton;

    // 标题
    @iOSFindBy(name = "//UIAApplication[1]/UIAWindow[1]/UIANavigationBar[1]/UIAStaticText[1]")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement Title;

    // 右边按钮
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement RightButton;

    public String getTitleText() {
        return Title.getText();
    }

    public void clickBackButton() {
        clickLeftButton();
    }

    public void clickForwardButton() {
        clickRightButton();
    }

    public void clickLeftButton() {
        this.LeftButton.click();

        // wait for 5 seconds
        driverHelper.sleep(5000);
    }

    public void clickRightButton() {
        this.RightButton.click();

        // wait for 5 seconds
        driverHelper.sleep(5000);
    }


}
