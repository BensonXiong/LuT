package com.lu.mobileaui.common;

import com.lu.mobileainfra.be.LuTestBeEnv;
import com.lu.mobileainfra.lma.BasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

import static com.lu.mobileafw.app.TestHelper.checkExist;

/**
 * Created by yuyongsong001 on 16/5/12.
 *
 *app 登录页面－忘记密码-重置登录密码
 *
 */
public class RetrievePasswordPage extends BasePage {

    //用户名
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATextField[1]")
    @AndroidFindBy(name = "请输入用户名")
    public WebElement UserNameInput;

    //手机号码
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATextField[2]")
    @AndroidFindBy(name = "请输入手机号码")
    public WebElement MobileNOInput;

    //验证码
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATextField[3]")
    @AndroidFindBy(name = "右侧字符")
    public WebElement VerifyCodeInput;

    //刷新验证码
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAImage[1]")
    @AndroidFindBy(id="iv_login_pwd_retrieve")
    public WebElement RefreshVCodeBtn;

    //下一步按钮
    @iOSFindBy(name = "下一步")
    @AndroidFindBy(name = "下一步")
    public WebElement NextButton;

    //答案
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATextField[2]")
    @AndroidFindBy(id="otp_answer_et")
    public WebElement AnswerInput;

    //获取动态码按钮
    @iOSFindBy(name = "获取动态码")
    @AndroidFindBy(name = "获取动态码")
    public WebElement RefreshDynCodeButton;

    //动态码输入框
    @iOSFindBy(name = "7位数字")//UIAApplication[1]/UIAWindow[1]/UIATextField[3]
    @AndroidFindBy(name = "7位数字")
    public WebElement DyncodeInput;

    //动态码
    @iOSFindBy(name = "动态码")//UIAApplication[1]/UIAWindow[1]/UIAStaticText[4]
    @AndroidFindBy(name = "动态码")
    public WebElement DyncodeView;

    //输入登录密码
    @iOSFindBy(name = "请输入登录密码")//UIAApplication[1]/UIAWindow[1]/UIASecureTextField[1]
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.EditText[1]")
    public WebElement LoginPwdNewInput;

    //再输入一遍
    @iOSFindBy(name = "请再输一遍登录密码")//UIAApplication[1]/UIAWindow[1]/UIASecureTextField[2]
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.LinearLayout[1]/android.widget.EditText[1]")
    public WebElement LoginPwdNewExInput;

    //确定
    @iOSFindBy(name = "确定")//UIAApplication[1]/UIAWindow[1]/UIAButton[1]
    @AndroidFindBy(name = "确定")
    public WebElement ConfirmButton;

    //登录密码重置成功
    @iOSFindBy(name = "登录密码重置成功")//UIAApplication[1]/UIAWindow[1]/UIAStaticText[1]
    @AndroidFindBy(name = "登录密码重置成功")
    public WebElement RePwdStatusButton;

    //立即登录
    @iOSFindBy(name = "立即登录")//UIAApplication[1]/UIAWindow[1]/UIAButton[1]
    @AndroidFindBy(name = "立即登录")
    public WebElement NewLoginButton;

    public void RetrievePassword(String userName,String mobileNo,String answerInput,LuTestBeEnv luTestBeEnv,String loginPwd){

        //输入用户名
        UserNameInput.clear();
        UserNameInput.sendKeys(userName);

        //输入手机号码
        MobileNOInput.clear();
        MobileNOInput.sendKeys(mobileNo);

        //获取验证码
        Boolean bExist = checkExist(VerifyCodeInput);
        if(bExist) {
            testBeEnv.clearCaptcha("USER:V1:CAPTCHA");
            RefreshVCodeBtn.click();
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            String code = testBeEnv.getCaptcha();
            logger.info("code = " + code);

            VerifyCodeInput.clear();
            VerifyCodeInput.sendKeys(code);
        }

        //下一步
        NextButton.click();

        //安全保护问题答案
        AnswerInput.sendKeys(answerInput);

        //点击获取动态码
        RefreshDynCodeButton.click();

        //输入动态码
        DyncodeInput.sendKeys(luTestBeEnv.getSms());

        //下一步
        NextButton.click();

        //输入新登录密码
        LoginPwdNewInput.clear();
        LoginPwdNewInput.sendKeys(loginPwd);

        //再输入一遍
        LoginPwdNewExInput.clear();
        LoginPwdNewExInput.sendKeys(loginPwd);

        //确定
        ConfirmButton.click();

        testAssert.assertTrue(RePwdStatusButton.isDisplayed(),"重置密码成功");

    }

}
