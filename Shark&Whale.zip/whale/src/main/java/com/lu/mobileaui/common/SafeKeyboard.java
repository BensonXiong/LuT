package com.lu.mobileaui.common;

/**
 * Created by huangyinhuang on 16/3/18.
 *
 * app 安全键盘
 *
 */

import com.lu.mobileainfra.lma.BasePage;

public class SafeKeyboard extends BasePage {

    // 确认按钮
    public void clickOkButton() {

        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        driver.tap(2, width-80, height-80, 500);

    }
}
