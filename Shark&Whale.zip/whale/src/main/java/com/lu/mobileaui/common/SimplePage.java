package com.lu.mobileaui.common;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/4/14.
 */
public class SimplePage extends BasePageAbstract {

    //@iOSFindBys({@iOSFindBy(uiAutomator = ".elements()[0]"),
    //@iOSFindBy(xpath = "//someElement")})
    //@iOSFindBy(name = "登录")
    //@AndroidFindBy(uiAutomator = "new UiSelector().resourceId(\"com.lufax.android:id/tv_bottombar1\")")
    //@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '点金计划')]")
    //@AndroidFindBy(xpath = "//android.widget.Button[contains(@text, '')]")
    //@AndroidFindBy(xpath = "//android.widget.CheckBox[contains(@text, '')]")
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[1]/UIAButton[1]")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement LoginButton;

}
