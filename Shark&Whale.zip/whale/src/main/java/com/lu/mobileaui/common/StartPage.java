package com.lu.mobileaui.common;

import com.lu.mobileafw.BasePageAbstract;
import com.lu.mobileafw.app.TestHelper;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/3/31.
 *
 * app 启动页
 *
 */

public class StartPage extends BasePageAbstract {


    @iOSFindBy(name = "NA")
    @AndroidFindBy(id="welcome_pager")
    public WebElement WelcomePage;

    //体验新版
    @iOSFindBy(name = "体验新版")
    @AndroidFindBy(id="start_button")
    public WebElement StartBtn;

    //知道了
    @iOSFindBy(name = "300_tabbar_more_btn_guide")//UIAApplication[1]/UIAWindow[1]/UIAImage[2]
    @AndroidFindBy(id="bottom_layout")
    public WebElement BottomBtn;

    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAButton[7]")
    @AndroidFindBy(id="NA")
    public WebElement CloseButton;

    //立即更新
    @iOSFindBy(name="立即更新")
    @AndroidFindBy(name="立即更新")
    public WebElement UpgradeButton;

    @iOSFindBy(id="NA")
    @AndroidFindBy(id="update_btn_cancel")
    public WebElement UpgradeCancelButton;

    //完成立即投资前准备
    @iOSFindBy(name="立即去完成")
    @AndroidFindBy(name="立即去完成")
    //@AndroidFindBy(id="author_button")
    public WebElement PreInvestmentButton;

    @iOSFindBy(id="NA")
    @AndroidFindBy(id="close")
    public WebElement PreInvestmentCancelButton; // 取消立即投资前准备


    //滑动页面
    @iOSFindBy(xpath="//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAImage[1]")
    @AndroidFindBy(id="welcome_pager")
    public WebElement ScrollView;

//    <UIAScrollView name="" label="" value="" dom="" enabled="true" valid="true" visible="true" hint="" path="/0/0/11" x="0" y="0" width="320" height="568">
//    <UIAImage name="/var/containers/Bundle/Application/E4A6AFB0-4941-47AE-94C6-36FB68DB9FA8/lujinsuo.app/newUserGuide/launch_intro1.png" label="" value="" dom="" enabled="true" valid="true" visible="true" hint="" path="/0/0/11/0" x="0" y="0" width="320" height="568">
//    </UIAImage>
//    </UIAScrollView>
//    <UIAScrollView name="" label="" value="" dom="" enabled="true" valid="true" visible="true" hint="" path="/0/0/9" x="0" y="0" width="320" height="568">
//    <UIAImage name="/var/containers/Bundle/Application/E4A6AFB0-4941-47AE-94C6-36FB68DB9FA8/lujinsuo.app/newUserGuide/launch_intro2.png" label="" value="" dom="" enabled="true" valid="true" visible="true" hint="" path="/0/0/9/0" x="0" y="0" width="320" height="568">
//    <UIAButton name="体验新版" label="体验新版" value="" dom="" enabled="true" valid="true" visible="true" hint="" path="/0/0/9/0/0" x="90" y="483" width="140" height="36">
//    </UIAButton>
//    </UIAImage>
//    </UIAScrollView>


    public void skipUpgradeInfo() {

        logger.info("如果有更新提示，则跳过更新提示，点击取消按钮");
        driverHelper.sleep(5000);
        if (driverHelper.checkExist(UpgradeButton)) {
            logger.info("点击取消按钮");
            UpgradeCancelButton.click();
        }

    }

    public void skipPreInvestment() {

        logger.info("如果有投资前准备，则跳过，点击取消按钮");
        driverHelper.sleep(5000);
        if (driverHelper.checkExist(PreInvestmentButton)) {
            logger.info("点击取消按钮");
            PreInvestmentCancelButton.click();
        }

    }


    public void swipeStartupPage() {

//        waitFor(for_id(start_button));
//        WelcomePage.isDisplayed();

//        waitFor(for_id("welcome_pager"));

        logger.info("sleep 10 seconds, wait for start page");
        driverHelper.sleep(10000);

        if (driverHelper.checkExist(ScrollView)){
            logger.info("swipe the page");
            int width= TestHelper.driver.manage().window().getSize().width;
            int height= TestHelper.driver.manage().window().getSize().height;
            TestHelper.driver.swipe(width - 1, height / 2, 1, height / 2, 1000);
            TestHelper.driver.swipe(width - 1, height / 2, 1, height / 2, 1000);

            logger.info("click the start button");
            driverHelper.clickWhenExist(StartBtn);

            // sleep 10 seconds when switch to home page
            driverHelper.sleep(10000);

            skipUpgradeInfo();

            logger.info("click the bottom button if exist");
            //TODO waitFor(for_id("bottom_layout"));
            driverHelper.clickWhenExist(BottomBtn);
        }else{
            logger.info("the start page doesn't exist, skip page swipping");
        }



    }

}
