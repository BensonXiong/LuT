package com.lu.mobileaui.common.home;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/3/31.
 *
 * app 首页
 *
 */

public class HomePage extends BasePageAbstract {

    /**
     * 首页 banner广告位
     */
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[contains(@name,'登录')]")
    @AndroidFindBy(id = "layout_advertise")
    public WebElement AdvertiseBanner;

    //@iOSFindBys({@iOSFindBy(uiAutomator = ".elements()[0]"),
    //@iOSFindBy(xpath = "//someElement")})
    //@iOSFindBy(name = "登录")
    //使用关键字定位，可以判断是否显示
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[1]/UIAButton[contains(@name,'登录')]")//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[1]/UIAButton[1]
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement LoginButton;

    /**
     * 理财精选 － 市场推荐
     */
    @iOSFindBy(name = "理财精选")
    @AndroidFindBy(id = "marketing_area")
    public WebElement ProductRecommendArea;

    //新客入口
    //数字顺序  先由上至下，由左至右
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]/UIAStaticText[1]")
    @AndroidFindBy(id = "item1")
    public WebElement ProductRecommendItem1;

    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]/UIAStaticText[3]")
    @AndroidFindBy(id = "item2")
    public WebElement ProductRecommendItem2;

    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]/UIAStaticText[4]")
    @AndroidFindBy(id = "item3")
    public WebElement ProductRecommendItem3;

    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]/UIAStaticText[6]")
    @AndroidFindBy(id = "item4")
    public WebElement ProductRecommendItem4;

    /**
     * 理财精选 － 产品推荐列表
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "list_part1")
    public WebElement ProductRecommendList;


    /**
     * 功能模块
     */


    /**
     * 快速投资
     */

    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "list_part2")
    public WebElement QuickInvestList;

    @iOSFindBy(name = "活期")
    @AndroidFindBy(name = "活期")
    public WebElement HuoQiProduct;

    @iOSFindBy(name = "3个月以内")
    @AndroidFindBy(name = "3个月以内")
    public WebElement ThreeMonthProduct;

    @iOSFindBy(name = "3~6个月")
    @AndroidFindBy(name = "3~6个月")
    public WebElement SixMonthProduct;


    @iOSFindBy(name = "6~12个月")
    @AndroidFindBy(name = "6~12个月")
    public WebElement YearProduct;

    @iOSFindBy(name = "12个月以上")
    @AndroidFindBy(name = "12个月以上")
    public WebElement LongPeriodProduct;


    public void clickLoginButton() {
        LoginButton.click();
    }

    public void selectQuickProductHuoqi() {
//        WebElement ele = driver.scrollTo("活期");
//        ele.click();

        this.HuoQiProduct.click();
        // 切换页面等待5秒
        driverHelper.sleep(5000);

    }

    public void selectQuickProductThreeMonth() {

        this.ThreeMonthProduct.click();
        // 切换页面等待5秒
        driverHelper.sleep(5000);

    }

    public void selectQuickProductSixMonth() {

        this.SixMonthProduct.click();
        // 切换页面等待5秒
        driverHelper.sleep(5000);

    }

    public void selectQuickProductYear() {

        this.YearProduct.click();
        // 切换页面等待5秒
        driverHelper.sleep(5000);

    }

    public void selectQuickProductLongPeriod() {

        this.LongPeriodProduct.click();
        // 切换页面等待5秒
        driverHelper.sleep(5000);

    }

}
