package com.lu.mobileaui.common.insurance;

import com.lu.mobileainfra.lma.BasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by liuyinping on 16/6/29.
 */
public class InsurancePage extends BasePage{
    private Logger logger = LoggerFactory.getLogger(InsurancePage.class);


    @iOSFindBy(name="平安车险")
    @AndroidFindBy(name="平安车险")
    public WebElement CarInsurance;

    @iOSFindBy(name="平安百万任我行两全保险")
    @AndroidFindBy(name="平安百万任我行两全保险")
    public WebElement BaiWanInsurance;

    @iOSFindBy(name="一年期综合意外保险")
    @AndroidFindBy(name="一年期综合意外保险")
    public WebElement AccidentInsurance;

    @iOSFindBy(name="一年期综合意外险")
    @AndroidFindBy(name="一年期综合意外险")
    public WebElement AccidentInsuranceTitle;


    @iOSFindBy(id="NA")
    @AndroidFindBy(id="title_bar_left_tv")
    public WebElement Back;


    @iOSFindBy(id="NA")
    @AndroidFindBy(id="title_bar_title_tv")
    public WebElement Title;



}
