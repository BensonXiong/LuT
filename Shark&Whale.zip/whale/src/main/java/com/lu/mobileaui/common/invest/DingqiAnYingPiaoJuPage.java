package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/5.
 *
 * 定期－票据－安盈票据
 *
 */
public class DingqiAnYingPiaoJuPage extends BasePageAbstract {
    //安盈票据
    @iOSFindBy(name ="NA")
    @AndroidFindBy(xpath = "/android.widget.LinearLayout[2]/android.widget.RelativeLayout[1]")
    public WebElement AnYingPiaoJuProduct;

    public void clickAnYingPiaoJu(){
        AnYingPiaoJuProduct.click();
    }
}
