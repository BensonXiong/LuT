package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/26.
 *
 * 活期－定期投资计划
 *
 */
public class DingqiInvestPlanPage extends BasePageAbstract {

    //勾选协议
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "checkbox_agreement")
    public WebElement AgreementCheckbox;

    //创建
    @iOSFindBy(name = "创建")
    @AndroidFindBy(name = "创建")
    public WebElement CreateButton;

    //修改
    @iOSFindBy(name = "修改")
    @AndroidFindBy(name = "修改")
    public WebElement ModifyButton;

    //确定
    @iOSFindBy(name = "确定")
    @AndroidFindBy(name = "确定")
    public WebElement ConfirmButton;

    //完成
    @iOSFindBy(name = "完成")
    @AndroidFindBy(name = "完成")
    public WebElement CompleteButton;

    //每期投资多少钱（input）
    @iOSFindBy(xpath = "//UIATextField[1]")
    @AndroidFindBy(id = "s_edit")
    public WebElement InvestAmountInput;

    //扣款日期（日期控件）
    @iOSFindBy(xpath = "//UIATextField[2]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[4]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[3]")
    public WebElement RetainageDate;

    // 交易密码
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIASecureTextField[1]")//UIAApplication[1]/UIAWindow[1]/UIAScrollView[2]/UIASecureTextField[1]
    @AndroidFindBy(id = "pwPlaceHodler")
    public WebElement TradePwdInput;

    //选择具体日期
//    @iOSFindBy(name = "NA")
//    @AndroidFindBy(xpath = "//android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.ImageView[1]")
//    public WebElement ClickDateButton;

    //制定定期投资计划
    public void clickDingqiInvestPlan(String price,String tradePwd){

        InvestAmountInput.clear();
        InvestAmountInput.sendKeys(price);
        RetainageDate.click();
//        driver.tap(1,260,1000,500);
        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        driver.tap(1,width / 2, height / 2, 500);
        AgreementCheckbox.click();
        CreateButton.click();
        TradePwdInput.clear();
        TradePwdInput.sendKeys(tradePwd);
        ConfirmButton.click();
        CompleteButton.click();

    }

    //修改定期投资计划
    public void modifyDingqiInvestPlan(String price,String tradePwd){

        InvestAmountInput.clear();
        InvestAmountInput.sendKeys(price);
        RetainageDate.click();
//        driver.tap(1,260,1000,500);
        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        driver.tap(1,width/2,height/2,500);

        AgreementCheckbox.click();
        ModifyButton.click();
        TradePwdInput.clear();
        TradePwdInput.sendKeys(tradePwd);
        ConfirmButton.click();
        CompleteButton.click();

    }

}
