package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.exception.NoSuchWebElementException;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/4/27.
 *
 * 投资理财页 -> 定期页 -> 定期列表展示
 */
public class DingqiPage extends ProductListPage {

    /**
     *
     * 标题检查
     *
     */

    // 定期
    @iOSFindBy(xpath = "//UIAStaticText[@name='定期']")
    @AndroidFindBy(name = "定期")
    public WebElement DingqiTitle;

    /**
     * 产品类
     */

    //定期－财富汇
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATableView[1]/UIATableCell[3]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[3]/android.widget.RelativeLayout[1]")
    public WebElement CaifuhuiProduct;

    //定期－安鑫
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATableView[1]/UIATableCell[2]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.RelativeLayout[1]")
    public WebElement AnXinProduct;

    //定期－彩虹
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATableView[1]/UIATableCell[2]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.RelativeLayout[1]")
    public WebElement CaiHongProduct;

    //定期－粤股交
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATableView[1]/UIATableCell[2]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.RelativeLayout[1]")
    public WebElement YueGuJiaoProduct;

    //定期－票据
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATableView[1]/UIATableCell[2]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.RelativeLayout[1]")
    public WebElement DingqiPiaoJuProduct;


    //定期－信托理财投资
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATableView[1]/UIATableCell[1]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.RelativeLayout[1]")
    public WebElement DingqiTrustInvestment;


    /**
     * 标题
     */

    /**
     * 定期－综合排序
     */
    //综合排序
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAButton[3]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement topSyntheticallyTextView;

    /**
     * 定期－综合排序-综合排序
     * 关键字与上面重复
     */
    //综合排序选项
    ////UIATableCell[@name='综合排序'][last()]
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[1]/UIAStaticText[1]")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement synSortTextView;

    /**
     * 定期－综合排序-收益率/利率最高
     */
    //收益率/利率最高排序选项
    @iOSFindBy(name = "收益率/利率最高")
    @AndroidFindBy(xpath = "//android.view.View[2]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement synRateMaxSortTextView;

    /**
     * 定期－综合排序-期限最长
     */
    //期限最长排序选项
    @iOSFindBy(name = "期限最长")
    @AndroidFindBy(xpath = "//android.view.View[3]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement synHorizonMinSortTextView;

    /**
     * 定期－综合排序-期限最短
     */
    //期限最短排序选项
    @iOSFindBy(name = "期限最短")
    @AndroidFindBy(xpath = "//android.view.View[4]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement synHorizonMaxSortTextView;

    /**
     * 定期－综合排序-起投最高
     */
    //投资最大排序选项
    @iOSFindBy(name = "起投最高")
    @AndroidFindBy(xpath = "//android.view.View[5]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement synInvestmentMaxSortTextView;

    /**
     * 定期－综合排序-起投最低
     */
    //投资最短排序选项
    @iOSFindBy(name = "起投最低")
    @AndroidFindBy(xpath = "//android.view.View[6]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement synInvestmentMinSortTextView;

    //＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
    /**
     * 定期－投资期限
     */
    //投资期限
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAButton[4]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[2]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement topInvestmentHorizonTextView;


    /**
     * 定期－投资期限－不限
     */
    //不限排序选项
    @iOSFindBy(name = "不限")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement monthUnlimitedSortTextView;


    /**
     *定期－投资期限－ 一个月内
     */
    //一个月内排序选项
    @iOSFindBy(name = "1个月内")
    @AndroidFindBy(xpath = "//android.view.View[2]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement monthOneSortTextView;

    /**
     * 定期－投资期限－1~3个月
     */
    //1-3个月排序选项
    @iOSFindBy(name = "1~3个月")
    @AndroidFindBy(xpath = "//android.view.View[3]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement monthOneToThreeSortTextView;

    /**
     *定期－投资期限－ 3~6个月
     */
    //3-6个月排序选项
    @iOSFindBy(name = "3~6个月")
    @AndroidFindBy(xpath = "//android.view.View[4]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement monthThreeToSixSortTextView;

    /**
     * 定期－投资期限－6~12个月
     */
    //6-12个月排序选项
    @iOSFindBy(name = "6~12个月")
    @AndroidFindBy(xpath = "//android.view.View[5]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement monthSixToTwelveSortTextView;


    /**
     * 定期－投资期限－12个月以上
     */
    //12个月以上排序选项
    @iOSFindBy(name = "12个月以上")
    @AndroidFindBy(xpath = "//android.view.View[6]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement monthTwelveOverSortTextView;

    //＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
    /**
     * 定期－起投金额
     */
    //起投金额
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAButton[5]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[3]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement topStartAmountTextView;


    /**
     * 定期－起投金额－不限
     */
    //不限金额排序选项
    @iOSFindBy(name = "不限")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement amountUnlimitedSortTextView;

    /**
     * 定期－起投金额－5万元以下
     */
    //5万元内排序选项
    @iOSFindBy(name = "5万元以下")
    @AndroidFindBy(xpath = "//android.view.View[2]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement amountFiveHorizonSortTextView;

    /**
     * 定期－起投金额－5万~10万元
     */
    //5－10万排序选项
    @iOSFindBy(name = "5万~10万元")
    @AndroidFindBy(xpath = "//android.view.View[3]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement amountFiveToTenSortTextView;

    /**
     * 定期－起投金额－10万~30万元
     */
    //10-30万排序选项
    @iOSFindBy(name = "10万~30万元")
    @AndroidFindBy(xpath = "//android.view.View[4]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement amountTenToThirtySortTextView;

    /**
     * 定期－起投金额－30万元以上
     */
    //30万以上排序选项
    @iOSFindBy(name = "30万元以上")
    @AndroidFindBy(xpath = "//android.view.View[5]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement amountThirtyOverSortTextView;

    /**
     * 定期－起投金额－开始金额
     */
    //开始金额
    @iOSFindBy(xpath = "//UIATextField[position()=1]")
    @AndroidFindBy(id = "start_region_edit")//android.widget.EditText
    public WebElement amountStartEditText;

    /**
     * 定期－起投金额－结束金额
     */
    //结束金额
    @iOSFindBy(xpath = "//UIATextField[position()=2]")
    @AndroidFindBy(id = "last_region_edit")//android.widget.EditText
    public WebElement amountLastEditText;

    /**
     * 定期－起投金额－确定按钮
     */
    //确定按钮
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[*]/UIAButton[1]")
    @AndroidFindBy(id = "confirm_btn")//android.widget.Button
    public WebElement amountConfirmButton;

    //＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
    /**
     * 定期－筛选
     *
     */
    //筛选
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAButton[6]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[4]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement topFilterTextView;

    /**
     *定期－筛选- 收益方式－不限
     */
    //收益方式－不限
    @iOSFindBy(xpath = "//UIAStaticText[@name='不限'][position()=1]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.LinearLayout[1]//android.widget.GridView[1]/android.view.View[1]")//android.widget.TextView
    public WebElement earningsUnlimitedTextView;


    /**
     *定期－筛选- 收益方式－一次性还本付息
     */
    //收益方式－一次性还本付息
    @iOSFindBy(name = "一次性还本付息")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '一次性还本付息')]")//android.widget.TextView
    public WebElement earningsYicihuanbenfuxiTextView;

    /**
     * 定期－筛选-收益方式－以市值计算
     */
    //收益方式－以市值计算
    @iOSFindBy(name = "以市值计算")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '以市值计算')]")//android.widget.TextView
    public WebElement earningsYishizhijisuanTextView;


    /**
     * 定期－筛选-项目类型－不限
     */
    //项目类型－不限
    @iOSFindBy(xpath = "//UIAStaticText[@name='不限'][position()=2]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.LinearLayout[2]/android.widget.GridView[1]/android.view.View[1]")//android.widget.TextView
    public WebElement projectUnlimitedTextView;


    /**
     * 定期－筛选-项目类型－财富汇
     */
    //项目类型－财富汇
    @iOSFindBy(name = "财富汇")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '财富汇')]")//android.widget.TextView
    @AndroidFindBy(name = "财富汇")
    public WebElement projectCaifuhuiTextView;

    /**
     *定期－筛选- 项目类型－安鑫
     */
    //项目类型－安鑫
    @iOSFindBy(name = "安鑫")
    @AndroidFindBy(name = "安鑫")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '安鑫')]")//android.widget.TextView
    public WebElement projectAnxinTextView;



    /**
     * 定期－筛选-项目类型－彩虹
     */
    //项目类型－彩虹
    @iOSFindBy(name = "彩虹")
    @AndroidFindBy(name = "彩虹")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '彩虹')]")//android.widget.TextView
    public WebElement projectCaihongTextView;

    /**
     * 定期－筛选-项目类型－保险型理财
     */
    //项目类型－保险型理财
    @iOSFindBy(name = "保险型理财")
    @AndroidFindBy(name = "保险型理财")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '保险型理财')]")//android.widget.TextView
    public WebElement projectBaoxianxinglicaiTextView;

    //项目类型－理享+
    @iOSFindBy(name = "理享+")
    @AndroidFindBy(name = "理享+")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '保险型理财')]")//android.widget.TextView
    public WebElement projectLixiangjiaButton;

    /**
     * 定期－筛选-项目类型－安盈-票据
     */
    //项目类型－安盈-票据
    @iOSFindBy(name = "安盈-票据")
    @AndroidFindBy(name = "安盈-票据")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '安盈-票据')]")//android.widget.TextView
    public WebElement projectAnyingpiaojuTextView;

    //定期－票据
    @iOSFindBy(name = "票据")
    @AndroidFindBy(name = "票据")
    public WebElement DingqiPiaoJuButton;

    /**
     * 定期－筛选-项目类型－粤股交
     */
    //项目类型－粤股交
    @iOSFindBy(name = "粤股交")
    @AndroidFindBy(name = "粤股交")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '粤股交')]")//android.widget.TextView
    public WebElement projectYuegujiaoTextView;


    /**
     * 定期－筛选-项目类型－信托理财
     */
    //项目类型－信托理财
    @iOSFindBy(name = "信托理财")
    @AndroidFindBy(name = "信托理财")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '信托理财')]")//android.widget.TextView
    public WebElement projectXintuolicaiTextView;

    /**
     * 定期－筛选-项目类型－有促销
     */
    //项目类型－有促销
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[3]/UIAButton[1]")
    @AndroidFindBy(name = "有促销")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '有促销')]")//android.widget.TextView
    public WebElement projectYoucuxiaoTextView;

    /**
     * 定期－筛选-项目类型－重置
     */
    //项目类型－重置
    @iOSFindBy(name = "重置")
    @AndroidFindBy(id = "bt_filter_reset")//android.widget.Button
    public WebElement projectRestButton;

    /**
     * 定期－筛选-项目类型－确定
     */
    //项目类型－确定
    @iOSFindBy(name = "确定")//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[*]/UIAButton[1]
    @AndroidFindBy(id = "bt_filter_confirm")//android.widget.Button
    public WebElement projectConfirmButton;

    /**
     *
     * 产品
     *
     */

    //定期－财富汇
    public void clickCaifuhui(){
        topFilterTextView.click();
        projectCaifuhuiTextView.click();
        projectConfirmButton.click();
        CaifuhuiProduct.click();
    }

    //定期－安鑫
    public void clickAnXin(){
        topFilterTextView.click();
        projectAnxinTextView.click();
        projectConfirmButton.click();
        AnXinProduct.click();
    }

    //定期－彩虹
    public void clickCaiHong(){
        topFilterTextView.click();
        projectCaihongTextView.click();
        projectConfirmButton.click();
        CaiHongProduct.click();
    }

    //定期－票据
    public void clickDingqiPiaoJu(){
        topFilterTextView.click();
        projectAnyingpiaojuTextView.click();
        projectConfirmButton.click();
        DingqiPiaoJuButton.click();
        DingqiPiaoJuProduct.click();

    }

    //定期－粤股交
    public void clickDingqiYueGuJiao(){
        topFilterTextView.click();
        projectYuegujiaoTextView.click();
        projectConfirmButton.click();
        YueGuJiaoProduct.click();
    }

    //定期－信托理财投资
    public void clickDingqiTrustInvestment(){
        driverHelper.sleep(5000);
        logger.info("debug: 21");
        topFilterTextView.click();
        logger.info("debug: 22");
        projectXintuolicaiTextView.click();
        projectConfirmButton.click();
        DingqiTrustInvestment.click();
    }

    /**
     *
     * 保险类产品
     * 按产品姓名精确查找
     *
     */

    //按产品名字精确查找
    public void clickInsuranceProduct(String productName) throws NoSuchWebElementException {

        testLogger.info("翻页查找保险产品：" + productName);
        trySearchProduct(By.name(productName));

        testLogger.info("保险产品已找到，点击产品");
        WebElement webProduct = driver.findElementByName(productName);
        webProduct.click();

        // wait for seconds
        driverHelper.sleep(10000);

    }

    //定期保险列表搜索相关功能通用方法
    public void trySearchProduct(By productLocator) throws NoSuchWebElementException {

        // 筛选中选择理享＋产品
        topFilterTextView.click();
        projectLixiangjiaButton.click();
        testLogger.info("[screen] 筛选中选择理享＋产品");

        projectConfirmButton.click();

        // 翻页查找产品
        boolean bFound = driverHelper.trySearchElementByScroll(productLocator, true, 10);
        if (!bFound) {
            String exception = "The InsuranceProduct is not found. Please check the product is on the page.";
            throw new NoSuchWebElementException(exception);
        }
        testLogger.info("[screen] 从列表中找到了产品：" + bFound);

    }

//    /**
//     *
//     * 标题检查公共方法
//     *
//     */
//
//    //检查定期标题
//    public void checkDingqiTitle(){
//        //先检查标题是否存在
//        boolean dingqititle = DingqiTitle.isDisplayed();
//        testAssert.assertTrue(dingqititle);
//        logger.info("定期标题是否存在?" + dingqititle);
//        logger.info("当前是" + DingqiTitle.getText() + "页面");
//    }

    /**
     *
     * 列表检查
     *
     */
    //点击所有查询条件，对结果暂未验证
    public void clickSynthetically(){
        topSyntheticallyTextView.click();
        synHorizonMaxSortTextView.click();

        topSyntheticallyTextView.click();
        synHorizonMinSortTextView.click();

        topSyntheticallyTextView.click();
        synInvestmentMaxSortTextView.click();

        topSyntheticallyTextView.click();
        synInvestmentMinSortTextView.click();

        topSyntheticallyTextView.click();
        synRateMaxSortTextView.click();

        topSyntheticallyTextView.click();
        synSortTextView.click();
    }
    //点击所有查询条件，对结果暂未验证
    public void clickInvestmentHorizon(){
        topInvestmentHorizonTextView.click();
        monthOneSortTextView.click();

        topInvestmentHorizonTextView.click();
        monthOneToThreeSortTextView.click();

        topInvestmentHorizonTextView.click();
        monthThreeToSixSortTextView.click();

        topInvestmentHorizonTextView.click();
        monthSixToTwelveSortTextView.click();


        topInvestmentHorizonTextView.click();
        monthTwelveOverSortTextView.click();

        topInvestmentHorizonTextView.click();
        monthUnlimitedSortTextView.click();
    }
    //点击所有查询条件，对结果暂未验证
    public void clickStartAmount(){
        topStartAmountTextView.click();
        amountFiveHorizonSortTextView.click();

        topStartAmountTextView.click();
        amountFiveToTenSortTextView.click();


        topStartAmountTextView.click();
        amountTenToThirtySortTextView.click();


        topStartAmountTextView.click();
        amountThirtyOverSortTextView.click();


        topStartAmountTextView.click();
        amountStartEditText.sendKeys("10");
        amountLastEditText.sendKeys("100");
        amountConfirmButton.click();

        topStartAmountTextView.click();
        amountUnlimitedSortTextView.click();
    }
    //点击所有查询条件，对结果暂未验证
    public void clickFilter(){
        topFilterTextView.click();
        earningsYicihuanbenfuxiTextView.click();
        earningsYishizhijisuanTextView.click();
        earningsUnlimitedTextView.click();

        projectCaifuhuiTextView.click();
        projectAnxinTextView.click();
        projectCaihongTextView.click();
//        projectBaoxianxinglicaiTextView.click();
        projectLixiangjiaButton.click();
        projectAnyingpiaojuTextView.click();
        projectYuegujiaoTextView.click();
        projectXintuolicaiTextView.click();
        projectUnlimitedTextView.click();

        projectYoucuxiaoTextView.click();

        projectConfirmButton.click();


    }


}
