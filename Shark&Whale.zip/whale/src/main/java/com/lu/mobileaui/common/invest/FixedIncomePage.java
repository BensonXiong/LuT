package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/13.
 *
 * 私募－－固定收益类
 *
 */
public class FixedIncomePage extends BasePageAbstract {

    //固定收益类 －－ 私募-产品简称-auto2016-04-07 17:55:58-92721
    @iOSFindBy(name = "私募-产品简称-auto2016-04-07 17:55:58-92721")
    @AndroidFindBy(name = "私募-产品简称-auto2016-04-07 17:55:58-92721")
    public WebElement FixedIncomeFiveProduct;

    public void clickFixedIncomeFiveProduct(){
        FixedIncomeFiveProduct.click();
    }
}
