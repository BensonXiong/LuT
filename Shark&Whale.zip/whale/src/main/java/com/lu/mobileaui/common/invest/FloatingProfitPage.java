package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/13.
 *
 * 私募－－浮动收益类
 *
 */
public class FloatingProfitPage extends BasePageAbstract {

    //浮动收益类 －－
    @iOSFindBy(name = "浮动收益类")
    @AndroidFindBy(name = "浮动收益类")
    public WebElement FloatingProfitButton;

    //私募-产品简称-auto2016-02-24 18:10:58-61946
    @iOSFindBy(name = "私募-产品简称-auto2016-02-24 18:10:58-61946")
    @AndroidFindBy(name = "私募-产品简称-auto2016-02-24 18:10:58-61946")
    public WebElement FloatingProfitProduct;

    public void clickFloatingProfitFirstProduct(){
        FloatingProfitButton.click();
        FloatingProfitProduct.click();
    }
}
