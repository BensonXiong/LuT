package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/13.
 *
 * 投资理财 -- 高端理财
 *
 */
public class GaoduanLicaiPage extends BasePageAbstract {

    //信托
    @iOSFindBy(name = "信托")
    @AndroidFindBy(name = "信托")
    public WebElement TrustButton;

    //私募
    @iOSFindBy(name = "私募")
    @AndroidFindBy(name = "私募")
    public WebElement PrivateplacementButton;

    //信托
    public void clickTrustButton(){
        TrustButton.click();
    }

    //私募
    public void clickPrivateplacementButton(){
        PrivateplacementButton.click();
    }
}
