package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import com.lu.mobileafw.exception.NoSuchWebElementException;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/4/21.
 *
 * 投资理财－－>活期
 *
 */

public class HuoqiPage extends BasePageAbstract {


    /**
     *
     * 产品
     *
     */


    //活期--零活宝
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATableView[1]/UIATableCell[3]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[3]/android.widget.RelativeLayout[1]")//网上钱包20160504193347662
    public WebElement HuoqiLinghuobao;

    //活期－智能宝
    @iOSFindBy(name ="智能宝20160125113403251")
    @AndroidFindBy(name = "智能宝20160125113403251")
    public WebElement HuoqiZhinengbao;

    //活期－富盈宝宝
    @iOSFindBy(name ="富盈宝宝20160602180205")
    @AndroidFindBy(name = "富盈宝宝20160602180205")//富盈宝宝1号
    public WebElement HuoqiFuyingbao;

    //货币基金
    @iOSFindBy(name ="基金代销1197号093779")
    @AndroidFindBy(name = "基金代销1197号093779")
    public WebElement HuoqiMonetaryFund;


    /**
     *
     * 标题
     *
     */

    /**
     * 活期－零活宝
     */
    //零活宝
    @iOSFindBy(name = "零活宝")
    @AndroidFindBy(name = "零活宝")//android.widget.TextView[contains(@text, '零活宝')  and @resource-id='com.lufax.android:id/text_view']
    public WebElement flexiblePoTextView;



    /**
     * 活期－智能宝
     */
    //智能宝
    @iOSFindBy(name = "智能宝")
    @AndroidFindBy(name = "智能宝")//android.widget.TextView[contains(@text, '智能宝') and @resource-id='com.lufax.android:id/text_view']
    public WebElement intellectPoTextView;

    /**
     * 活期－富盈宝宝
     */
    //富盈宝宝
    @iOSFindBy(name = "富盈宝宝")
    @AndroidFindBy(name = "富盈宝宝")//android.widget.TextView[contains(@text, '富盈宝宝')  and @resource-id='com.lufax.android:id/text_view']
    public WebElement fuyingPoPoTextView;

    /**
     * 活期－货币基金
     */
    //货币基金
    @iOSFindBy(name = "货币基金")
    @AndroidFindBy(name = "货币基金")//android.widget.TextView[contains(@text, '货币基金')  and @resource-id='com.lufax.android:id/text_view']
    public WebElement moneyFundTextView;

    /**
     * 活期－新客专享
     */
    //新客专享
    @iOSFindBy(name = "新客专享")
    @AndroidFindBy(name = "新客专享")//android.widget.TextView[contains(@text, '新客专享')]
    public WebElement newCustomerTextView;

    /**
     *
     * 产品
     *
     */

    //零活宝
    public void clickHuoqiLinghuobao(){
        HuoqiLinghuobao.click();
    }

    //智能宝
    public void clickHuoqiZhinengbao() throws NoSuchWebElementException {
        boolean bFound = driverHelper.trySearchElementByScroll(HuoqiZhinengbao, true, 10);
        if (!bFound) {
            throw new NoSuchWebElementException("The DingqiGuoHualife is not found. Please check the product is on the page.");
        }
        HuoqiZhinengbao.click();
    }

    //富盈宝宝
    public void clickFuyingbao() throws NoSuchWebElementException {
//        driverHelper.sleep(3000);
        boolean bFound = driverHelper.trySearchElementByScroll(HuoqiFuyingbao, true, 15);
        if (!bFound) {
            throw new NoSuchWebElementException("The DingqiGuoHualife is not found. Please check the product is on the page.");
        }
        HuoqiFuyingbao.click();

    }

    //货币基金
    public void clickMonetaryFund() throws NoSuchWebElementException {
//        driverHelper.sleep(3000);
        boolean bFound = driverHelper.trySearchElementByScroll(HuoqiMonetaryFund, true, 15);
        if (!bFound) {
            throw new NoSuchWebElementException("The DingqiGuoHualife is not found. Please check the product is on the page.");
        }
        HuoqiMonetaryFund.click();

    }

    /**
     *
     * 标题
     *
     */

    //检查4个板块是否存在
    public void flexiblePoTextViewIsDisplayed(){
        flexiblePoTextView.isDisplayed();
    }
    public void intellectPoTextViewIsDisplayed(){
        intellectPoTextView.isDisplayed();
    }
    public void fuyingPoPoTextViewIsDisplayed(){
        fuyingPoPoTextView.isDisplayed();
    }
    public void moneyFundTextViewIsDisplayed(){
        moneyFundTextView.isDisplayed();
    }

    public void checkFourPlateIsDisplayed(){
        flexiblePoTextViewIsDisplayed();
        intellectPoTextViewIsDisplayed();
        fuyingPoPoTextViewIsDisplayed();
        moneyFundTextViewIsDisplayed();
    }

}
