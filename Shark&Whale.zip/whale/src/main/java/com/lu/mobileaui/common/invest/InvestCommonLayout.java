package com.lu.mobileaui.common.invest;

import com.lu.mobileainfra.lma.BasePage;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/6/16.
 */
public class InvestCommonLayout extends BasePage {

    // 标题
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "base_ui_title")
//    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.RelativeLayout[1]")
    public WebElement ProductTitleLayout;

    // 产品列表
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]")
    public WebElement ProductListLayout;

}
