package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/5.
 *
 *定期－理享＋（保险类产品） --投保页面
 *
 *
 */


public class InvestInsurancePage extends BasePageAbstract {


    //常住地址 － 省或市区
    //使用绝对路径会于其他元素冲突
    @iOSFindBy(xpath = "//UIAStaticText[@name='常住地址']/following-sibling::UIAButton[1]")//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAButton[2]
    //@AndroidFindBy(id = "area")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[3]/android.widget.LinearLayout[1]/android.widget.RelativeLayout[1]/android.widget.TextView[2]")
    public WebElement PermanentAddress;

    //详细地址  在ios中无法重置app 会存在历史记录  所以用“详细地址”关键是无法找到元素   使用绝对路径会其他元素冲突  因此使用preceding 关键字
    @iOSFindBy(xpath = "//UIAStaticText[@name='电子邮箱']/preceding:: UIATextField[last()]")//UIATextField[@name='详细地址' or @value='详细地址']//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATextField[1]
    @AndroidFindBy(name = "详细地址")
    public WebElement DetailedAddressInput;

    //详细地址(选填)
    @iOSFindBy(xpath = "//*[@name='详细地址' or @value='详细地址']")
    @AndroidFindBy(xpath = "//*[contains(@text, '详细地址') or contains(@content-desc, '详细地址')]")
    public WebElement DetailedAddressExInput;



    //签约地区  使用绝对路径会于其他元素冲突，使用xpath的轴寻找
    @iOSFindBy(xpath = "//UIAStaticText[@name='签约地区']/following-sibling::UIAButton[1]")//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAButton[3]
    @AndroidFindBy(id = "sign_area")
    public WebElement SignAreaList;

    //推介人编号
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.EditText[1]")
    public WebElement RecommendPersonIDInput;

    //风险合同
    @iOSFindBy(name = "\uE606")
    @AndroidFindBy(id = "chkEnable")
    public WebElement AgreementCheckbox;

    //立即投保按钮
    @iOSFindBy(name = "立即投保")
    @AndroidFindBy(name = "立即投保")
    public WebElement InsureNowButton;

    /**
     * 确认支付方式
     */

    // 下一步
    @iOSFindBy(name = "下一步")
    @AndroidFindBy(name = "下一步")
    public WebElement NextStepButton;

    /**
     * 确认支付
     */

    // 交易密码
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[2]/UIASecureTextField[1]")  ////UIASecureTextField[@value='请输入陆金所交易密码']
    @AndroidFindBy(id = "com.lufax.android:id/s_edit")
    public WebElement TradePwdInput;

    // 立即支付
    @iOSFindBy(name = "立即支付")
    @AndroidFindBy(name = "立即支付")
    public WebElement PayNowButton;

    //保险－-国华人寿(vip)
    public void investGuoHualifeVIP(String detailedAddress, Integer RecommendPersonID, String tradePwd){
        insuranceInvestGeneralVIP(detailedAddress, RecommendPersonID, tradePwd);
    }

    //保险投保vip常规通用流程（页面上需要填写市区，详细地址，签约地区，推介人,用此方法）
    public void insuranceInvestGeneralVIP(String detailedAddress, Integer RecommendPersonID, String tradePwd){

        driverHelper.sleep(1000);

        //选择地区下拉框
        PermanentAddress.click();

        //tap点击
        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
//        driver.swipe(width / 2, height / 3, width / 2, height / 3 * 2, 2000);
        driverHelper.sleep(1000);
        driver.tap(1, height / 3, width / 2, 100);
        driverHelper.sleep(1000);

        //向上滑动
        driver.swipe(width / 2, height / 3 * 2, width / 2, height / 3, 2000);

        //详细地址填写
        DetailedAddressInput.clear();
        DetailedAddressInput.sendKeys(detailedAddress);

        //选择签约地区
        SignAreaList.click();

        //tap点击
        driverHelper.sleep(1000);
//        driver.swipe(width / 2, height / 3, width / 2, height / 3 * 2, 2000);
        driver.tap(1, height / 3, width / 2, 100);
        driverHelper.sleep(1000);
        //推介人填写
        RecommendPersonIDInput.clear();
        RecommendPersonIDInput.sendKeys(RecommendPersonID.toString());

        //勾选风险合同
        AgreementCheckbox.click();

        //立即投保
        InsureNowButton.click();
        driverHelper.sleep(5000);

//        String pageXml = driver.getPageSource();
//        logger.info(pageXml);
        //下一步
        NextStepButton.click();

        //输入交易密码
        testAssert.info("[screen] 输入交易密码");
        TradePwdInput.clear();
        TradePwdInput.sendKeys(tradePwd);

        //确认
        PayNowButton.click();
        driverHelper.sleep(5000);
    }

    //保险投保非vip常规通用流程（页面上需要填写市区，详细地址，签约地区,用此方法）
    public void insuranceInvestGeneral(String detailedAddress, String tradePwd){

        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;


        if(driverHelper.checkExist(PermanentAddress)){
            testLogger.info("选择地区下拉框");
            PermanentAddress.click();

            //tap点击
//        driver.swipe(width / 2, height / 3, width / 2, height / 3 * 2, 2000);
            driverHelper.sleep(1000);
            driver.tap(1, height / 3, width / 2, 100);

            //向下滑动
            driverHelper.sleep(1000);
        }


        //driver.swipe(width / 2, 400, width / 2, height - 400, 2000);
        testAssert.info("[screen] width:" + width + "  height:" + height);
        driver.swipe(width / 2, height / 3 * 2, width / 2, height / 3, 2000);
        //driver.swipe(width / 2, height - 400, width / 2, 1000, 2000);

        testLogger.info("详细地址填写：" + detailedAddress);
        DetailedAddressInput.clear();
        DetailedAddressInput.sendKeys(detailedAddress);

        testLogger.info("选择签约地区");
        if(driverHelper.checkExist(SignAreaList)){
            SignAreaList.click();
            driverHelper.sleep(1000);
            //tap点击  处理弹出的地址滑动栏  点击屏幕即可关闭
            //driver.swipe(width / 2, height / 3, width / 2, height / 3 * 2, 2000);
            driver.tap(1,height / 3, width / 2,100);
            driverHelper.sleep(1000);
        }

        testLogger.info("勾选风险合同");
        AgreementCheckbox.click();

        driver.swipe(width / 2, height / 2, width / 2, 10, 1000);
        testLogger.info("[screen] 点击立即投保");
        InsureNowButton.click();
        driverHelper.sleep(5000);

        testLogger.info("[screen] 点击下一步");
        NextStepButton.click();

        testLogger.info("[screen] 输入交易密码");
        TradePwdInput.clear();
        TradePwdInput.sendKeys(tradePwd);
        driverHelper.sleep(2000);

        testLogger.info("点击确认按钮");
        PayNowButton.click();
        driverHelper.sleep(5000);

    }

    //保险投保非vip常规通用流程（页面上只有确认风险合同，立即投保按钮两个元素,用此方法）
    public void insuranceInvest(String tradePwd){
        driverHelper.sleep(5000);
        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
//        driver.swipe(width / 2, height-400, width / 2, 1000, 2000);
        driver.swipe(width / 2, height/5, width / 2, height/5*4, 2000);
        driverHelper.sleep(5000);
        //确认风险合同
        AgreementCheckbox.click();

        //立即投保
        InsureNowButton.click();

        driverHelper.sleep(5000);

//        String pageXml = driver.getPageSource();
//        logger.info(pageXml);
        //下一步
        NextStepButton.click();

        //输入交易密码
        testAssert.info("[screen] 输入交易密码");
        TradePwdInput.clear();
        TradePwdInput.sendKeys(tradePwd);

        //确定
        PayNowButton.click();
        driverHelper.sleep(5000);
    }

    //保险－-渤海人寿
    public void investBoHailife(String tradePwd){
        insuranceInvest(tradePwd);

    }

    //保险－-新珠江人寿
    public void investZhuJianglife(String detailedAddress, String tradePwd){
        insuranceInvestGeneral(detailedAddress, tradePwd);

    }

    //保险－-平安人寿
    public void investPingAnlife(String tradePwd){
        insuranceInvest(tradePwd);

    }

    //保险－-国华人寿
    public void investGuoHualife(String detailedAddress, String tradePwd){
        insuranceInvestGeneral(detailedAddress, tradePwd);

    }

    //保险－-信泰人寿
    public void investXinTailife(String detailedAddress, String tradePwd) {
        insuranceInvestGeneral(detailedAddress, tradePwd);

    }

    //保险－-中融人寿
    public void investZhongRonglife(String detailedAddress, String tradePwd) {
        insuranceInvestGeneral(detailedAddress, tradePwd);

    }

    //保险－-恒大人寿
    public void investHengDalife(String tradePwd) {
        insuranceInvest(tradePwd);

    }

    //保险－-天安人寿
    public void investTianAnlife(String detailedAddress, String tradePwd){
        insuranceInvestGeneral(detailedAddress, tradePwd);

    }

    //保险－-百年人寿
    public void investBaiNianlife(String detailedAddress, String tradePwd) {
        insuranceInvestGeneral(detailedAddress, tradePwd);

    }

    //保险－-生命人寿
    public void investShengMinglife(String detailedAddress, String tradePwd){
        insuranceInvestGeneral(detailedAddress, tradePwd);

    }

    //保险－-阳光人寿
    public void investYangGuanglife(String detailedAddress, String tradePwd){
        insuranceInvestGeneral(detailedAddress, tradePwd);

    }

    //保险－-君康人寿
    public void investJunKanglife(String detailedAddress, String tradePwd) {
        insuranceInvestGeneral(detailedAddress, tradePwd);

    }

    //保险－-前海人寿
    public void investQianHailife(String detailedAddress, String tradePwd) {
        insuranceInvestGeneral(detailedAddress, tradePwd);

    }

    //保险－-华夏人寿
    public void investHuaXialife(String detailedAddress, String tradePwd) {
        insuranceInvestGeneral(detailedAddress, tradePwd);

    }

    //保险－-合众人寿
    public void investHeZhonglife(String detailedAddress, String tradePwd) {
        insuranceInvestGeneral(detailedAddress, tradePwd);
    }

    //新手专区－-平安人寿
    public void NewbieAreaPingAnlife(String detailedAddress, String tradePwd) {

        //详细地址填写
        DetailedAddressExInput.clear();
        DetailedAddressExInput.sendKeys(detailedAddress);

        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        driver.swipe(width / 2, height - 200, width / 2, 1000, 2000);
//        driverHelper.trySearchElementByScroll(AgreementCheckbox,true,3);

        //勾选风险合同
        AgreementCheckbox.click();


        //立即投保
        driverHelper.trySearchElementByScroll(InsureNowButton,true,3);
        InsureNowButton.click();

        driverHelper.sleep(5000);

        //下一步
        NextStepButton.click();

        //输入交易密码
        testAssert.info("[screen] 输入交易密码");
        TradePwdInput.clear();
        TradePwdInput.sendKeys(tradePwd);

        //确认
        PayNowButton.click();
        driverHelper.sleep(5000);
    }

}
