package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import com.lu.mobileainfra.be.LuTestBeEnv;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/4/13.
 *
 * 投资页
 *
 */

public class InvestmentConfirmPage extends BasePageAbstract {

    /**
     *
     * 高端理财
     *
     */
    //信托直营
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]")
    public WebElement InvestTrustDirect;

    //选择地址
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(xpath = "//android.widget.ListView[1]/android.widget.RelativeLayout[1]/android.widget.RelativeLayout[1]")
    public WebElement SelectAddress;

    //获取动态码
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(name = "获取动态码")
    public WebElement RefreshDynCodeButton;

    //输入动态码
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(name = "7位数字")
    public WebElement DyncodeInput;

    /**
     *
     * 标题检查
     *
     */

    // 投资
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIANavigationBar[1]/UIAStaticText[1]")
    @AndroidFindBy(name = "投资")
    public WebElement InvestTitle;

    /**
     * 确认风险合约
     */

    // 风险合约声明确认框
    @iOSFindBy(name = "\uE606")
    @AndroidFindBy(id = "com.lufax.android:id/chkEnable") // android.widget.CheckBox
    public WebElement AgreementCheckbox;

    /**
     * 确认风险合约
     *
     * 通过 本人已阅读 元素位置点击 风险合约声明确认框
     */

    // 风险合约声明确认框
    @iOSFindBy(name = "\uE606")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@content-desc,'本人已阅读') or contains(@text,'本人已阅读')]")
    public WebElement ReadButton;

    // 立即投资
    @iOSFindBy(name = "立即投资")
    @AndroidFindBy(id = "btn_invest")
    public WebElement InvestNowButton;

    /**
     * 确认支付方式
     */

    // 下一步
    @iOSFindBy(name = "下一步")
    @AndroidFindBy(id = "btn_next")
    public WebElement NextStepButton;

    /**
     * 确认支付
     */

    // 交易密码
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[2]/UIASecureTextField[1]")
    @AndroidFindBy(id = "com.lufax.android:id/s_edit")
    public WebElement TradePwdInput;

    // 起投金额
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[2]/UIASecureTextField[1]")
    @AndroidFindBy(id = "tv_sort_type")
    public WebElement StartAmount;



    // 交易密码  出现两个文本输入框时  一个是短信码  这个是交易密码  ID都一致 所以这里以路径
    @iOSFindBy(name = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[2]/UIASecureTextField[1]")
//    @AndroidFindBy(xpath = "")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.EditText[1]")
    public WebElement TradePwdInput2;


    // 立即支付
    @iOSFindBy(name = "立即支付")
    @AndroidFindBy(id = "com.lufax.android:id/btn_confirm")
    public WebElement TradeConfirmButton;


    //现金管理
    public void confirmInvestment(String tradePwd) {

        confirmProduct(tradePwd);

    }

    //活期--零活宝
    public void confirmLinghuobao(String tradePwd){

        confirmProduct(tradePwd);

    }

    //活期--智能宝
    public void confirmZhinengbao(String tradePwd){

        confirmProduct(tradePwd);

    }

    //活期－富盈宝宝
    public void confirmFuyingbao(String tradePwd){

        confirmProduct(tradePwd);

    }

    //活期－货币基金
    public void confirmMonetaryFund(String tradePwd) {

        confirmProductFund(tradePwd);

    }

    //定期－财富汇
    public void confirmCaifuhui(String tradePwd){

        confirmProduct(tradePwd);

    }

    //定期－安鑫
    public void confirmAnXin(String tradePwd){

        confirmProduct(tradePwd);

    }

    //定期－彩虹
    public void confirmCaiHong(String tradePwd){

        confirmProductFund(tradePwd);

    }

    //定期－票据
    public void confirmAnyingPiaoJu(String tradePwd){

        confirmProduct(tradePwd);

    }

    //定期－粤股交
    public void confirmYueGuJiao(String tradePwd){

        confirmProduct(tradePwd);

    }

    //定期－信托理财投资
    public void confirmTrustInvestment(String tradePwd){

        confirmProduct(tradePwd);

    }

    //活期--P2P稳盈保障类
    public void confirmP2PWenying(String tradePwd){

        confirmProduct(tradePwd);

    }

    //P2P稳盈安e（901）
    public void confirmP2PWenyingAnyi(String tradePwd){

        confirmProduct(tradePwd);

    }

    //P2P点金计划（901）
    public void confirmP2PDianjinJihua901(String tradePwd){

        confirmProduct(tradePwd);

    }

    //P2P点金计划（902）
    public void confirmP2PDianjinJihua902(String tradePwd){

        confirmProduct(tradePwd);

    }

    //新手专区
    public void confirmNewbieArea(String tradePwd){

        confirmProduct(tradePwd);

    }

    //富盈人寿－保险产品
    public void confirmFuYingLife(String tradePwd){

        confirmProduct(tradePwd);

    }

    private void ReadButton(){
        int X = ReadButton.getLocation().getX();
        int Y = ReadButton.getLocation().getY();
        driver.tap(1, X / 2, Y + 10, 100);
    }
    private void confirmProduct(String tradePwd) {

        //先检查标题是否存在
        boolean investtitle = InvestTitle.isDisplayed();
        testAssert.assertTrue(investtitle, "[screen] 检查标题是否存在");
        logger.info("投资标题是否存在?" + investtitle);
        testLogger.info("当前是" + InvestTitle.getText() + "页面");

        logger.info("confirm the agreement");

        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        driver.swipe(width / 2, (int)(height * 0.9), width / 2, (int)(height * 0.2), 1000);

        AgreementCheckbox.click();
        testLogger.info("[screen]勾选同意按钮");
        InvestNowButton.click();
        testLogger.info("[screen] 点击下一步");
        NextStepButton.click();
        logger.info("input the trade password");
        TradePwdInput.clear();
        TradePwdInput.sendKeys(tradePwd);
        testLogger.info("[screen] 输入交易密码");
        TradeConfirmButton.click();

    }

    private void confirmProductFund(String tradePwd) {

        //先检查标题是否存在
        boolean investtitle = InvestTitle.isDisplayed();
        testAssert.assertTrue(investtitle, "检查标题是否存在");
        logger.info("投资标题是否存在?" + investtitle);
        logger.info("当前是" + InvestTitle.getText() + "页面");

        logger.info("confirm the agreement");

        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        driver.swipe(width / 2, (int)(height * 0.9), width / 2, (int)(height * 0.2), 1000);

        ReadButton();
//        AgreementCheckbox.click();
        InvestNowButton.click();
        NextStepButton.click();
        logger.info("input the trade password");
        TradePwdInput.clear();
        TradePwdInput.sendKeys(tradePwd);
        TradeConfirmButton.click();

    }

    //信托直营
    public void confirmInvestTrustDirect(String tradePwd){

        //先检查标题是否存在
        boolean investtitle = InvestTitle.isDisplayed();
        testAssert.assertTrue(investtitle, "检查标题是否存在");
        logger.info("投资标题是否存在?" + investtitle);
        logger.info("当前是" + InvestTitle.getText() + "页面");

        logger.info("confirm the agreement");

        InvestTrustDirect.click();
        SelectAddress.click();

        driverHelper.sleep(3000);

        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        driver.swipe(width / 2, (int)(height * 0.9), width / 2, (int)(height * 0.2), 1000);

        AgreementCheckbox.click();
        InvestNowButton.click();
        NextStepButton.click();
        logger.info("input the trade password");
        TradePwdInput.clear();
        TradePwdInput.sendKeys(tradePwd);
        TradeConfirmButton.click();

    }

    //私募－－固定收益类
    public void confirmInvestFixedIncome(String tradePwd,LuTestBeEnv testBeEnv){

        //先检查标题是否存在
        boolean investtitle = InvestTitle.isDisplayed();
        testAssert.assertTrue(investtitle, "检查标题是否存在");
        logger.info("投资标题是否存在?" + investtitle);
        logger.info("当前是" + InvestTitle.getText() + "页面");

        logger.info("confirm the agreement");


        driverHelper.sleep(3000);

        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        driver.swipe(width / 2, (int)(height * 0.9), width / 2, (int)(height * 0.2), 1000);

        AgreementCheckbox.click();
        InvestNowButton.click();
        NextStepButton.click();
        //点击获取动态码
        RefreshDynCodeButton.click();
        //输入动态码
        DyncodeInput.sendKeys(testBeEnv.getSms());
        logger.info("input the trade password");
        TradePwdInput2.click();
        // 交易密码  点击TradePwdInput2时  页面回重新加载  此时只有一个文本框
        TradePwdInput.clear();
        TradePwdInput.sendKeys(tradePwd);
        TradeConfirmButton.click();

    }

    //私募－－浮动收益类
    public void confirmInvestFloatingProfit(String tradePwd,LuTestBeEnv testBeEnv){

        //先检查标题是否存在
        boolean investtitle = InvestTitle.isDisplayed();
        testAssert.assertTrue(investtitle, "检查标题是否存在");
        logger.info("投资标题是否存在?" + investtitle);
        logger.info("当前是" + InvestTitle.getText() + "页面");

        logger.info("confirm the agreement");

        driverHelper.sleep(3000);

        int width=driver.manage().window().getSize().width;
        int height = driver.manage().window().getSize().height;
        driver.swipe(width / 2, (int)(height * 0.9), width / 2, (int)(height * 0.2), 1000);

        AgreementCheckbox.click();
        InvestNowButton.click();
        NextStepButton.click();
        //点击获取动态码
        RefreshDynCodeButton.click();
        //输入动态码
        DyncodeInput.sendKeys(testBeEnv.getSms());
        logger.info("input the trade password");
        TradePwdInput2.click();
        // 交易密码  点击TradePwdInput2时  页面回重新加载  此时只有一个文本框
        TradePwdInput.clear();
        TradePwdInput.sendKeys(tradePwd);
        TradeConfirmButton.click();

    }

    //会员交易区－－定期转让－－财富汇
    public void confirmCaiFuHuiProduct(String tradePwd){

        confirmProduct(tradePwd);

    }

    //会员交易区－－定期转让－－安鑫
    public void confirmAnxinProduct(String tradePwd){

        confirmProduct(tradePwd);

    }

    //会员交易区－－定期转让－－彩虹
    public void confirmCaiHongProduct(String tradePwd){

        confirmProduct(tradePwd);

    }

    //会员交易区－－p2p转让－－一口价，稳应安e
    public void confirmP2PWenYingAnYi(String tradePwd){

        confirmProduct(tradePwd);

    }

}
