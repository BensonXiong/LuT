package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import com.lu.mobileafw.exception.NoSuchWebElementException;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

import static com.lu.mobileafw.app.TestHelper.checkExist;

/**
 * Created by huangyinhuang on 16/3/31.
 *
 * 投资理财首页
 *
 */


public class InvestmentPage extends BasePageAbstract {


    /**
     * 投资理财首页
     */



    /**
     *
     * 投资理财首页最上面一排的导航栏产品类型
     */
    //保险按钮
    @iOSFindBy(name = "保险")//UIANavigationBar[1]/UIAButton[contains(@name,'保险')]
    @AndroidFindBy(name = "保险")
    public WebElement InsuranceButton;

    //基金按钮
    @iOSFindBy(name = "基金")
    @AndroidFindBy(name = "基金")
    public WebElement JiJinButton;

    //股票按钮
    @iOSFindBy(name = "股票")
    @AndroidFindBy(name = "股票")
    public WebElement StockButton;

    /**
     *
     * 投资理财首页最上面一排的导航栏产品类型
     */

    //活期
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'活期')]/..")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.lufax.android:id/title_text' and @text='活期']")
    public WebElement HuoqiButton;

    //活期数量
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'活期')]/../UIAStaticText[4]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='活期' and @resource-id='com.lufax.android:id/title_text']/following-sibling::android.widget.TextView[1]")
    public WebElement HuoqiNumButton;


    // 定期
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'定期')]/..")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.lufax.android:id/title_text' and @text='定期']")
    public WebElement DingqiButton;

    //定期数量
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'定期')]/../UIAStaticText[4]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='定期' and @resource-id='com.lufax.android:id/title_text']/following-sibling::android.widget.TextView[1]")
    public WebElement DingqiNumButton;

    //新手专区
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'新手专区')]/..")
    @AndroidFindBy(name = "新手专区")
    public WebElement NewbieAreaButton;

    //新手专区数量
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'新手专区')]/../UIAStaticText[4]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='新手专区' and @resource-id='com.lufax.android:id/title_text']/following-sibling::android.widget.TextView[1]")
    public WebElement NewbieAreaNumButton;

    //P2P
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'P2P')]/..")
    @AndroidFindBy(name = "P2P")
    public WebElement P2pButton;

    //P2P数量
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'P2P')]/../UIAStaticText[4]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='P2P' and @resource-id='com.lufax.android:id/title_text']/following-sibling::android.widget.TextView[1]")
    public WebElement P2PNumButton;


    //高端理财
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'高端理财')]/..")
    @AndroidFindBy(name = "高端理财")
    public WebElement GaoduanlicaiButton;

    //高端理财数量
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'高端理财')]/../UIAStaticText[4]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='高端理财' and @resource-id='com.lufax.android:id/title_text']/following-sibling::android.widget.TextView[1]")
    public WebElement GaoduanlicaiNumButton;


    // 会员交易区
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'会员交易区')]/..")
    @AndroidFindBy(name = "会员交易区")
    //@AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.lufax.android:id/title_text' and @text='会员交易区']")
    public WebElement VipButton;
    //会员交易区数量
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'会员交易区')]/../UIAStaticText[4]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='会员交易区' and @resource-id='com.lufax.android:id/title_text']/following-sibling::android.widget.TextView[1]")
    public WebElement VipNumButton;

    //VIP专属投资项目
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'VIP专属投资项目')]/..")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id='com.lufax.android:id/title_text' and @text='VIP专属投资项目']")
    public WebElement VipExclusiveButton;
    //VIP专属投资项目数量
    @iOSFindBy(xpath = "//UIATableView[1]/UIATableCell[position()>1]/UIAStaticText[contains(@name,'VIP专属投资项目')]/../UIAStaticText[4]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='VIP专属投资项目' and @resource-id='com.lufax.android:id/title_text']/following-sibling::android.widget.TextView[1]")
    public WebElement VipExclusiveNumButton;


    //未知元素
//    // 灵活宝
//    @iOSFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.RelativeLayout[2]/android.support.v4.view.ViewPager[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.ListView[1]/android.widget.LinearLayout[2]/android.widget.RelativeLayout[1]")
//    @AndroidFindBy(id = "")
//    public WebElement LinghuobaoButton;
//
//    // 现金管理
//    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[1]")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '现金管理')]")
//    public WebElement CashManagmentButton;
//
//    // 专享理财
//    @iOSFindBy(xpath = "NA")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '专享理财')]")
//    public WebElement InvestVIPManagmentButton;
//
//    // 点金计划
//    @iOSFindBy(xpath = "NA")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '点金计划')]")
//    public WebElement DianJingPlanButton;

    /**
     * 提示页
     */

    //分类内容全新整合－－定期orP2P
    @iOSFindBy(name = "P2P")//未找到
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]")
    public WebElement PromptNewContents;

    //股票频道上线啦
    @iOSFindBy(name = "上线啦")//未找到
    @AndroidFindBy(id = "com.lufax.android:id/horizontal_layout")
    public WebElement PromptStockChannelOnline;


    //新手专区
    public void clickNewbieArea() throws NoSuchWebElementException {

        boolean bFound = driverHelper.trySearchElementByScroll(NewbieAreaButton, true, 10);
        if (!bFound) {
            throw new NoSuchWebElementException("The selectVIPExclusiveInvestProduct is not found. Please check the product is on the page.");
        }
        driver.tap(1, 400, 1000, 100);
        NewbieAreaButton.click();

    }

    //公共方法－－向下滑动
    public void scrollTo(){
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        driver.swipe(width / 2, height - 400, width / 2, 1000, 2000);
    }

    //公共方法－－判断广告是否存在然后点击
    public void skipPrompt() {

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        boolean bExist = checkExist(PromptNewContents);
        if (bExist) {
            PromptNewContents.click();
        }

        bExist = checkExist(PromptStockChannelOnline);
        if (bExist) {
            PromptStockChannelOnline.click();
        }
    }

    //P2P稳盈保障类
    public void selectP2p(){

        P2pButton.click();

        // 切换页面等待15秒
        driverHelper.sleep(15000);

    }

    //活期
    public void selectHuoqi(){

        HuoqiButton.click();

        // 切换页面等待15秒
        driverHelper.sleep(15000);

    }

    //定期
    public void selectDingqi(){

        testLogger.info("点击定期按钮");
        DingqiButton.click();

        // 切换页面等待15秒
        driverHelper.sleep(15000);

    }

    //保险
    public void clickInsuranceButton(){
        InsuranceButton.click();
    }

    //基金
    public void clickJiJinButton(){
        JiJinButton.click();
    }

    //股票
    public void clickStockButton(){
        StockButton.click();
    }

    //高端理财
    public void clickGaoduanlicaiButton(){
        GaoduanlicaiButton.click();
    }

    //VIP专属投资项目
    public void selectVIPExclusiveInvestProduct() throws NoSuchWebElementException {

        boolean bFound = driverHelper.trySearchElementByScroll(VipExclusiveButton, true, 10);
        if (!bFound) {
            throw new NoSuchWebElementException("The selectVIPExclusiveInvestProduct is not found. Please check the product is on the page.");
        }
        driver.tap(1,400,1000,100);
        VipExclusiveButton.click();

    }

    //会员交易区
    public void selectVIPTradArea() throws NoSuchWebElementException {

        boolean bFound = driverHelper.trySearchElementByScroll(VipButton, true, 10);
        if (!bFound) {
            throw new NoSuchWebElementException("The selectVIPExclusiveInvestProduct is not found. Please check the product is on the page.");
        }
        VipButton.click();

    }

}
