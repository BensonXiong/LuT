package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/4/13.
 *
 * 投资申请已提交页（最后提示页）
 *
 */

public class InvestmentViewPage extends BasePageAbstract {

    /**
     *
     * 标题检查
     *
     */

    // 提示
    @iOSFindBy(name = "提示")
    @AndroidFindBy(name = "提示")
    public WebElement PromptTitle;

    //投资申请已提交
    @iOSFindBy(name = "投资申请已提交")
    @AndroidFindBy(name = "投资申请已提交")
    public WebElement InvestmentTZView;

    //投保申请已提交
    @iOSFindBy(name = "投保申请已提交")
    @AndroidFindBy(name = "投保申请已提交")
    public WebElement InvestmentTBView;

    /**
     *
     * 页面元素
     *
     */

    // 浏览其它项目
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(id = "to_other_product_btn")
    public WebElement BrowserOtherProjectButton;

    // 查看申请
    @iOSFindBy(name = "查看申请")
    @AndroidFindBy(id = "to_details_btn")
    public WebElement CheckApplicationDetailsButton;

    // 完成
    @iOSFindBy(name = "完成")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement CompleteButton;

    // 点击完成按钮
    public void clickCompleteButton() {
        testLogger.info("[screen]投资完成");
        CompleteButton.click();
    }

}
