package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/4/25.
 *
 * 投资理财－－新手专区
 *
 */

public class NewbieAreaPage extends BasePageAbstract {

    // 产品－－平安人寿6个月4r0
    @iOSFindBy(name = "平安人寿6个月5wp")
    @AndroidFindBy(name = "平安人寿6个月5wp")
    public WebElement PingAnlifeProduct;

    //我可投的
    @iOSFindBy(name = "我可投的")
    @AndroidFindBy(name = "我可投的")
    public WebElement MyInsuranceButton;

    //全部项目
    @iOSFindBy(name = "全部项目")
    @AndroidFindBy(name = "全部项目")
    public WebElement AllProductButton;

    public void clickNewbieAreaProduct(){

        AllProductButton.click();
        PingAnlifeProduct.click();
    }

}
