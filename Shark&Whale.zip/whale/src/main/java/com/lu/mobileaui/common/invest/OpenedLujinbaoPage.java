package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/13.
 *
 * 开通陆金宝
 *
 */
public class OpenedLujinbaoPage extends BasePageAbstract {

    /**
     * 确认风险合约
     */

    // 风险合约声明确认框
    @iOSFindBy(name = "\uE606")
    @AndroidFindBy(id = "//android.webkit.WebView[1]/android.view.View[1]/android.view.View[12]") // android.widget.CheckBox
    public WebElement AgreementCheckbox;

    // 确定
    @iOSFindBy(name = "立即投资")
    @AndroidFindBy(name = "确定")
    public WebElement ConfirmButton;

    public void clickOpenedLujinbao(){

        int x,y;
        x = AgreementCheckbox.getLocation().getX();
        y = AgreementCheckbox.getLocation().getY();
        x = x+60;
        y = y+60;
        driver.tap(1,x,y,100);

        ConfirmButton.click();

    }

}
