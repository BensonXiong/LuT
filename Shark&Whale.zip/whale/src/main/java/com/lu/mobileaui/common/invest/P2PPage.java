package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import com.lu.mobileafw.exception.NoSuchWebElementException;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/4/27.
 *
 * 投资理财页 －> P2P页面
 *
 */
public class P2PPage extends BasePageAbstract {


    /**
     * 产品 -－ 一口价
     * 稳盈安e
     */

    //P2P－稳盈安e(901)
    @iOSFindBy(xpath = "//UIAStaticText[@name='一口价']/..")
//    @AndroidFindBy(name = "稳盈-安e 15032600067")
//    @AndroidFindBy(name = "一口价")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'一口价')]/parent::*/parent::*/parent::*")
    public WebElement WenYingAnyiYikoujia;

    /**
     * 点金计划
     *
     */

    //点金计划（901）
    @iOSFindBy(name = "点金计划1  稳盈-安e系列(36个月) + 陆金宝服务")//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATableView[1]/UIATableCell[2]
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.RelativeLayout[1]")
    //@AndroidFindBy(name = "点金计划1  稳盈-安e系列(36个月) + 陆金宝服务")
    public WebElement DianJinPlan901;

    //点金计划（902）
    @iOSFindBy(name = "点金计划5  稳盈-安e系列(36个月) + 陆金宝服务")//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIATableView[1]/UIATableCell[4]
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[4]/android.widget.RelativeLayout[1]")
    //@AndroidFindBy(name = "点金计划5  稳盈-安e系列(36个月) + 陆金宝服务")
    public WebElement DianJinPlan902;



    /**
     * P2P－稳盈保障类
     */

    //P2P－稳盈保障类
    @iOSFindBy(name = "稳盈-安e 3.5万元起")
    @AndroidFindBy(name = "稳盈-安e 3.5万元起")
    public WebElement WenYingAnyiGuarantee;



    /**
     *
     * 标题
     *
     */

    /**
     * P2P－点金计划
     */
    //点金计划
    @iOSFindBy(name = "点金计划")
    @AndroidFindBy(name = "点金计划")
    public WebElement titleGoldPlanTextView;

    /**
     * P2P－稳盈-保障类
     */
    //稳盈-保障类
    @iOSFindBy(name = "稳盈-保障类")
    @AndroidFindBy(name = "稳盈-保障类")
    public WebElement titleWenyingTextView;

    /**
     * P2P－稳盈-保障类-展开
     */
    //P2P－稳盈-保障类
    @iOSFindBy(name = "展开")
    @AndroidFindBy(id ="expand_desc")
    public WebElement expandDescTextView;


    //P2P－稳盈保障类
    public void selectWenYingProduct() throws NoSuchWebElementException {

//        driverHelper.sleep(5000);
//
//        int width=driver.manage().window().getSize().width;
//        int height=driver.manage().window().getSize().height;
//        driver.swipe(width / 2, height - 400, width / 2, 1000, 2000);
        driverHelper.trySearchElementByScroll(WenYingAnyiGuarantee,true,10);

        WenYingAnyiGuarantee.click();

    }

    //P2P－稳盈安e(901)
    public void clickWenyingAnyiYikoujia() throws NoSuchWebElementException {
        boolean bFound = driverHelper.trySearchElementByScroll(WenYingAnyiYikoujia, true, 10);
        if (!bFound) {
            throw new NoSuchWebElementException("The DingqiGuoHualife is not found. Please check the product is on the page.");
        }
        WenYingAnyiYikoujia.click();
    }

    //点金计划（901）
    public void clickDianjinJihua901(){
        DianJinPlan901.click();
    }

    //点金计划（902）
    public void clickDianjinJihua902(){
        DianJinPlan902.click();
    }

}
