package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/27.
 *
 *
 * 活期－查看定期投资－修改计划－计划详情
 *
 */
public class PlanDetailsPage extends BasePageAbstract {

    // 修改计划
    @iOSFindBy(name = "修改计划")
    @AndroidFindBy(name = "修改计划")
    public WebElement ModifyPlanButton;

    // 结束计划
    @iOSFindBy(name = "结束计划")
    @AndroidFindBy(name = "结束计划")
    public WebElement OverPlanButton;

    public void clickPlanDetails(){

        ModifyPlanButton.click();

    }

}
