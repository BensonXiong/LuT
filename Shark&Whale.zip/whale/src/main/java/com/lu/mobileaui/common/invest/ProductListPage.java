package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/4/27.
 *
 * 产品在列表中展示时，显示的所有字段，不相同项目展示的字段基本一致
 */
public class ProductListPage extends BasePageAbstract {

    /**
     * 产品名称
     */

    // 产品名称
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "product_name")
    public WebElement productName;

    /**
     * 产品利率
     */
    //产品利率
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "product_rofit")
    public WebElement productRofit;

    /**
     * 产品利率描述
     */
    //产品利率描述
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "product_rofit_descripton")
    public WebElement productRofitDescripton;

    /**
     * 产品保底收益
     */
    //产品保底收益
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "product_credit_content")
    public WebElement productCreditContent;

    /**
     * 产品回款说明
     */
    //产品回款说明
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "product_duration_or_description")
    public WebElement productDurationOrDescription;

    /**
     * 产品起投说明
     */
    //产品起投说明
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "product_duration_tag")
    public WebElement productDurationTag;


    /**
     * 产品起投金额
     */
    //产品起投金额
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "product_min_amount")
    public WebElement productMinAmount;

    /**
     * 产品状态
     */
    //产品状态
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "product_trade_status")
    public WebElement productTradeStatus;




    /**
     * 新客专享
     */
    //新客专享
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "新客专享")
    public WebElement productNewCustom;


    /**
     * 首投专享
     */
    //首投专享
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "首投专享")
    public WebElement productFirstCustom;

    /**
     * VIP
     */
    //VIP
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "VIP")
    public WebElement productVIPCustom;

    /**
     * 手机专享
     */
    //手机专享
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "手机专享")
    public WebElement productPhoneCustom;

    /**
     * 促销
     */
    //促销
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "手机专享")
    public WebElement productPromotionCustom;

}
