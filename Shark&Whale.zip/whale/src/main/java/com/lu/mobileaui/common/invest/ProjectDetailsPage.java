package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

import static com.lu.mobileafw.app.TestHelper.checkExist;

/**
 * Created by huangyinhuang on 16/4/13.
 *
 * 项目详情页
 *
 */

public class ProjectDetailsPage extends BasePageAbstract {

    /**
     * 保险
     * 百万任我行
     *
     */
    // 立即投保
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(name = "立即投保")
    public WebElement InsuranceNowButton;

    /**
     *
     * 标题检查
     *
     */

    // 项目详情  android活期基金的标题使用的是产品名称 故使用xpath  找到返回按钮--同级节点－－子节点
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIANavigationBar[1]/UIAStaticText[1]")
    @AndroidFindBy(xpath = "//android.widget.RelativeLayout[@resource-id='com.lufax.android:id/title_bar_left_container']/following-sibling::*[1]/descendant::android.widget.TextView[position()<=2][last()]")//id = title_bar_title_tv  name = 项目详情
    public WebElement ProjectDetailsTitle;

    /**
     *
     * 广告
     *
     */

    //固定日期自动投，省心省力赚收益
    @iOSFindBy(name = "5419_reserved_invest_guid")//name: 5419_reserved_invest_guid  //UIAApplication[1]/UIAWindow[1]/UIAImage[2]
    //@AndroidFindBy(xpath = "//android.widget.RelativeLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.view.View[1]")
    @AndroidFindBy(xpath = "//android.widget.RelativeLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.ImageView[1]")
    public WebElement ProjectTitleBar;

    /**
     * 投资金额（弹出框1）
     */

    // 投资金额
    @iOSFindBy(xpath = "//UIATextField[1]")
    @AndroidFindBy(id = "etPrice")
    public WebElement InvestmentAmountInput;

    // 立即投资按钮  1） 存在UIButton 和 UIATextField 故使用＊ 2）使用visible 存在两个页面元素一样的元素时选显示的那个
    @iOSFindBy(xpath = "//*[contains(@name,'立即投资') and @visible='true']")//*[contains(@name,'立即投资')]//UIAApplication[1]/UIAWindow[1]/UIAButton[3]  立即投资
    @AndroidFindBy(name = "立即投资")
    //@AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.Button[2]")
    public WebElement InvestNowButton;

    /**
     * 投资金额（弹出框2）
     */

    // 投资金额
    @iOSFindBy(xpath = "//UIATextField[1]")
    @AndroidFindBy(id = "input_etPrice")
    public WebElement InvestmentAmountInputEx;

    // 弹出金额页面中的   立即投资  按钮
    @iOSFindBy(name = "立即投资")//UIAApplication[1]/UIAWindow[1]/UIAButton[4]
    @AndroidFindBy(id = "com.lufax.android:id/input_btnAction") //com.lufax.android:id/btnAction
    public WebElement InvestNowButtonEx;


    /**
     * 投资金额（弹出框3）
     * ET=EditText
     */
    //特殊案例
    //p2p-- 投资金额
    @iOSFindBy(xpath = "//UIATextField[1]")
    @AndroidFindBy(xpath = "//android.view.View[34]/android.widget.EditText[1]")
    public WebElement InvestAmountInputSpecial;

    //定期-- 投资金额
    @iOSFindBy(xpath = "//UIATextField[1]")
    @AndroidFindBy(xpath = "//android.view.View[37]/android.widget.EditText[1]")
    public WebElement DingqiInvestAmount;

    //定期--票据-- 投资金额
    @iOSFindBy(xpath = "//UIATextField[1]")
    @AndroidFindBy(xpath = "//android.view.View[30]/android.widget.EditText[1]")
    public WebElement DingqiPiaoJuInvestAmount;

    // 投资金额
    @iOSFindBy(xpath = "//UIATextField[1]")
    @AndroidFindBy(name = "投资金额")
    public WebElement InvestmentAmountInputET;

    // 立即投资按钮
    @iOSFindBy(name = "立即投资")//UIAApplication[1]/UIAWindow[1]/UIAButton[3]
    @AndroidFindBy(name = "立即投资")
    public WebElement InvestNowButtonET;

    /**
     * 特例
     * 保险产品－富盈人寿投资金额
     *
     */
    // 投资金额
    @iOSFindBy(xpath = "//UIATextField[1]")
    @AndroidFindBy(xpath = "//android.view.View[23]/android.widget.EditText[1]")
    public WebElement InsuranceInvestmentAmount;

    /**
     *
     *进入项目详情，点击定期投资
     * 定期投资计划页面
     *
     */

    // 定期投资按钮
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAButton[2]")
    @AndroidFindBy(name = "定期投资")
    public WebElement InvestDingqiButton;


    //确定按钮
    @iOSFindBy(name = "确定")
    @AndroidFindBy(id = "confirmButton")
    public WebElement ConfirmButton;


    // 查看定期投资
    @iOSFindBy(name = "查看定期投资")
    @AndroidFindBy(name = "查看定期投资")
    public WebElement ModifyDingqiInvestButton;

    /**
     * 新手引导页
     */


    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "reserverd_freshguide_bottom")
    public WebElement FreshGuideButton;

    /**
     * P2P-稳盈安e－项目详情
     */

    //投资按钮
    @iOSFindBy(name = "投资")
    @AndroidFindBy(name = "投资")
    public WebElement InvestButton;

    /**
     * 高端理财－－私募
     */

    //确认投资
    @iOSFindBy(name = "确认投资")
    @AndroidFindBy(name = "确认投资")
    public WebElement InvestConfirmButton;


    //新手引导页方法
    public void skipFreshGuide() {


        Boolean bExist = checkExist(FreshGuideButton);
        testAssert.info("是否存在新手引导页：" + bExist );
        if (bExist) {
            testAssert.info("[screen] 点击新手引导页");
            FreshGuideButton.click();
        }

    }
    //固定日期自动投，省心省力赚收益方法
    public void skipProjectTitleBar(){
        Boolean bExist = checkExist(ProjectTitleBar);
        testAssert.info("是否存在省心省力赚收益页面 " + bExist);
        if(bExist) {
            testAssert.info("[screen] 点击省心省力赚收益页面");
            ProjectTitleBar.click();
        }
    }

    public void topSwipe(){
//        testAssert.info("[screen] debug width or heigth");
        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        driver.swipe(width / 2, (int)(height * 0.9), width / 2, (int)(height * 0.2), 1000);
        testAssert.info("上滑一次");
    }
    

    //检查标题是否存在
    public void checkProjectDetailsTitle(){

        boolean projectdetailstitle = ProjectDetailsTitle.isDisplayed();
        testAssert.assertTrue(projectdetailstitle, "[screen] 检查\"项目详情标题\"是否存在" + projectdetailstitle);
//        testAssert.info("项目详情标题是否存在?" + projectdetailstitle);
        testAssert.info("当前是“" + ProjectDetailsTitle.getText() + "”页面");

    }




    //零活宝方法
    public void investLinghuobao(Integer price) {


        driverHelper.sleep(2000);


        skipFreshGuide();

        skipProjectTitleBar();

        //先检查标题是否存在
        checkProjectDetailsTitle();

        //上滑
        topSwipe();

        InvestNowButton.click();

        testAssert.info("[screen] 进入立即投资页面");
        InvestmentAmountInputEx.clear();
        InvestmentAmountInputEx.sendKeys(price.toString());

        testAssert.info("[screen] 输入价格");
        InvestNowButtonEx.click();

    }

    //零活宝－点击，定期投资按钮
    public void investDingqiLinghuobao() {

        skipProjectTitleBar();


        //先检查标题是否存在
        checkProjectDetailsTitle();

        driverHelper.sleep(5000);

        skipFreshGuide();

        //上滑
        topSwipe();

        InvestDingqiButton.click();

    }

    //零活宝－点击，查看定期投资按钮
    public void modifyDingqiInvestPlan() {

        skipProjectTitleBar();


        //先检查标题是否存在
        checkProjectDetailsTitle();

        driverHelper.sleep(5000);

        skipFreshGuide();

        //上滑
        topSwipe();

        ModifyDingqiInvestButton.click();
    }

    //活期--智能宝--项目详情方法
    public void investZhinengbao(Integer price) {

        //先检查标题是否存在
        checkProjectDetailsTitle();

        driverHelper.sleep(5000);
        testAssert.info("[screen] 进入项目详情页");
        InvestmentAmountInput.click();
        InvestmentAmountInputEx.clear();
        InvestmentAmountInputEx.sendKeys(price.toString());
        testAssert.info("[screen] 输入价格");
        InvestNowButtonET.click();

    }

    //活期--富盈宝宝--项目详情方法
    public void investFuyingbaobao(Integer price){

        //先检查标题是否存在
        checkProjectDetailsTitle();

        driverHelper.sleep(5000);

        InvestmentAmountInput.click();
        InvestmentAmountInputEx.clear();
        InvestmentAmountInputEx.sendKeys(price.toString());
        testAssert.info("[screen] 输入价格");
        InvestNowButton.click();

        if (driverHelper.checkExist(ConfirmButton)){
            ConfirmButton.click();
        }

    }

    //活期--货币基金--项目详情方法
    public void investMonetaryFund(Integer price){

        //先检查标题是否存在
        checkProjectDetailsTitle();

        driverHelper.sleep(5000);

        InvestmentAmountInput.click();
        InvestmentAmountInputEx.clear();
        InvestmentAmountInputEx.sendKeys(price.toString());
        InvestNowButton.click();
        if (driverHelper.checkExist(ConfirmButton)) {
            ConfirmButton.click();
        }

    }

    private void investProduct(Integer price) {

        //先检查标题是否存在
        checkProjectDetailsTitle();

        driverHelper.sleep(5000);

        //上滑
        topSwipe();

        testAssert.info("[screen] 输入价格");
        InvestmentAmountInputET.clear();
        InvestmentAmountInputET.sendKeys(price.toString());

        testAssert.info("[screen] 点击立即投资按钮");
        InvestNowButtonET.click();

    }

    //p2p-稳盈安e 901－一口价 产品
    public void wenYingAnyiYiKouJia() {

        //先检查标题是否存在
        checkProjectDetailsTitle();

        driverHelper.sleep(5000);

        InvestButton.click();

    }

    //p2p-稳盈安e－保障类
    public void wenYingAnyiGuarantee(String price) {

        //先检查标题是否存在
        checkProjectDetailsTitle();

        driverHelper.sleep(5000);

        //上滑
        topSwipe();

        InvestAmountInputSpecial.clear();
        InvestAmountInputSpecial.sendKeys(price);
        InvestNowButton.click();

    }

    //p2p-点金计划（901）
    public void DianjinJihua901(){
        driverHelper.sleep(5000);

        //上滑
        topSwipe();

        InvestNowButton.click();

    }

    //p2p-点金计划（902）
    public void DianjinJihua902(){
        driverHelper.sleep(5000);

        //上滑
        topSwipe();

        InvestNowButton.click();

    }

    //定期产品部分通用流程
    public void dingqiGeneralProcess(Integer price) {
        //先检查标题是否存在
        checkProjectDetailsTitle();

        driverHelper.sleep(5000);

        //上滑
        topSwipe();

        DingqiInvestAmount.clear();
        DingqiInvestAmount.sendKeys(price.toString());
        InvestNowButton.click();
    }

    //定期－－财富汇
    public void dingqiCaifuhui(Integer price){

        dingqiGeneralProcess(price);
    }

    //定期－－安鑫
    public void dingqiAnXin(){

        InvestButton.click();
        //dingqiGeneralProcess(price);
    }

    //定期－－彩虹
    public void dingqiCaiHong(Integer price){

        driverHelper.sleep(5000);
        //先检查标题是否存在
        checkProjectDetailsTitle();
        driverHelper.trySearchElementByScroll(InvestAmountInputSpecial,true,3);


        InvestAmountInputSpecial.clear();
        InvestAmountInputSpecial.sendKeys(price.toString());
        InvestNowButton.click();

    }

    //定期－－票据
    public void dingqiAnyingPiaoJu(Integer price) {

        driverHelper.sleep(5000);
        //先检查标题是否存在
        checkProjectDetailsTitle();

        //上滑
        topSwipe();

        driverHelper.trySearchElementByScroll(DingqiInvestAmount, true, 3);
        DingqiPiaoJuInvestAmount.clear();
        DingqiPiaoJuInvestAmount.sendKeys(price.toString());
        InvestNowButton.click();

    }

    //定期－－粤股交
    public void dingqiYueGuJiao(Integer price) {

        driverHelper.sleep(5000);
        //先检查标题是否存在
        checkProjectDetailsTitle();

        //上滑
        topSwipe();

        InvestmentAmountInput.click();
        if(driverHelper.checkExist(InvestmentAmountInputEx)){
            InvestmentAmountInputEx.clear();
            InvestmentAmountInputEx.sendKeys(price.toString());
        }
        if(driverHelper.checkExist(InvestNowButtonEx)){
            InvestNowButtonEx.click();
        }else {
            InvestNowButton.click();
        }

    }

    //定期－－信托理财投资
    public void dingqiTrustInvestment(Integer price) {

        driverHelper.sleep(5000);
        //先检查标题是否存在
        checkProjectDetailsTitle();

        //上滑
        topSwipe();

        InvestmentAmountInput.click();
        InvestmentAmountInputEx.clear();
        InvestmentAmountInputEx.sendKeys(price.toString());
        InvestNowButtonEx.click();
        if (driverHelper.checkExist(InvestConfirmButton)){
            InvestConfirmButton.click();
        }
    }

    //定期－－理享＋（保险类产品）--国华人寿
    public void dingqiGuoHualife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--渤海人寿
    public void dingqiBoHailife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--平安人寿
    public void dingqiPingAnlife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--新珠江人寿
    public void dingqiZhuJianglife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--信泰人寿
    public void dingqiXinTailife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--中融人寿
    public void dingqiZhongRonglife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--恒大人寿
    public void dingqiHengDalife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--天安人寿
    public void dingqiTianAnlife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--百年人寿
    public void dingqiBaiNianlife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--生命人寿
    public void dingqiShengMinglife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--阳光人寿
    public void dingqiYangGuanglife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--君康人寿
    public void dingqiJunKanglife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--前海人寿
    public void dingqiQianHailife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--华夏人寿
    public void dingqiHuaXialife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--合众人寿
    public void dingqiHeZhonglife(Integer price){
        insuranceProduct(price);
    }

    //定期－－理享＋（保险类产品）--富盈人寿
    public void dingqiFuYinglife(Integer price){
        InsuranceInvestmentAmount.clear();
        InsuranceInvestmentAmount.sendKeys(price.toString());
        InvestNowButtonET.click();
    }


    //保险类产品公共流程方法
    public void insuranceProduct(Integer price){

        testLogger.info("切换到产品项目页面");

        driverHelper.sleep(5000);
        //先检查标题是否存在
        checkProjectDetailsTitle();

        //上滑
        topSwipe();

        InvestmentAmountInput.click();
        InvestmentAmountInputEx.clear();
        InvestmentAmountInputEx.sendKeys(price.toString());
        testAssert.info("[screen] 输入价格：" + price.toString() + "，并点击投资按钮");
        InvestNowButtonEx.click();

        // wait for 10 seconds
        driverHelper.sleep(10000);
    }

    //高端理财－信托－信托直营
    public void TrustDirect(Integer price){
        driverHelper.sleep(5000);
        //先检查标题是否存在
        checkProjectDetailsTitle();

        driverHelper.trySearchElementByScroll(InvestmentAmountInput,true,3);
        InvestmentAmountInput.click();
        InvestmentAmountInputEx.clear();
        InvestmentAmountInputEx.sendKeys(price.toString());
        InvestNowButton.click();
        if (checkExist(InvestConfirmButton)){
            InvestConfirmButton.click();
        }



    }


    //高端理财－私募－固定收益类
    public void FixedIncome(Integer price){
        driverHelper.sleep(5000);
        //先检查标题是否存在
        checkProjectDetailsTitle();

        driverHelper.trySearchElementByScroll(InvestmentAmountInput,true,3);
        InvestmentAmountInput.click();
        InvestmentAmountInputEx.clear();
        InvestmentAmountInputEx.sendKeys(price.toString());
        InvestNowButton.click();
        if (checkExist(InvestConfirmButton)){
            InvestConfirmButton.click();
        }

    }

    //高端理财－私募－浮动收益类
    public void FloatingProfit(Integer price){

        driverHelper.sleep(5000);
        //先检查标题是否存在
        checkProjectDetailsTitle();
        driverHelper.trySearchElementByScroll(InvestmentAmountInput,true,3);
        InvestmentAmountInput.click();
        InvestmentAmountInputEx.clear();
        InvestmentAmountInputEx.sendKeys(price.toString());
        InvestNowButton.click();
        if (checkExist(InvestConfirmButton)){
            InvestConfirmButton.click();
        }

    }

    //会员交易区－－定期转让-－财富汇
    public void clickCaiFuHuiProduct(){
        InvestButton.click();
    }

    //会员交易区－－定期转让-－安鑫
    public void clickAnxinProduct(){
        InvestButton.click();
    }

    //会员交易区－－定期转让-－彩虹
    public void clickCaiHongProduct(){
        InvestButton.click();
    }

    //会员交易区－－P2P转让-－一口价，稳盈安e
    public void clickP2PWenYingAnYi(){

        InvestButton.click();
        //InvestConfirmButton.click();

    }

    //新手专区－－平安人寿
    public void NewbieAreaPingAnlife(Integer price){
        insuranceProduct(price);
    }

    //VIP专属投资项目－－国华人寿
    public void VIPGuoHualife(Integer price){
        insuranceProduct(price);
    }

    //保险－－百万任我行
    public void clickBaiwanRenwoxing(){

        driverHelper.sleep(3000);

        //上滑
        topSwipe();

        InsuranceNowButton.click();

    }
}
