package com.lu.mobileaui.common.invest.RWXInsurance;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/19.
 *
 * 投保金额计算
 *
 */
public class InsuranceAmountCalculatePage extends BasePageAbstract {

    //被保人出生日期
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.view.View[3]")
    public WebElement SelectionBirthdate;

    //保障期限(年)
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(name = "20")
    public WebElement InsuranceDeadline;

    //确定
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(name = "确定")
    public WebElement Confirmbtn;

    //取消
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(name = "确定")
    public WebElement Cancelbtn;

    //立即投保
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(name = "立即投保")
    public WebElement InsuranceNowButton;

    public void clickInsuranceAmountCalculate(){

        SelectionBirthdate.click();
        Confirmbtn.click();
        InsuranceNowButton.click();

    }


}
