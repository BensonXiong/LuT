package com.lu.mobileaui.common.invest.RWXInsurance;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/20.
 *
 * 投保信息填写
 *
 */
public class InsuranceInfoWritePage extends BasePageAbstract {

    //投保人
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.view.View[4]")
    public WebElement InsurancePerson;

    //证件有效期
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.view.View[15]")
    public WebElement DocumentsExpiryDate;

    //确定-证件有效期
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.widget.Button[2]")
    public WebElement ConfirmDatebtn;

    //确定
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.view.View[16]")
    public WebElement Confirmbtn;

    //投保人联系地址
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.view.View[6]")
    public WebElement InsurancePersonContactAddress;

    //详细地址
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.widget.EditText[1]")
    public WebElement DetailsAddress;

    //邮政编码
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.widget.EditText[2]")
    public WebElement ZipCode;

    //下一步
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(name = "下一步")
    public WebElement NextButton;

    public void clickInsuranceInformationWrite(String detailsAddress,String zipCode){

        InsurancePerson.click();
        DocumentsExpiryDate.click();
        ConfirmDatebtn.click();
        Confirmbtn.click();
        InsurancePersonContactAddress.click();
        DetailsAddress.clear();
        DetailsAddress.sendKeys(detailsAddress);
        ZipCode.clear();
        ZipCode.sendKeys(zipCode);
        Confirmbtn.click();
        driverHelper.sleep(3000);
        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        driver.swipe(width / 2, height - 400, width / 2, 1000, 2000);
        NextButton.click();

    }

}
