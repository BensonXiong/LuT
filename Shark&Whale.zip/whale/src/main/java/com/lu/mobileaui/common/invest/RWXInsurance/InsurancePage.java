package com.lu.mobileaui.common.invest.RWXInsurance;

import com.lu.mobileafw.BasePageAbstract;
import com.lu.mobileafw.exception.NoSuchWebElementException;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/11.
 * 投资理财首页最上面一排的导航栏，第三个产品类型
 *
 * 投资理财－保险
 *
 */
public class InsurancePage extends BasePageAbstract {

    //平安百万任我行两全保险－－百万回归0328
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "百万回归0328")
    public WebElement InsuranceFirstProduct;

    public void clickInsuranceButton() throws NoSuchWebElementException {

        boolean bFound = driverHelper.trySearchElementByScroll(InsuranceFirstProduct, true, 10);
        if (!bFound) {
            throw new NoSuchWebElementException("The selectVIPExclusiveInvestProduct is not found. Please check the product is on the page.");
        }
        InsuranceFirstProduct.click();

    }
}
