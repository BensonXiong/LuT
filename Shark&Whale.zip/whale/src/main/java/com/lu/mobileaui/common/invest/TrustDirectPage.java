package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/13.
 *
 * 投资理财 -- 高端理财 -- 信托直营
 *
 */
public class TrustDirectPage extends BasePageAbstract {

    //信托 －－ yanxutao信托直营_2016051210114348267533
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.RelativeLayout[1]")
    public WebElement TrustFirstProduct;

    public void clickTrustFirstProduct(){
        TrustFirstProduct.click();
    }

}
