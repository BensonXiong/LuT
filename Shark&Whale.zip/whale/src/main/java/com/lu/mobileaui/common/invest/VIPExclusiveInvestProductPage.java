package com.lu.mobileaui.common.invest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/16.
 *
 * 投资理财－－VIP专属投资项目
 *
 */
public class VIPExclusiveInvestProductPage extends BasePageAbstract {

    //VIP专属投资项目－－国华人寿6个月p01
    @iOSFindBy(name = "国华人寿6个月p01")
    @AndroidFindBy(name = "国华人寿6个月p01")
    public WebElement VIPGuoHualifeBtn;

    public void clickVIPExclusiveInvestProductBtn(){
        VIPGuoHualifeBtn.click();
    }
}
