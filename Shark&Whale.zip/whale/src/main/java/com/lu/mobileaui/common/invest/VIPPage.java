package com.lu.mobileaui.common.invest;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/4/27.
 *
 * 投资理财页 -> 会员交易区页 -> 会员交易区列表展示
 */
public class VIPPage extends ProductListPage {

    /**
     * 产品
     * 会员交易区
     */

    //定期（转让）--财富汇
    @iOSFindBy(xpath = "//UIAStaticText[contains(@text, '转让财富汇')]")
//    @AndroidFindBy(name = "转让财富汇20160112175027852 16011900080")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '转让财富汇')]")
    public WebElement DingqiCaiFuHuiProduct;

    //定期（转让）--安鑫
    @iOSFindBy(xpath = "//UIAStaticText[contains(@text, '安鑫') or contains(@text, 'AnXin')]")
//    @AndroidFindBy(name = "安鑫20160318152439701")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '安鑫') or contains(@text, 'AnXin')]")
    public WebElement DingqiAnxinProduct;

    //定期（转让）--彩虹
    @iOSFindBy(xpath = "//UIAStaticText[contains(@text, '彩虹')] or contains(@text,'CH')")
//    @AndroidFindBy(name = "彩虹20160321104051367")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '彩虹') or contains(@text,'CH')]")
    public WebElement DingqiCaiHongProduct;

    //p2p转让--一口价，稳盈-安e
    @iOSFindBy(xpath = "//UIAStaticText[contains(@text, '稳盈-安e')]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.RelativeLayout[1]")
    //@AndroidFindBy(name = "稳盈-安e 16020200174")
    //@AndroidFindBy(name = "稳盈-安e 15120800179")
    public WebElement P2PWenYingAnYi;

    //P2P转让
    @iOSFindBy(name = "P2P转让")
    @AndroidFindBy(name = "P2P转让")
    //@AndroidFindBy(xpath = "//android.widget.HorizontalScrollView[1]/android.widget.LinearLayout[1]/android.widget.TextView[2]")
    public WebElement P2PAssignmentButton;



    /**
     * 标题
     * ＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
     */

    /**
     * 会员交易区－定期（转让）
     */
    //定期（转让）
    @iOSFindBy(name = "定期转让")
    @AndroidFindBy(xpath = "//android.widget.HorizontalScrollView[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement topFixeAssignmentTextView;

    /**
     * 会员交易区－P2P（转让）
     */
    //P2P（转让）
    @iOSFindBy(name = "P2P转让")
    @AndroidFindBy(xpath = "//android.widget.HorizontalScrollView[1]/android.widget.LinearLayout[1]/android.widget.TextView[2]")
    public WebElement topP2PAssignmentTextView;

    /**
     * 会员交易区－稳盈-e享计划
     */
    //稳盈-e享计划
    @iOSFindBy(name = "e享计划")
    @AndroidFindBy(xpath = "//android.widget.HorizontalScrollView[1]/android.widget.LinearLayout[1]/android.widget.TextView[3]")
    public WebElement topWenyinPlanTextView;


    //稳盈-e享计划  弹出框
    //新增“e享计划”  一个月年化收益率5%－6%
    @iOSFindBy(name = "newuserguide")//UIAApplication[1]/UIAWindow[1]/UIAImage[1]
    @AndroidFindBy(className = "android.widget.RelativeLayout")//android.widget.RelativeLayout
    public WebElement TipsEXiang;


//    /**
//     * 特殊控件
//     */
//
//    /**
//     * 点击任意
//     */
//    @iOSFindBy(name = "NA")
//    @AndroidFindBy(className = "android.widget.RelativeLayout")//android.widget.RelativeLayout
//    public WebElement msgButton;



    //＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
    /**
     * 顶部排序分类
     */

    /**
     * 会员交易区－综合排序
     *
     * iOS 环境中  UIAButton存在 visible="false" 且关键字元素也为false状态 所以去除这些元素后 index为3
     */
    //综合排序
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAButton[3]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement topSyntheticallyTextView;

    /**
     * 会员交易区－转让价格
     */
    //转让价格
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAButton[4]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[2]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement topAssignmentPriceTextView;

    /**
     * 会员交易区－剩余期限
     */
    //剩余期限
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAButton[5]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[3]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement topResidualMaturityTextView;

    /**
     * 会员交易区－筛选
     *
     */
    //筛选
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAButton[6]")
    @AndroidFindBy(name = "筛选")
    //@AndroidFindBy(xpath = "//android.widget.FrameLayout[4]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement topFilterTextView;


    //==================================================================================================================
    /**
     * 会员交易区－排序－展开第一个条件
     */
    //排序－展开第一个条件
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[1]/UIAStaticText[1]")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement sortOneTextView;

    /**
     * 会员交易区－排序－展开第二个条件
     */
    //排序－展开第二个条件
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]/UIAStaticText[1]")//收益率/利率最高
    @AndroidFindBy(xpath = "//android.view.View[2]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement sortTwoTextView;

    /**
     * 会员交易区－排序－展开第三个条件
     */
    //排序－展开第三个条件
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[3]/UIAStaticText[1]")//转让价格最低
    @AndroidFindBy(xpath = "//android.view.View[3]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement sortThreeTextView;

    /**
     * 会员交易区－排序－展开第四个条件
     */
    //排序－展开第四个条件
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[4]/UIAStaticText[1]")//转让价格最高
    @AndroidFindBy(xpath = "//android.view.View[4]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement sortFourTextView;

    /**
     * 会员交易区－排序－展开第五个条件
     */
    //排序－展开第五个条件
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[5]/UIAStaticText[1]")//剩余期限最短
    @AndroidFindBy(xpath = "//android.view.View[5]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement sortFiveTextView;

    /**
     * 会员交易区－排序－展开第六个条件
     */
    //排序－展开第六个条件
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[6]/UIAStaticText[1]")//剩余期限最长
    @AndroidFindBy(xpath = "//android.view.View[6]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement sortSixTextView;

    //==================================================================================
    /**
     * 输入
     */

    /**
     * 会员交易区－起投金额－开始金额
     */
    //开始金额
    @iOSFindBy(xpath = "//UIATextField[1]")
    @AndroidFindBy(id = "start_region_edit")//android.widget.EditText
    public WebElement amountStartEditText;

    /**
     * 会员交易区－起投金额－结束金额
     */
    //结束金额
    @iOSFindBy(xpath = "//UIATextField[2]")
    @AndroidFindBy(id = "last_region_edit")//android.widget.EditText
    public WebElement amountLastEditText;

    /**
     * 会员交易区－起投金额－确定按钮
     */
    //确定按钮
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[*]/UIAButton[1]")
    @AndroidFindBy(id = "confirm_btn")//android.widget.Button
    public WebElement amountConfirmButton;

    //==================================================================================
    /**
     * 投资方式
     */
    //一口价
    //投资方式－一口价
    @iOSFindBy(name = "一口价")
    @AndroidFindBy(name = "一口价")
    public WebElement YikoujiaButton;

    //==================================================================================
    /**
     * 项目
     */
    /**
     * 会员交易区－筛选-项目类型－不限
     */
    //项目类型－不限
    @iOSFindBy(name = "不限")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.GridView[1]/android.view.View[1]")//android.widget.TextView
    public WebElement filterUnlimitedTextView;


    /**
     * 会员交易区－筛选-项目类型－财富汇
     */
    //项目类型－财富汇
    @iOSFindBy(name = "财富汇")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '财富汇')]")//android.widget.TextView
    @AndroidFindBy(name = "财富汇")
    public WebElement filterCaifuhuiTextView;

    /**
     *会员交易区－筛选- 项目类型－安鑫
     */
    //项目类型－安鑫
    @iOSFindBy(name = "安鑫")
    @AndroidFindBy(name = "安鑫")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '安鑫')]")//android.widget.TextView
    public WebElement filterAnxinTextView;

    //项目类型－稳盈安e
    @iOSFindBy(name = "稳盈-安e")
    @AndroidFindBy(name = "稳盈-安e")
    public WebElement WenYingAnYiButton;



    /**
     * 会员交易区－筛选-项目类型－彩虹
     */
    //项目类型－彩虹
    @iOSFindBy(name = "彩虹")
    @AndroidFindBy(name = "彩虹")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '彩虹')]")//android.widget.TextView
    public WebElement filterCaiHongTextView;

    /**
     * 会员交易区－筛选－可变现
     */
    //项目类型－可变现
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]/UIAButton[1]")
    @AndroidFindBy(name = "可变现")
//    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '可变现')]")//android.widget.TextView
    public WebElement filterKebianxianTextView;

    /**
     * 会员交易区－筛选－重置
     */
    //项目类型－重置
    @iOSFindBy(name = "重置")
    @AndroidFindBy(id = "bt_filter_reset")//android.widget.Button
    public WebElement filterRestButton;

    /**
     * 会员交易区－筛选－确定
     */
    //项目类型－确定
    @iOSFindBy(name = "确定")
    @AndroidFindBy(id = "bt_filter_confirm")//android.widget.Button
    public WebElement filterConfirmButton;



    /**
     * 产品
     * 定期转让--财富汇
     */
    public void clickDingqiAssignmentCaiFuHuiProduct(){

//        driverHelper.sleep(5000);
//
//        driver.executeScript("mobile: tap", new HashMap<String, Integer>() {{
//            put("tapCount", 1);
//            put("touchCount", 1);
//            put("duration", 1);
//            put("x", 700);
//            put("y", 400);
//        }});
//
//        driverHelper.sleep(2000);

        if(driverHelper.checkExist(TipsEXiang)){
            TipsEXiang.click();
        }
        topFilterTextView.click();
        filterCaifuhuiTextView.click();
        filterConfirmButton.click();
        DingqiCaiFuHuiProduct.click();

    }


    /**
     * 产品
     * 定期转让--安鑫
     */
    public void clickDingqiAssignmentAnxinProduct(){

//        driverHelper.sleep(5000);
//
//        driver.executeScript("mobile: tap", new HashMap<String, Integer>() {{
//            put("tapCount", 1);
//            put("touchCount", 1);
//            put("duration", 1);
//            put("x", 700);
//            put("y", 400);
//        }});
//
//        driverHelper.sleep(2000);
        if(driverHelper.checkExist(TipsEXiang)){
            TipsEXiang.click();
        }

        topFilterTextView.click();
        filterAnxinTextView.click();
        filterConfirmButton.click();
        DingqiAnxinProduct.click();

    }

    /**
     * 产品
     * 定期转让--彩虹
     */
    public void clickDingqiAssignmentCaiHongProduct(){

//        driverHelper.sleep(5000);
//
//        driver.executeScript("mobile: tap", new HashMap<String, Integer>() {{
//            put("tapCount", 1);
//            put("touchCount", 1);
//            put("duration", 1);
//            put("x", 700);
//            put("y", 400);
//        }});
//
//        driverHelper.sleep(2000);
        if(driverHelper.checkExist(TipsEXiang)){
            TipsEXiang.click();
        }

        topFilterTextView.click();
        filterCaiHongTextView.click();
        filterConfirmButton.click();
        DingqiCaiHongProduct.click();

    }

    /**
     * 产品
     * p2p转让一口价，稳盈安e
     */
    public void clickP2PAssignmentWenYingAnYi(){

//        driverHelper.sleep(5000);
//
//        driver.executeScript("mobile: tap", new HashMap<String, Integer>() {{
//            put("tapCount", 1);
//            put("touchCount", 1);
//            put("duration", 1);
//            put("x", 700);
//            put("y", 400);
//        }});
//
//        driverHelper.sleep(2000);
        if(driverHelper.checkExist(TipsEXiang)){
            TipsEXiang.click();
        }

        P2PAssignmentButton.click();
        topFilterTextView.click();
        YikoujiaButton.click();
        WenYingAnYiButton.click();
        filterConfirmButton.click();
        P2PWenYingAnYi.click();


    }

    //点击所有查询条件，对结果暂未验证
    public void clickSynthetically(){
        topSyntheticallyTextView.click();
        sortTwoTextView.click();

        topSyntheticallyTextView.click();
        sortThreeTextView.click();

        topSyntheticallyTextView.click();
        sortFourTextView.click();

        topSyntheticallyTextView.click();
        sortFiveTextView.click();

        topSyntheticallyTextView.click();
        sortSixTextView.click();

        topSyntheticallyTextView.click();
        sortOneTextView.click();
    }
    //点击所有查询条件，对结果暂未验证
    public void clickAssignmentPrice(){
        topAssignmentPriceTextView.click();
        sortTwoTextView.click();

        topAssignmentPriceTextView.click();
        sortThreeTextView.click();

        topAssignmentPriceTextView.click();
        sortFourTextView.click();

        topAssignmentPriceTextView.click();
        sortFiveTextView.click();


        topAssignmentPriceTextView.click();
        amountStartEditText.sendKeys("10");
        amountLastEditText.sendKeys("100");
        amountConfirmButton.click();

        topAssignmentPriceTextView.click();
        sortOneTextView.click();

    }
    //点击所有查询条件，对结果暂未验证
    public void clickResidualMaturity(){
        topResidualMaturityTextView.click();
        sortTwoTextView.click();

        topResidualMaturityTextView.click();
        sortThreeTextView.click();


        topResidualMaturityTextView.click();
        sortFourTextView.click();


        topResidualMaturityTextView.click();
        sortFiveTextView.click();


        topResidualMaturityTextView.click();
        sortSixTextView.click();

        topResidualMaturityTextView.click();
        amountStartEditText.sendKeys("10");
        amountLastEditText.sendKeys("400");
        amountConfirmButton.click();

        topResidualMaturityTextView.click();
        sortOneTextView.click();
    }

    //点击所有查询条件，对结果暂未验证
    public void clickFilter(){
        topFilterTextView.click();

        filterCaifuhuiTextView.click();
        filterAnxinTextView.click();
        filterCaiHongTextView.click();

        filterKebianxianTextView.click();

        filterConfirmButton.click();

        //清空查询条件
        topFilterTextView.click();

        filterUnlimitedTextView.click();
        setKebianxianFalse();
        filterConfirmButton.click();

    }


     //设置可变现按钮为，不勾选状态
    public void setKebianxianFalse(){
        if(filterKebianxianTextView.isEnabled()){
            filterKebianxianTextView.click();
        }
        
    }

}
