package com.lu.mobileaui.common.more;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/4/21.
 *
 * 更多 --> 关于
 *
 */
public class AboutPage extends BasePageAbstract {

    //标题－关于
    @iOSFindBy(name = "关于")
    @AndroidFindBy(name = "关于")
    public WebElement Title;

    //版本号
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAStaticText[1]")
    @AndroidFindBy(id = "com.lufax.android:id/tv_about_version")
    public WebElement LuAppVersion;

    //官网网站
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAStaticText[3]")
    @AndroidFindBy(id = "com.lufax.android:id/tv_about_website_value")
    public WebElement LuAppWebsite;

    //微信号
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAStaticText[5]")
    @AndroidFindBy(id = "com.lufax.android:id/tv_about_wechat_value")
    public WebElement LuWechat;

    //客服电话
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAStaticText[7]")
    @AndroidFindBy(id = "com.lufax.android:id/tv_about_tel")
    public WebElement LuCSTel;

    //人工服务时间
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAStaticText[8]")
    @AndroidFindBy(id = "com.lufax.android:id/tv_about_service")
    public WebElement LuCSServiceTime;

    //微信公众号
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAStaticText[11]")
    @AndroidFindBy(name = "lufax_cs")
    public WebElement LuCSWebchat;

}
