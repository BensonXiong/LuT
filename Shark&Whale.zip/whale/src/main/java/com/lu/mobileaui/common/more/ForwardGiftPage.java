package com.lu.mobileaui.common.more;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/4/21.
 *
 * 更多 --> 天天发礼包 一秒变土豪
 *
 */

public class ForwardGiftPage extends BasePageAbstract {

    // 标题
    @iOSFindBy(xpath = "//UIANavigationBar[1]/UIAStaticText[@name='发礼包']")
    @AndroidFindBy(id ="title_bar_title_tv")
    public WebElement Title;

    // 一段文字
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAStaticText[1]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.ScrollView[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement TypeText;

//    // 天天发礼包 一秒变土豪
//    @iOSFindBy(name = "NA")
//    @AndroidFindBy(id = "ll_forwardGift")
//    public WebElement ForwardGiftButton;
//
//    public void clickforwardgift(){
//        ForwardGiftButton.click();
//    }

}
