package com.lu.mobileaui.common.more;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/4/15.
 *
 * 更多 --> 邀请好友页面
 *
 */
public class InvitationPage extends BasePageAbstract {

    // 标题 - 邀请好友
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIANavigationBar[1]/UIAStaticText[1]")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement TitleText;

    // 我的邀请
    @iOSFindBy(name = "我的邀请")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement MyInvitationButton;

    //返回未第一个按钮，但点击无效，使用第二个按钮点击有效
    // 回退按钮
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIANavigationBar[1]/UIAButton[2]")//返回//UIAApplication[1]/UIAWindow[1]/UIANavigationBar[1]/UIAButton[1]
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement BackButton;

}
