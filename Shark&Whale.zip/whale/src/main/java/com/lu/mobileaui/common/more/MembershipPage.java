package com.lu.mobileaui.common.more;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/4/21.
 * 更多 --> 会员权益
 *
 */
public class MembershipPage extends BasePageAbstract {
    //会员权益
    @iOSFindBy(name = "会员权益")
    @AndroidFindBy(id = "ll_forwardMember")
    public WebElement BackwardMembershipButton;

    // 标题 - 邀请好友
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIANavigationBar[1]/UIAStaticText[1]")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement TitleText;

    public void clickBackwardButton(){
        BackwardMembershipButton.click();
    }
}
