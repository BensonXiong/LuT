package com.lu.mobileaui.common.more;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/4/15.
 *
 * “更多”页面
 *
 */
public class MorePage extends BasePageAbstract {

    // 标题 - 更多
    @iOSFindBy(name = "更多")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement Title;

    // 邀请好友赚奖励
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[1]")
    @AndroidFindBy(id = "ll_forwardRecommend")
    public WebElement ForwardRecommendButton;

    // 天天发礼包 一秒变土豪
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]")
    @AndroidFindBy(id = "ll_forwardGift")
    public WebElement ForwardGiftButton;

    // 边玩边赚钱 投资券无限
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[3]")
    @AndroidFindBy(id = "ll_forwardGame")
    public WebElement ForwardGameButton;

    // 会员权益
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[4]")
    @AndroidFindBy(id = "ll_forwardMember")
    public WebElement ForwardVIPMemberButton;

    // 手机令牌
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[6]")
    @AndroidFindBy(id = "ll_forwardToken")
    public WebElement ForwardTokenButton;

    // 检查更新
//    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "ll_forwardUpdate")
    public WebElement ForwardUpgradeButton;

    // 关于
    @iOSFindBy(name = "关于")
    @AndroidFindBy(id = "ll_forwardAbout")
    public WebElement ForwardAboutButton;

    // 在线客服
    @iOSFindBy(name = "在线客服")
    @AndroidFindBy(id = "ll_forwardCS")
    public WebElement ForwardOnlineCSButton;

}
