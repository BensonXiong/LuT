package com.lu.mobileaui.common.myaccount;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/5/3.
 *
 * 注册 －－>  投资前准备（实名认证）
 *
 */
public class InvestmentPreparationPage extends BasePageAbstract {

    //真实姓名
    @iOSFindBy(xpath = "//UIATextField[@value='真实姓名']")
    @AndroidFindBy(xpath = "//android.widget.EditText[2]")
//    @AndroidFindBy(name = "真实姓名")
    public WebElement RealnameInput;

    //身份证号码
    @iOSFindBy(xpath = "//UIATextField[@value='身份证号码']")
    @AndroidFindBy(xpath = "//android.widget.EditText[3]")
//    @AndroidFindBy(name = "身份证号码")
    public WebElement CardNoInput;

    //认证按钮
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAStaticText[6]")
    @AndroidFindBy(name = "认证")
    public WebElement CertificationBtn;


    //设置交易密码
    @iOSFindBy(xpath = "//UIAStaticText[@name='设置交易密码'][1]")//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAStaticText[4]
    @AndroidFindBy(name = "设置交易密码")
    public WebElement SetTradPwdView;

    //交易密码
    @iOSFindBy(xpath = "//UIASecureTextField[@value='交易密码']")
    @AndroidFindBy(xpath = "//android.widget.EditText[2]")
    public WebElement SetTradPwdInput;

    //再输入一遍
    @iOSFindBy(xpath = "//UIASecureTextField[@value='再输一遍']")
    @AndroidFindBy(xpath = "//android.widget.EditText[3]")
    public WebElement ConfirmTradPwdInput;

    //确定
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIAStaticText[6]")
    @AndroidFindBy(name = "确定")
    public WebElement ConfirmButton;

    //银行卡认证
    @iOSFindBy(xpath = "//UIAStaticText[@name='银行卡认证'][1]")
    @AndroidFindBy(name = "银行卡认证")
    public WebElement BankCardVieW;


    //银行卡号
    @iOSFindBy(xpath = "//UIASecureTextField[@value='银行卡号'] || //UIATextField[@value='银行卡号']")
//    @AndroidFindBy(xpath = "//android.widget.EditText[3]")
    @AndroidFindBy(xpath = "//android.widget.EditText[2]")
    public WebElement BankNoInput;

    //下一步(银行卡认证)
    @iOSFindBy(name = "下一步")
//    @AndroidFindBy(name = "银行卡认证")
    @AndroidFindBy(name = "下一步")
    public WebElement NextButton;

    //确认无误
    @iOSFindBy(name = "确认无误")
    @AndroidFindBy(name = "确认无误")
    public WebElement ConfirmCardButton;


    /**
     * 绑定成功页面
     */

    // 银行名称
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "l_bank_name")
    public WebElement BankNameText;

    // 银行名称
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "l_bank_no")
    public WebElement BankCardNumberText;

    // 启动银行App
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "btn_startapp")
    public WebElement StartBankAppButton;


    /**
     * 实名认证
     * @param realName
     * @param cardNo
     */
    public void investmentPreparation(String realName,String cardNo){

        RealnameInput.clear();
        RealnameInput.sendKeys(realName);

        CardNoInput.clear();
        CardNoInput.sendKeys(cardNo);
        logger.info(CertificationBtn.getText());
        CertificationBtn.click();

        // 页面变换等待5秒
        driverHelper.sleep(5000);

    }

    /**
     * 交易密码
     * @param tradPwd
     */
    public void setTradPwd(String tradPwd){

        SetTradPwdView.isEnabled();
        logger.debug(SetTradPwdView.isEnabled() + "");

        SetTradPwdInput.clear();
        SetTradPwdInput.sendKeys(tradPwd);
        ConfirmTradPwdInput.clear();
        ConfirmTradPwdInput.sendKeys(tradPwd);
        ConfirmButton.click();

        // 页面变换等待5秒
        driverHelper.sleep(5000);

    }

    /**
     * 绑定银行卡
     * @param bankNo
     */
    public void realBankNo(String bankNo){

        BankCardVieW.isEnabled();
        BankNoInput.clear();
        BankNoInput.sendKeys(bankNo);
        NextButton.click();

        ConfirmCardButton.isDisplayed();
        ConfirmCardButton.click();

        // 页面变换等待5秒
        driverHelper.sleep(5000);

    }

}
