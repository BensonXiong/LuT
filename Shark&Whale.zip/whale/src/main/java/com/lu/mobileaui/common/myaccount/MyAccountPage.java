package com.lu.mobileaui.common.myaccount;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/3/31.
 *
 * 我的账户首页
 *
 */


public class MyAccountPage extends BasePageAbstract {

    // 我的消息
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIANavigationBar[1]/UIAButton[2]")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement MyMessageButton;

    // 账户名字
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIANavigationBar[1]/UIAButton[3]")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement AccountNameText;

    // 个人设置按钮
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIANavigationBar[1]/UIAButton[3]")
    @AndroidFindBy(id = "com.lufax.android:id/title_bar_middle_container")
    public WebElement FaviconButton;

    //个人头像
    @iOSFindBy(name = "avatar_default")
    @AndroidFindBy(id = "pull_loading_head_avatar")
    public WebElement PersonalSettingsButton;


    // 安全退出
    @iOSFindBy(name = "安全退出")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement LogOutButton;

    // 显示或者隐藏资产
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIAStaticText[2]")
    @AndroidFindBy(id = "account_general_assests")
    public WebElement ShowHideAssetsButton;

    // 当前资产总价值
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIAStaticText[3]")
    @AndroidFindBy(id = "account_general_assests_value")
    public WebElement TotalAssetsText;

    // 现金管理总价值
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIAButton[1]")
    @AndroidFindBy(id = "account_detail_assest_1")
    public WebElement TotoalCashText;

    // 可用余额
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIAButton[2]")
    @AndroidFindBy(id = "account_detail_assest_2")
    public WebElement AvailableCashText;

    // 可用投资券
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIAButton[3]")
    @AndroidFindBy(id = "account_detail_assest_3")
    public WebElement AvailableCouponText;

    /**
     * 我的资产
     */
    //总资产
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIAStaticText[3]")
    @AndroidFindBy(name = "总资产")
    public WebElement TotoalAssetsText;

    //可用余额 or //冻结金额
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIAStaticText[3]")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.widget.ListView[1]")
    public WebElement AvailableBalanceText;

    //委托中项目
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIAStaticText[3]")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.widget.ListView[2]")
    public WebElement DelegateProjectText;

    /**
     * 可用投资券
     */

    //已使用
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIAStaticText[3]")
    @AndroidFindBy(name = "已使用")
    public WebElement UseButton;

    //已失效
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIAStaticText[3]")
    @AndroidFindBy(name = "已失效")
    public WebElement ExpiredButton;

    //返回
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIAStaticText[3]")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement Backbtn;


    /**
     * 我的投资项目
     */

    // 持有中
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]/UIAButton[1]")
    @AndroidFindBy(id = "account_total_ongoing_count")
    public WebElement OngoingButton;

    // 申请中
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]/UIAButton[2]")
    @AndroidFindBy(id = "account_num_of_applying_request")
    public WebElement ApplyingButton;

    // 可转让
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]/UIAButton[3]")
    @AndroidFindBy(id = "account_total_transferable_count")
    public WebElement TransferableButton;

    // 可变现
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[2]/UIAButton[4]")
    @AndroidFindBy(id = "account_total_cash_loan_count")
    public WebElement CashButton;


    /**
     * 投资统计
     */
    //投资统计
//    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "投资统计")
    public WebElement InvestCountButton;

    //投资总额
//    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "投资总额")
    public WebElement InvestAmountButton;

    //已收款总额
//    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "已收款总额")
    public WebElement MoneyReceiptButton;

    //待收款总额
//    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "待收款总额")
    public WebElement AgencyReceiptButton;

    // 取现
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[1]/UIAButton[1]")
    @AndroidFindBy(id = "account_assest_withdraw")
    public WebElement WithdrawButton;

    // 充值
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATableView[1]/UIATableCell[1]/UIAButton[2]")
    @AndroidFindBy(id = "account_assest_charge")
    public WebElement ChargeButton;

    /**
     * 退出登录对话框
     */
    // 确定按钮
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[4]/UIAAlert[1]/UIACollectionView[1]/UIACollectionCell[2]/UIAButton[1]")//name=确定
    @AndroidFindBy(id = "btn_right")
    // //android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.TextView[2]
    public WebElement ConfirmLogoutButton;

    // 取消按钮
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[4]/UIAAlert[1]/UIACollectionView[1]/UIACollectionCell[2]/UIAButton[1]")//name=取消
    @AndroidFindBy(id = "btn_left")
    public WebElement CancelLogoutButton;

    /**
     * 新手引导页
     */
    // 点击这里进行个人信息、密码管理
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "account_freshguide_pre_btn")
    public WebElement GuideFirstButton;

    // 陆金券更名“投资券”
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "account_freshguide_next_btn")
    public WebElement GuideSecondButton;
    //public  cashAdvancePages;

    // 余额自动化转入陆金宝
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "guide_image")
    public WebElement GuideLuJinBao;

    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "layout1")
    public WebElement GuideLuJinBaoCancelButton;

    public void SkipGuide() {

        driverHelper.clickWhenExist(GuideFirstButton);
        driverHelper.clickWhenExist(GuideSecondButton);

        if (driverHelper.checkExist(GuideLuJinBao)) {
            GuideLuJinBaoCancelButton.click();
        }

    }

    public void LogOut() {

        SkipGuide();
        LogOutButton.click();
        ConfirmLogoutButton.click();

    }

    public void showHideAssets(){

        ShowHideAssetsButton.click();

    }

    public void clickWithdrawButton() {
        this.WithdrawButton.click();

        // 切换页面等待5秒
        driverHelper.sleep(5000);
    }

}
