package com.lu.mobileaui.common.myaccount;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/4/29.
 *
 * 最后完成页
 *
 */
public class MyAccountViewPage extends BasePageAbstract {

    // 完成
    @iOSFindBy(name = "完成")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement CompleteButton;

    //继续充值
    @iOSFindBy(name = "继续充值")
    @AndroidFindBy(id = "btn_charge_layout")
    public WebElement ProceedChargeButton;

    // 点击完成按钮
    public void clickCompleteButton() {
        CompleteButton.click();
    }

    //点击继续充值
    public void clickProceedChargeButton(){
        ProceedChargeButton.click();
    }
}
