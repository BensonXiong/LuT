package com.lu.mobileaui.common.myaccount;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/4/14.
 *
 * 我的投资券
 *
 */
public class MyCouponPage extends BasePageAbstract {


    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement TitleBarText;



}
