package com.lu.mobileaui.common.myaccount;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by huangyinhuang on 16/4/14.
 */
public class PersonalSettingsPage extends BasePageAbstract {

    /**
     * 个人信息
     */


    /**
     * 会员权益
     */

    /**
     * 密码管理
     */


    // step 1
    // 密码管理按钮
    @iOSFindBy(xpath = "//UIAWebView[1]/UIAStaticText[contains(@name,'密码管理')]")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'密码管理')]")//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.RelativeLayout[2]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.ScrollView[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.webkit.WebView[1]/android.webkit.WebView[1]/android.view.View[6]
    public WebElement PwdManagementButton;

    // step 2
    // 交易密码修改按钮
    @iOSFindBy(xpath = "//UIAScrollView[1]/UIAWebView[1]/UIAStaticText[@name='交易密码']")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.webkit.WebView[1]/android.webkit.WebView[1]/android.view.View[3]")
    public WebElement TradePwdModifyButton;

    // 交易密码重置按钮
    @iOSFindBy(xpath = "//UIAScrollView[1]/UIAWebView[1]/UIAStaticText[@name='重置交易密码']")
    @AndroidFindBy(xpath = "NA")
    public WebElement TradePwdResetButton;


    // step 3

    // 原先交易密码
    @iOSFindBy(xpath = "//UIASecureTextField[@value='当前交易密码']")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.EditText[1]")
    public WebElement TradePwdOriginalInput;

    // 新交易密码
    @iOSFindBy(xpath = "//UIASecureTextField[@value='请输入交易密码']")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[2]/android.widget.LinearLayout[1]/android.widget.EditText[1]")
    public WebElement TradePwdNewInput;

    // 新交易密码－再一次输入
    @iOSFindBy(xpath = "//UIASecureTextField[@value='请再输一遍交易密码']")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[3]/android.widget.LinearLayout[1]/android.widget.EditText[1]")
    public WebElement TradePwdNewExInput;

    // 确定按钮
    @iOSFindBy(name = "确定")
    @AndroidFindBy(id = "btn_pwd_retrieve_confirm")
    ////android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.Button[1]
    public WebElement ConfirmNewTradePwdButton;


    // step 3
    // 交易密码修改
    @iOSFindBy(name = "交易密码修改成功")//UIAApplication[1]/UIAWindow[1]/UIAStaticText[1]
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text, '交易密码修改成功')]")
    public WebElement TradePwdModifiedBySuccessMsg;

    /**
     * 手势密码
     */
    @iOSFindBy(xpath = "//UIASwitch[1]")//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAWebView[1]/UIASwitch[1]
    @AndroidFindBy(xpath = "//android.widget.CheckBox[1]")
    public WebElement GestureSwitchCheckBox;

    // 弹出框－输入用户密码
    @iOSFindBy(xpath = "//UIASecureTextField[1]")//UIAApplication[1]/UIAWindow[1]/UIAAlert[1]/UIAScrollView[1]/UIACollectionView[1]/UIACollectionCell[1]/UIASecureTextField[1]
    @AndroidFindBy(id = "com.lufax.android:id/tv_popup_edit")
    public WebElement PopUpUserPwdInput;

    // 弹出框－取消
    @iOSFindBy(name = "取消")
    @AndroidFindBy(id = "com.lufax.android:id/btn_left")
    public WebElement PopUpUserPwdCancelButton;

    // 弹出框－确定
    @iOSFindBy(name = "确认")
    @AndroidFindBy(id = "com.lufax.android:id/btn_right")
    public WebElement PopUpUserPwdConfirmButton;

    public void modifyTradePwd(String originalPwd, String newPwd) {
        testAssert.info("[screen] click the button to modify trade password");
        PwdManagementButton.click();
        TradePwdModifyButton.click();

        testAssert.info("[screen] input the original trade password: " + originalPwd);
        TradePwdOriginalInput.clear();
        TradePwdOriginalInput.sendKeys(originalPwd);

        testAssert.info("[screen] input new trade password: " + newPwd);
        TradePwdNewInput.clear();
        TradePwdNewInput.sendKeys(newPwd);

        TradePwdNewExInput.clear();
        TradePwdNewExInput.sendKeys(newPwd);

        testAssert.info("[screen] click the ok button to confirm new trade password");
        ConfirmNewTradePwdButton.click();
    }


}
