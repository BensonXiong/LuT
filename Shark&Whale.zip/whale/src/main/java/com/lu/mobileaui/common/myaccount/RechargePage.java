package com.lu.mobileaui.common.myaccount;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/4/21.
 *
 * 我的账户 --> 充值
 *
 */
public class RechargePage extends BasePageAbstract {

    //充值按钮
    @iOSFindBy(name = "充值")
    @AndroidFindBy(name = "充值")
    public WebElement ChargeButton;

    //充值金额input框
    @iOSFindBy(xpath = "//UIATextField[@value='最低为1']")
    @AndroidFindBy(id = "charge_value")
    public WebElement ChargeAmountInput;

    //获取动态码按钮
    @iOSFindBy(name = "获取动态码")
    //@AndroidFindBy(id = "countdown_btn")
    @AndroidFindBy(name = "获取动态码")
    public WebElement RefreshCodeButton;

    //动态码input框
    @iOSFindBy(xpath = "//UIATextField[@value='7位数字']")
    //@AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.EditText[1]")
    @AndroidFindBy(xpath = "(//*[@resource-id=\"com.lufax.android:id/s_edit\"])[1]")
    public WebElement DynCodeInput;

    //交易密码input框
    @iOSFindBy(xpath = "//UIASecureTextField[@value='请输入陆金所交易密码']")
    //@AndroidFindBy(xpath = "//android.widget.LinearLayout[2]/android.widget.LinearLayout[1]/android.widget.LinearLayout[1]/android.widget.EditText[1]")
    @AndroidFindBy(xpath = "(//*[@resource-id=\"com.lufax.android:id/s_edit\"])[2]")
    public WebElement TradePassWordInput;

    //确认协议checkbox
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIAScrollView[1]/UIAButton[3]")//(name = "\uE606")
    @AndroidFindBy(id = "chkEnable")
    public WebElement AgreementCheckbox;

    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "agreement")
    public WebElement AgreementText;

    //立即充值按钮
    @iOSFindBy(name = "立即充值")
    @AndroidFindBy(id = "btn_charge")
    public WebElement ChargeNowButton;

    public void clickRechargeButton() {
        ChargeButton.click();
        driverHelper.sleep(5000);
    }

    public void rechargeAccount(String dynCode, String tradePwd){

        //输入动态码
        DynCodeInput.sendKeys(dynCode);

        //输入交易密码
        TradePassWordInput.sendKeys(tradePwd);
        driverHelper.sleep(1000);

        //确认协议
        if (!ChargeNowButton.isEnabled()){
            AgreementCheckbox.click();
            driverHelper.sleep(1000);
        }

        //点击立即充值按钮
        ChargeNowButton.click();
        driverHelper.sleep(1000);

    }

}
