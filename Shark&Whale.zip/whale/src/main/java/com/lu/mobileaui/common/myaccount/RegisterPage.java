package com.lu.mobileaui.common.myaccount;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by yuyongsong001 on 16/4/28.
 *
 * 新用户－注册页面
 *
 */
public class RegisterPage extends BasePageAbstract {

    /**
     * 注册
     */

    //免费注册按钮
    @iOSFindBy(name = "确认")
    @AndroidFindBy(id = "com.lufax.android:id/btn_register")
    public WebElement RegisterButton;

    //用户名
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATextField[1]")
    @AndroidFindBy(id = "com.lufax.android:id/et_loginname")
    public WebElement Textloginname;

    //登录密码
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIASecureTextField[1]")
    @AndroidFindBy(id = "com.lufax.android:id/et_loginpswd")
    public WebElement Textloginpwd;

    //确认登录密码
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIASecureTextField[2]")
    @AndroidFindBy(id = "com.lufax.android:id/et_loginvalidator")
    public WebElement Textloginvalidator;

    //手机号码
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATextField[2]")
    @AndroidFindBy(id = "com.lufax.android:id/et_phonenum")
    public WebElement TextmobileNo;

    //获取动态码按钮
    @iOSFindBy(name = "获取动态码")
    @AndroidFindBy(id = "com.lufax.android:id/btn_getvalidator")
    public WebElement RefreshDynCodeButton;

    //动态码
    @iOSFindBy(xpath = "//UIAApplication[1]/UIAWindow[1]/UIATextField[3]")
    @AndroidFindBy(id = "com.lufax.android:id/et_dyncode")
    public WebElement TextDyncode;

    /**
     * 注册成功
     */


    public void clickRegisterButton(){
        RegisterButton.click();

        driverHelper.sleep(1000);
        testLogger.info("[screen] 注册成功页面");

        // 切换页面等待10秒
        driverHelper.sleep(10000);
    }

    public void refreshDynCodeButton(){
        RefreshDynCodeButton.click();
    }

    public void InputTextDyncode(String dynCode){
        TextDyncode.sendKeys(dynCode);

        // 输入验证码等待5秒
        driverHelper.sleep(5000);
    }
    
}
