package com.lu.mobileaui.common.myaccount;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;


/**
 * Created by yuyongsong001 on 16/4/15.
 *
 * 我的账户-->取现
 *
 */
public class WithdrawPage extends BasePageAbstract {



    //取现金额
    @iOSFindBy(xpath = "//UIATextField[1]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.webkit.WebView[1]/android.webkit.WebView[1]/android.widget.EditText[1]")
    public WebElement WithdrawAmountInput;

    //下一步
    @iOSFindBy(xpath = "//UIAStaticText[@name='下一步' or @ label='下一步']")
    @AndroidFindBy(name ="下一步")
    //@AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.webkit.WebView[1]/android.webkit.WebView[1]/android.view.View[10]")
    public WebElement NextButton;

//    //确认详情 －－下一步
//    @iOSFindBy(name = "NA")
//    @AndroidFindBy(name ="下一步")
//    //@AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.webkit.WebView[1]/android.webkit.WebView[1]/android.view.View[9]")
//    public WebElement IsoknextButton;

    //1.交易密码
    @iOSFindBy(xpath = "//UIASecureTextField[1]")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.webkit.WebView[1]/android.webkit.WebView[1]/android.widget.EditText[1]")
    public WebElement TradePassWordInput;

    //2.动态码--点击“获取动态码”按钮
    @iOSFindBy(xpath = "//UIAStaticText[@name='获取动态码']")
    //@AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.webkit.WebView[1]/android.webkit.WebView[1]/android.view.View[4]")
    @AndroidFindBy(name = "获取动态码")
    public WebElement RefreshCodeButton;

    //2.动态码--输入动态码
    @iOSFindBy(xpath = "//UIATextField[@value='7位数字']")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.webkit.WebView[1]/android.webkit.WebView[1]/android.widget.EditText[2]")
    public WebElement DynCodeInput;

    //3.确认取现
    @iOSFindBy(xpath = "//UIAStaticText[@name='确认取现']")
    //@AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.webkit.WebView[1]/android.webkit.WebView[1]/android.view.View[5]")
    @AndroidFindBy(name = "确认取现")
    public WebElement ConfirmButton;


    // 取现申请提交成功
    @iOSFindBy(xpath = "//UIAStaticText[@name='取现申请提交成功' or @lable='取现申请提交成功']")
    @AndroidFindBy(name = "取现申请提交成功")
    public WebElement SuccessMsgText;


    public void fillAmount(Integer price){
        //WithdrawAmountInput.clear();
        WithdrawAmountInput.click();
        WithdrawAmountInput.sendKeys(price.toString());
    }

    public void fillTradePwd(String tradePwd){
        //TradePassWordInput.clear();
        TradePassWordInput.click();
        TradePassWordInput.sendKeys(tradePwd);

        // 等待5秒
        driverHelper.sleep(5000);
    }

    public void refreshDynCode(){
        RefreshCodeButton.click();
    }

    public void fillDynCode(String dynCode){
        DynCodeInput.click();
        DynCodeInput.sendKeys(dynCode);

        // 输入验证码等待5秒
        driverHelper.sleep(5000);
    }

    public void confirmWithdraw(){
        driverHelper.sleep(5000);

        ConfirmButton.click();

        // 切换页面等待5秒
        driverHelper.sleep(5000);
    }

    public void clickNextButton(){
        NextButton.click();

        // 切换页面等待5秒
        driverHelper.sleep(5000);
    }

}
