package com.lu.mobileaui.common.myinvest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/17.
 *
 * 零活宝
 * 我要赎回  继续投资
 *
 */
public class AddLinghuobaoPage extends BasePageAbstract {

    /**
     *左上角返回按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement BackButton;
    /**
     * 标题
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement TitleButton;

    /**
     * 投资明细  右上角按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement DetailButton;



    /**
     * 我要赎回
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "我要赎回")
    public WebElement RedemptionButton;

    /**
     * 继续投资
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "继续投资")
    public WebElement InvestButton;


}
