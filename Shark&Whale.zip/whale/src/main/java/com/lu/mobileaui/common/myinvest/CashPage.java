package com.lu.mobileaui.common.myinvest;

import com.lu.mobileafw.BasePageAbstract;
import com.lu.mobileainfra.be.LuTestBeEnv;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/17.
 *
 * 彩虹 安鑫 财富汇 变现
 *
 */
public class CashPage extends BasePageAbstract {

    /**
     *左上角返回按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement BackButton;


    /**
     * 标题
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement TitleButton;


    /**
     * 标题
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement RightButton;


    /**
     * 变现借款
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "变现借款")
    public WebElement CashButton;

    /**
     * 申请转让
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "申请转让")
    public WebElement TransferButton;


    /**
     * 下一步
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "下一步")
    public WebElement NextButton;

    /**
     * 确认风险合约
     *
     * 本人已阅读  以该元素定位
     */

    // 风险合约声明确认框
    @iOSFindBy(name = "\uE606")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'本人已阅读')]")
    public WebElement ReadButton;

    /**
     * 交易密码
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.widget.EditText[1]")
    public WebElement TpwdEditText;

    //获取动态码
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(name = "获取动态码")
    public WebElement RefreshDynCodeButton;

    //输入动态码
    @iOSFindBy(name = "浏览其它项目")
//    @AndroidFindBy(name = "7位数字")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.widget.EditText[2]")
    public WebElement DyncodeInput;





    /**
     * 确定
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "确定")
    public WebElement ConfirmButton;


    /**
     * 查看变现记录
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "查看变现记录")
    public WebElement CheckCashButton;

    private LuTestBeEnv testBeEnv = new LuTestBeEnv();
    /**
     * 变现   彩虹   安鑫
     *
     */
    public void Cash(String Tpwd){
        CashButton.click();
        driverHelper.trySearchElementByScroll(NextButton, true, 3);
        NextButton.click();
        int X = ReadButton.getLocation().getX();
        int Y = ReadButton.getLocation().getY();
        driver.tap(1, X / 2, Y + 10, 100);
        NextButton.click();
        TpwdEditText.sendKeys(Tpwd);
        RefreshDynCodeButton.click();
        driverHelper.sleep(3000);
        DyncodeInput.sendKeys(testBeEnv.getSms());
        ConfirmButton.click();
        CheckCashButton.click();

    }














}
