package com.lu.mobileaui.common.myinvest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/17.
 * 我的账户－－我的投资项目
 *
 */
public class MyInvestPage extends BasePageAbstract {

    //页面显示＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
    /**
     *左上角返回按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement BackButton;

    /**
     * 标题
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement TitleButton;


    /**
     * 我的投资－－产品名称
     */
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "project_name")
    public WebElement ProjectNameButton;

    /**
     *我的投资－－产品状态
     */
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "project_status")
    public WebElement ProjectStatusButton;

    /**
     * 筛选－－确认
     */
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "pick_confirm")
    public WebElement ConfirmButton;

    /**
     * 筛选－－滑动
     */
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.RelativeLayout[2]/android.widget.LinearLayout[2]")
    public WebElement moveButton;


    //活期产品＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝


    /**
     * 零活宝产品  包含有零活宝两个字的按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@name,'零活宝') or contains(@content-desc,'零活宝')  or contains(@name,'网上') or contains(@content-desc,'网上')]")
    public WebElement LinghuobaoButton;


    /**
     * 智能宝 产品  包含有智能宝两个字的按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@name,'智能宝') or contains(@content-desc,'智能宝') ]")
    public WebElement ZhinengbaoButton;


    /**
     * 富盈宝宝 产品  包含有富盈宝宝字的按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@name,'富盈宝宝') or contains(@content-desc,'富盈宝宝') ]")
    public WebElement FuyinbaobaoButton;

    /**
     * 基金  产品  包含有基金字的按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@name,'基金') or contains(@content-desc,'基金') ]")
    public WebElement FundButton;

    //变现产品＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
    /**
     * 彩虹  产品
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@name,'彩虹') or contains(@content-desc,'彩虹') ]")
    public WebElement CaihongCountButton;


    /**
     * 彩虹列表中的 第一个 彩虹  产品
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.widget.ListView[1]/android.view.View[1]")
    public WebElement CaihongButton;

    /**
     * 安鑫  产品
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@name,'安鑫') or contains(@content-desc,'安鑫') ]")
    public WebElement AnxinCountButton;


    /**
     * 安鑫列表中的 第一个 安鑫  产品
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[1]")
    public WebElement AnxinButton;


    /**
     * 财富汇  产品
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@name,'财富汇') or contains(@content-desc,'财富汇') ]")
    public WebElement CaifuhuiCountButton;


    /**
     * 财富汇列表中的 第一个 财富汇  产品
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[1]")
    public WebElement CaifuhuiButton;







    //全部项目  上滑
    public void topName(){

    }

    //状态 上滑
    public void topStatus(){

    }


}
