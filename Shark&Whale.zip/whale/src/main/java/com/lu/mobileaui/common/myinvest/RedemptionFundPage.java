package com.lu.mobileaui.common.myinvest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/18.
 *  赎回页面  基金
 *
 */
public class RedemptionFundPage extends BasePageAbstract {

    /**
     *左上角返回按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement BackButton;

    /**
     * 标题
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement TitleButton;


    /**
     *  右上角按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement RightButton;

    /**
     * 赎回份额
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.widget.EditText[1]")
    public WebElement RedemptioAmountEditText;


    /**
     * 最低赎回份额
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.view.View[4]")
    public WebElement RedemptioBottomAmountButton;




    /**
     * 全部赎回
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "全部赎回")
    public WebElement AllRedeemButton;


    /**
     * 交易密码
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.widget.EditText[2]")//android.webkit.WebView[1]/android.view.View[1]/android.widget.EditText[2]
    public WebElement TpwdEditText;



    /**
     * 确定
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "确定")
    public WebElement ConfirmButton;





    //赎回成功页面＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝


    /**
     * 赎回状态
     * 您的赎回申请已提交，预计到账时间为2016-05-26前，最终结果将以短信通知。
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.TextView[1]")
    public WebElement SuccessView;

    /**
     * 确定
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "确定")
    public WebElement CheckButton;



}
