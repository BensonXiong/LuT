package com.lu.mobileaui.common.myinvest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/18.
 * 零活宝 赎回页面
 *
 */
public class RedemptionLinghuobaoPage extends BasePageAbstract {

    /**
     *左上角返回按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement BackButton;

    /**
     * 标题
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement TitleButton;


    /**
     *  右上角按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement RightButton;

    /**
     * 赎回金额
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[1]/android.widget.EditText[1]")
    public WebElement RedemptioAmountButton;

    /**
     * 全部赎回
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@text,'全部赎回') or contains(@content-desc,'全部赎回')]")
    public WebElement AllRedeemButton;


    /**
     * 交易密码
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[3]/android.widget.EditText[1]")
    public WebElement TpwdButton;

    /**
     * ABC按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "ABC...")
    public WebElement AbcButton;


    /**
     * 确定
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "确定")
    public WebElement ConfirmButton;




    //赎回成功页面＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝


    /**
     * 赎回状态
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.view.View[2]")
    public WebElement SuccessView;

    /**
     * 确定
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.view.View[4]")
    public WebElement CheckButton;



}
