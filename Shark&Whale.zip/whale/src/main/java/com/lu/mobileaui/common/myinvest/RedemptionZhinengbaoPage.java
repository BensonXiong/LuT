package com.lu.mobileaui.common.myinvest;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/18.
 * 智能宝   富盈宝宝  赎回页面
 *
 */
public class RedemptionZhinengbaoPage extends BasePageAbstract {

    /**
     *左上角返回按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement BackButton;

    /**
     * 标题
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement TitleButton;

    /**
     *  右上角按钮 完成
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement RightButton;



    /**
     * 全部赎回
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@text,'全部赎回') or contains(@content-desc,'全部赎回')]")
    public WebElement AllRedeemButton;


    /**
     * 赎回金额
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.widget.EditText[1]")//android.webkit.WebView[1]/android.view.View[1]/android.widget.EditText[1]
    public WebElement RedemptioAmountButton;


    /**
     * 交易密码
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.widget.EditText[2]")//android.webkit.WebView[1]/android.view.View[1]/android.widget.EditText[2]
    public WebElement TpwdButton;



    /**
     * 确定
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "确定")
    public WebElement ConfirmButton;




    //赎回成功页面＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝


    /**
     * 赎回状态  赎回申请已提交
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "赎回申请已提交")
    public WebElement SuccessView;

    /**
     * 完成  在上面
     */




}
