package com.lu.mobileaui.common.myinvest;

import com.lu.mobileafw.BasePageAbstract;
import com.lu.mobileainfra.be.LuTestBeEnv;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/23.
 *
 * 转让页面   彩虹  安鑫  财富汇
 *
 *
 */
public class TransferPage extends BasePageAbstract {

    /**
     *左上角返回按钮
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement BackButton;


    /**
     * 标题
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement TitleButton;


    /**
     * 标题
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement RightButton;


    /**
     * 变现借款
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "变现借款")
    public WebElement CashButton;

    /**
     * 申请转让
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "申请转让")
    public WebElement TransferButton;


    /**
     * 全部转让
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "全部转让")
    public WebElement AllTransferButton;



    /**
     * 使用
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'建议')]")
    public WebElement UseButton;

    /**
     * 下一步
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "下一步")
    public WebElement NextButton;



    /**
     * 确认风险合约
     *
     * 本人已阅读  以该元素定位
     */

    // 风险合约声明确认框
    @iOSFindBy(name = "\uE606")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'本人已阅读')]")
    public WebElement ReadButton;


    /**
     * 确认转让
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "确认转让")
    public WebElement ConfirmTransferButton;



    /**
     * 交易密码
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.widget.EditText[1]")
    public WebElement TpwdEditText;

    /**
     * 交易密码
     *
     * 弹出的输入框  交易码
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.RelativeLayout[1]/android.widget.EditText[1]")
    public WebElement TpwdEditPopupText;




    //获取动态码
    @iOSFindBy(name = "浏览其它项目")
    @AndroidFindBy(name = "获取动态码")
    public WebElement RefreshDynCodeButton;

    //输入动态码
    @iOSFindBy(name = "浏览其它项目")
//    @AndroidFindBy(name = "7位数字")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.widget.EditText[2]")
    public WebElement DyncodeInput;



    /**
     * 确定
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "确定")
    public WebElement ConfirmButton;


    /**
     * 查看变现记录
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "查看变现记录")
    public WebElement CheckCashButton;


    /**
     * 查看变现记录
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(name = "转让申请提交成功")
    public WebElement CheckTransferButton;



    /**
     * 列表中的 第一个 彩虹  产品
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'CH')]")
    public WebElement CaihongButton;

    /**
     * 列表中的 第一个 安鑫  产品
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'AnXin')]")
    public WebElement AnXinButton;


    /**
     * 列表中的 第一个 安鑫  产品
     */
    @iOSFindBy(name = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'财富汇')]")
    public WebElement CaiFuHuiButton;


    private LuTestBeEnv testBeEnv = new LuTestBeEnv();

    /**
     * 转让   彩虹   安鑫
     *
     */
    public void transfer(String Tpwd){
        TransferButton.click();
        UseButton.click();
        driverHelper.sleep(3000);

        driverHelper.trySearchElementByScroll(NextButton, true, 3);
        NextButton.click();
        int X = ReadButton.getLocation().getX();
        int Y = ReadButton.getLocation().getY();
        driver.tap(1, X / 2, Y + 10, 100);

        driverHelper.sleep(3000);

        ConfirmTransferButton.click();
        TpwdEditPopupText.sendKeys(Tpwd);
        ConfirmButton.click();
        CheckTransferButton.click();

    }

    /**
     * 转让  财富汇
     *
     */
    public void transferCaiFuHui(String Tpwd){
        TransferButton.click();
        if (driverHelper.checkExist(AllTransferButton)){
            AllTransferButton.click();
        }
        if (driverHelper.checkExist(UseButton)){
            UseButton.click();
        }
        driverHelper.sleep(3000);

        driverHelper.trySearchElementByScroll(NextButton, true, 3);
        NextButton.click();
        int X = ReadButton.getLocation().getX();
        int Y = ReadButton.getLocation().getY();
        driver.tap(1, X / 2, Y + 10, 100);

        driverHelper.sleep(3000);

        ConfirmTransferButton.click();
        TpwdEditPopupText.sendKeys(Tpwd);
        ConfirmButton.click();
        CheckTransferButton.click();

    }
}
