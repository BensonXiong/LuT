package com.lu.mobileaui.common.vip;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/13.
 *
 *竞拍
 *
 */
public class AuctionPage extends BasePageAbstract {


    //出价输入框
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "etPrice")
    public WebElement PriceEdit;


    //出价按钮
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "btnAction")
    public WebElement PriceButton;


}
