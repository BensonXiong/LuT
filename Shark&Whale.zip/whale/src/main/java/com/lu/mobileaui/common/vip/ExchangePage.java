package com.lu.mobileaui.common.vip;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/13.
 *
 * 换购商品
 *
 */
public class ExchangePage extends BasePageAbstract {

    // 换购数量
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "input_content")
    public WebElement ContentEdit;


    // 换购按钮
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "换购")
    public WebElement ExchangeButton;



    // 确定按钮
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "换购")
    public WebElement ConfirmButton;

}
