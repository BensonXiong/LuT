package com.lu.mobileaui.common.vip;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/13.
 *
 * 我的通币
 *
 */
public class MyCurrencyPage extends BasePageAbstract {

    // 通币标题
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@content-desc,'我的通币') or contains(@text,'我的通币')]")
    public WebElement CurrencyTitleButton;


    // 可用通币
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'可用通币') or contains(@text,'可用通币')]")
    public WebElement FreeCurrencyButton;


    // 冻结通币
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'冻结通币') or contains(@text,'冻结通币')]")
    public WebElement FreezeCurrencyButton;

    // 通币明细
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'通币明细') or contains(@text,'通币明细')]")
    public WebElement CurrencyDetailsButton;

    // 换购商品
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'换购商品') or contains(@text,'换购商品')]")
    public WebElement ExchangeButton;

    // 竞拍商品
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'竞拍商品') or contains(@text,'竞拍商品')]")
    public WebElement AuctionButton;


    // 刮刮乐商品
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'刮刮乐商品') or contains(@text,'刮刮乐商品')]")
    public WebElement ScratchButton;

    // 返回
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement BackButton;

}
