package com.lu.mobileaui.common.vip;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/13.
 *
 *
 * 我的订单
 */
public class MyOrderPage extends BasePageAbstract {

    // 我的订单－－订单标题
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@content-desc,'换购订单') or contains(@text,'换购订单')]")
    public WebElement OrderTitleButton;


    // 我的订单－－产品名称－筛选
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "project_name")
    public WebElement ProjectNameButton;

    // 我的订单－－产品状态－筛选
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "project_status")
    public WebElement ProjectStatusButton;



    // 我的订单－－筛选－－确认
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "pick_confirm")
    public WebElement PickConfirmButton;



}
