package com.lu.mobileaui.common.vip;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/15.
 *
 * 会员俱乐部-商品列表
 *
 */

public class ProductListPage extends BasePageAbstract {

    // 左上角 返回按钮
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.view.View[1]")
    public WebElement BackButton;


    // 兑换刮刮乐竞拍 标题
    @iOSFindBy(xpath = "NA")
//    @AndroidFindBy(name = "兑换刮刮乐竞拍")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.view.View[2]")
    public WebElement TitleButton;


    //全部分类
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[5]/android.view.View[1]")
    public WebElement CategoryButton;

    //全部分类 第一个
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[1]")//android.webkit.WebView[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[contains(@content-desc,'全部分类')]
    public WebElement CategoryAllButton;

    //全部分类 第二个
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[2]")//android.webkit.WebView[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[contains(@content-desc,'全部分类')]
    public WebElement CategoryOneButton;

    //全部分类 第三个
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.widget.ListView[1]/android.view.View[3]")
    public WebElement CategoryTwoButton;




    //综合排序
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[5]/android.view.View[2]")
    public WebElement SortButton;


    //综合排序
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[1]/android.view.View[1]")
    public WebElement SortAllButton;

    //第一个 返券最多
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[1]/android.view.View[2]")
    public WebElement SortOneButton;

    //第二个  返券最多
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[1]/android.view.View[3]")
    public WebElement SortTwoButton;

    //第三个  返券最多
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[1]/android.view.View[4]")
    public WebElement SortThreeButton;





    //筛选
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[5]/android.view.View[3]")
    public WebElement FilterButton;


    //第一个  无限制
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[5]/android.widget.Button[1]")
    public WebElement FilterOneButton;


    //第二个  我可参与
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[5]/android.widget.Button[2]")
    public WebElement FilterTwoButton;

    //第三个  1-100
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[5]/android.widget.Button[3]")
    public WebElement FilterThreeButton;


    //第四个  101-1000
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[6]/android.widget.Button[1]")
    public WebElement FilterFourButton;

    //第五个  1001-10000
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[6]/android.widget.Button[2]")
    public WebElement FilterFiveButton;


    //第六个  101-1001
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[6]/android.widget.Button[3]")
    public WebElement FilterSixButton;

    //第七个  不限 第二排
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[8]/android.widget.Button[1]")
    public WebElement FilterSevenutton;

    //第八个  VIP专享
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[8]/android.widget.Button[2]")
    public WebElement FilterEightButton;


    //第九个  普通会员
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[8]/android.widget.Button[3]")
    public WebElement FilterNineButton;


    //清除筛选
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "清空筛选 Link")
    public WebElement FilterClearButton;

    //完成
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "清空筛选 Link")
    public WebElement FilterCompleteButton;



//===============================

    // 会员俱乐部－－产品列表－－兑换－－第一个
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[6]/android.view.View[1]/android.widget.Image[1]")
    public WebElement NowExchangeButton;

    // 会员俱乐部－－产品列表－－刮刮乐－－立即刮奖
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "立即刮奖")
    public WebElement NowScratchButton;


    // 会员俱乐部－－产品列表－－竞拍－－我要出价
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "我要出价")
    public WebElement NowPriceButton;



}
