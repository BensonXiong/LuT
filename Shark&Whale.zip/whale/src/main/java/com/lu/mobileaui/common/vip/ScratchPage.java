package com.lu.mobileaui.common.vip;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.TouchAction;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/13.
 *
 * 刮刮乐
 *
 */
public class ScratchPage extends BasePageAbstract {

    //会员俱乐部－－单品详情页－－我要刮奖
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "我要刮奖")//android.widget.TextView[contains(@content-desc,'换购订单') or contains(@text,'换购订单')]
    public WebElement ScratchButton;

    //会员俱乐部－－单品详情页－－我要刮奖－－刮刮乐
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.RelativeLayout[1]")//android.widget.TextView[contains(@content-desc,'换购订单') or contains(@text,'换购订单')]
    public WebElement ScratchView;



    //会员俱乐部－－8通币刮刮乐－－产品列表－－立即刮奖－－刮奖
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "rubbler")
    public WebElement EightCurrencyView;


    public void scratch(int X,int Y){
        //driverHelper.sleep(5000);
        TouchAction t = new TouchAction(driver);
        int moveX = 100;
        int moveY = 400;
        int wait = 200;

        t.press(X, Y).waitAction(wait)
                .moveTo(0,moveY).waitAction(wait)
                .moveTo(moveX, -moveY).waitAction(wait)
                .moveTo(0,moveY).waitAction(wait)
                .moveTo(moveX, -moveY).waitAction(wait)
                .moveTo(0,moveY).waitAction(wait)
                .moveTo(moveX, -moveY).waitAction(wait)
                .moveTo(0,moveY).waitAction(wait);
        //t.release();
        t.perform();
        t.waitAction();
    }





}
