package com.lu.mobileaui.common.vip;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/15.
 *
 * 会员俱乐部 搜索
 *
 */

public class SearchPage extends BasePageAbstract {

    // 取消搜索
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.view.View[1]")
    public WebElement BackButton;


    // 搜索输入框
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[7]/android.widget.EditText[1]")//android.view.View[1]/android.view.View[2]/android.widget.EditText[1]
    public WebElement SearchEdit;

    // 搜索按钮
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[7]/android.widget.Button[1]")
    public WebElement SearchButton;



}
