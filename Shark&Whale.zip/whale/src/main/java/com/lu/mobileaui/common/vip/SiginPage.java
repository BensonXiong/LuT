package com.lu.mobileaui.common.vip;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/15.
 *
 * 会员俱乐部  签到
 *
 */

public class SiginPage extends BasePageAbstract {

    // 返回
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "title_bar_left_tv")
    public WebElement BackButton;

    // 签到
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "签到")
//    @AndroidFindBy(id = "title_bar_title_tv")
    public WebElement SignInButton;

    // 分享
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "分享")
//    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement ShareButton;

    // 签到规则
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "签到规则")
    public WebElement ShareRuleButton;


//    //7
//    @iOSFindBy(xpath = "NA")
//    @AndroidFindBy(name = "7")
//    public WebElement SevenButton;

    // 今日已签到
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "今日已签到")//android.webkit.WebView[1]/android.view.View[1]/android.view.View[1]
    public WebElement TodaySignInOkButton;

    // 今日签到成功
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "今日签到成功")//android.webkit.WebView[1]/android.view.View[1]/android.view.View[1]
    public WebElement TodaySignInButton;


    // 获得通币
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[1]/android.view.View[1]")
    public WebElement GetMoney;

    // 签到天数
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[1]/android.view.View[1]")
    public WebElement SigninDays;

    //微信好友
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "微信好友")
    public WebElement WeChat;


    //微信朋友圈
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "微信朋友圈")
    public WebElement WeChats;

    //取消
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "取消")
    public WebElement Cancel;



}
