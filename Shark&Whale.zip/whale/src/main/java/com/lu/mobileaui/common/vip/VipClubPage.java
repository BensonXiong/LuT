package com.lu.mobileaui.common.vip;

import com.lu.mobileafw.BasePageAbstract;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSFindBy;
import org.openqa.selenium.WebElement;

/**
 * Created by liuyinping on 16/5/15.
 *
 * 会员俱乐部首页
 *
 */

public class VipClubPage extends BasePageAbstract {

    // 签到
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "签到")
//    @AndroidFindBy(id = "title_bar_right_tv")
    public WebElement SignInButton;

    // 签到右边红点
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "btn_corner_hint")
    public WebElement SingInRedButton;

    // 顶部 广告
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.webkit.WebView[1]/android.view.View[1]/android.view.View[2]")
    public WebElement TopViewButton;


    //我的通币
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'我的通币') or contains(@text,'我的通币')]")
    public WebElement MyCurrencyButton;

    // 我的订单
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "我的订单 Link")
    public WebElement MyOrderButton;


    // 搜索兑换商品 按钮
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(id = "tv_search_hint")
    public WebElement SearchButton;


    // 1 兑换
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[2]/android.view.View[1]/android.view.View[1]")
    public WebElement OneButton;

    // 2 娱乐
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[2]/android.view.View[2]/android.view.View[1]")
    public WebElement TwoButton;

    // 3 VIP
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[2]/android.view.View[3]/android.view.View[1]")
    public WebElement ThreeButton;

    // 4 券码
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[2]/android.view.View[4]/android.view.View[1]")
    public WebElement FourButton;

    // 左  签到
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[3]/android.view.View[1]")
    public WebElement LeftButton;

    // 右  拍卖
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.widget.ListView[3]/android.view.View[2]")
    public WebElement RightButton;

    //8通币刮刮乐
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc,'8通币刮刮乐') or contains(@text,'8通币刮刮乐')]")
    public WebElement EightCurrencyButton;

    //第一个产品
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(xpath = "//android.view.View[10]/android.widget.Image[1]")
    public WebElement ProductOneButton;

    //底部查看更多
    @iOSFindBy(xpath = "NA")
    @AndroidFindBy(name = "查看更多兑换商品")
    public WebElement MoreButton;


}
