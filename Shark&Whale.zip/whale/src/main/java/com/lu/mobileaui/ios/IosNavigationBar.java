package com.lu.mobileaui.ios;

import com.lu.mobileainfra.lma.BasePage;

/**
 * Created by huangyinhuang on 16/4/11.
 *
 * app导航栏
 *
 */

public class IosNavigationBar extends BasePage {
}
