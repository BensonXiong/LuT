package com.lu.mobileat.android;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.android.AdLoginPage;
import com.lu.mobileaui.android.AdStartPage;
import com.lu.mobileaui.android.home.AdHomePage;
import com.lu.mobileaui.android.register.BindBankCardPage;
import com.lu.mobileaui.android.register.RegisterNewAccountPage;
import com.lu.mobileaui.android.register.UserPreparationPage;
import com.lufax.laf.biz.domain.NewUserParameters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.lu.mobileafw.app.TestHelper.for_id;
import static com.lu.mobileafw.app.TestHelper.waitInvisible;
import static java.lang.Thread.sleep;

/**
 * Created by huangyinhuang on 16/3/15.
 */
public class TestLoginPage extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private AdStartPage adStartPage = new AdStartPage();
    private AdHomePage homePage = new AdHomePage();
    private AdLoginPage adLoginPage = new AdLoginPage();
    private RegisterNewAccountPage registerNewAccountPage = new RegisterNewAccountPage();
    private UserPreparationPage userPreparationPage = new UserPreparationPage();
    private BindBankCardPage bindBankCardPage = new BindBankCardPage();

    @BeforeMethod
    public void setup() {
        adStartPage.SwipeStartupPage();
        homePage.clickLoginButton();
    }

    @AfterMethod
    public void teardown() {

    }

    /**
     * 用户登陆
     */
    @Test
    public void testLogin() {

        logger.info("1) fill the user name");
        adLoginPage.fillUserName("uia1");

        logger.info("2) fill the user password");
        adLoginPage.fillUserPassword("mima123");

        logger.info("3) check if it's required to fill verify code");
        adLoginPage.checkAndFillVerifyCode();

        logger.info("4) click the login button");
        adLoginPage.clickLoginButton();

        logger.info("5) check the login button doesn't exist any more.");
        waitInvisible(for_id("title_bar_right_tv"));

    }

    /**
     * 用户登陆页面关闭
     */
    @Test
    public void testCloseButton() {

        logger.info("1) click the close button");
        adLoginPage.clickCloseButton();

    }

    /**
     * 注册账号
     */
    @Test
    public void testRegisterAccount() throws InterruptedException {

        logger.info("1) click the register New Account button");
        adLoginPage.clickRegisterNewAccount();

        NewUserParameters newUserParameters = new NewUserParameters();

        logger.info("user name: " + newUserParameters.getUserName());
        logger.info("user password: " + newUserParameters.getLoginPwd());
        logger.info("user phoneNo: " + newUserParameters.getMobileNo());
        logger.info("user real name: " + newUserParameters.getRealName());
        logger.info("user card number: " + newUserParameters.getCardNo());
        logger.info("user bank: " + newUserParameters.getBank());
        logger.info("user bank code: " + newUserParameters.getBankCode());
        logger.info("user birthday: " + newUserParameters.getBirthday());
        logger.info("user answer: " + newUserParameters.getAnswer());
        logger.info("user credential: " + newUserParameters.getCredentialsNo());
        logger.info("user ip address: " + newUserParameters.getIpAddress());
        logger.info("user market cookie: " + newUserParameters.getMarketCookie());
        logger.info("user trade pwd: " + newUserParameters.getTradePwd());


        registerNewAccountPage.registerNewAccount(newUserParameters);

        userPreparationPage.authenticatUserName(newUserParameters);

        bindBankCardPage.clickReturnButton();

        userPreparationPage.clickReturnPreparation();
    }

    /**
     * 找回账号
     */
    @Test
    public void testRetrieveAccount() throws InterruptedException {

        logger.info("1) click the retrieve account button");
        adLoginPage.clickRetrieveAccount();

        sleep(6000);

        String pageSrc = driver.getPageSource();
        logger.info(pageSrc);

    }
}
