package com.lu.mobileat.android.invest;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.android.AdLoginPage;
import com.lu.mobileaui.android.AdNavigationBar;
import com.lu.mobileaui.android.AdStartPage;
import com.lu.mobileaui.android.home.AdHomePage;
import com.lu.mobileaui.android.invest.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Created by huangyinhuang on 16/3/16.
 */
public class TestLingHuoBao extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private AdStartPage adStartPage = new AdStartPage();
    private AdNavigationBar AdNavigationBar = new AdNavigationBar();
    private AdInvestmentPage investmentPage = new AdInvestmentPage();
    private AdCashManagementPage cashManagementPage = new AdCashManagementPage();
    private AdHomePage adHomePage = new AdHomePage();
    private AdLoginPage adLoginPage = new AdLoginPage();
    private AdProjectDetailsPage projectDetailsPage = new AdProjectDetailsPage();
    private AdInvestmentConfirmPage investmentConfirmPage = new AdInvestmentConfirmPage();
    private AdLastPromptPaget adLastPromptPage = new AdLastPromptPaget();

    @BeforeMethod
    public void setup() {
        adStartPage.SwipeStartupPage();
        adHomePage.clickLoginButton();
        adLoginPage.loginApp();
        AdNavigationBar.clickInvestmentButton();
    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void testPurchaseLinghuobao() {

        // 点击投资理财
        investmentPage.clickCashManagement();

        // 现金管理页面
        cashManagementPage.clickProudct();

        // 项目详情页
        projectDetailsPage.clickFreshGuide();
        projectDetailsPage.clickInvestmentNow();
        projectDetailsPage.fillPrice2(1);
        projectDetailsPage.clickOkButton2();

        // 投资页面
        investmentConfirmPage.confirmAgreement();
        investmentConfirmPage.confirmTrade();

        // 提示页面
        adLastPromptPage.clickDetailsButton();

    }

    @Test
    public void testPurchaseLinghuobaoDemo() throws InterruptedException {

        // 划屏
        logger.info("swipe the page");
        int width=driver.manage().window().getSize().width;
        int height=driver.manage().window().getSize().height;
        logger.info("width=" + width);
        logger.info("height=" + height);
        Thread.sleep(1000);
        driver.swipe(width / 2, height - 200, width / 2, 400, 1000);
        Thread.sleep(5000);
        driver.swipe(width / 2, 400, width / 2, height - 200, 1000);
        Thread.sleep(1000);

        // 点击投资理财
        investmentPage.clickCashManagement();

        // 现金管理页面
        cashManagementPage.clickProudct();

        // 项目详情页
        projectDetailsPage.clickFreshGuide();
        projectDetailsPage.clickInvestmentNow();
        projectDetailsPage.fillPrice2(1);
        projectDetailsPage.clickOkButton2();

        // 投资页面
        investmentConfirmPage.confirmAgreement();
        investmentConfirmPage.confirmTrade();

        // 提示页面
        adLastPromptPage.clickDetailsButton();

        Thread.sleep(20000);

    }


}
