package com.lu.mobileat.android.myaccount;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.android.AdLoginPage;
import com.lu.mobileaui.android.AdNavigationBar;
import com.lu.mobileaui.android.AdStartPage;
import com.lu.mobileaui.android.home.AdHomePage;
import com.lu.mobileaui.android.myaccount.AdMyAccountPage;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Created by huangyinhuang on 16/3/17.
 */
public class TestMyAccountPage extends BaseTestCase {

    private AdStartPage adStartPage = new AdStartPage();
    private AdHomePage adHomePage = new AdHomePage();
    private AdLoginPage adLoginPage = new AdLoginPage();

    private AdNavigationBar AdNavigationBar = new AdNavigationBar();
    private AdMyAccountPage myAccountPage = new AdMyAccountPage();

    @BeforeMethod
    public void setup() {
        adStartPage.SwipeStartupPage();
        adHomePage.clickLoginButton();
        adLoginPage.loginApp();
    }

    @AfterMethod
    public void teardown() {

    }

    /**
     * 我的账号详情页
     */

    @Test
    public void testMyAccountDetails() {
        // 打开“我的账户”
        AdNavigationBar.clickMyAccountButton();

        // 跳过引导页
        myAccountPage.solveHomePagehandleGuideById();

        // 检查页面
        Double actualValue = myAccountPage.getAssetValue();
        testAssert.assertEquals(actualValue, 50000000, 0.001, "verify the asset value.");

        // 点击安全退出
        myAccountPage.clickQuitButton();
    }
}
