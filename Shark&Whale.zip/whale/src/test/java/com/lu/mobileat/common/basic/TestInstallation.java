package com.lu.mobileat.common.basic;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.StartPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by huangyinhuang on 16/4/22.
 */
public class TestInstallation extends BaseTestCase {
    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @BeforeMethod
    public void setup() {

    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void testReinstall() throws Exception {

        String appPackageName = super.getAppBundleID();
        Boolean isAppInstalled = null;

        logger.info("0) check the app installation status ");
        isAppInstalled = driver.isAppInstalled(appPackageName);
        testAssert.assertTrue(isAppInstalled, "check if app is installed.");

        logger.info("1) close the app ");
        driver.closeApp();
        Thread.sleep(5000);

        logger.info("2) uninstall the app ");
        driver.removeApp(appPackageName);
        Thread.sleep(5000);

        // workaround: failed to get app installation status after app removal
        try {
            isAppInstalled = driver.isAppInstalled(appPackageName);
        }catch (Exception ex) {
            isAppInstalled = false;
        }
        testAssert.assertFalse(isAppInstalled, "Check if app has uninstalled.");

        logger.info("3) reinstall the app ");
        String appPath = super.getAppPath();
        driver.installApp(appPath);
        driver.launchApp();
        Thread.sleep(5000);

        isAppInstalled = driver.isAppInstalled(appPackageName);
        testAssert.assertTrue(isAppInstalled, "Check if app has been reinstalled.");

    }


    @Test
    public void testSimple1() {
        logger.info("this is a simple test 1");
        StartPage startPage = new StartPage();
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        startPage.swipeStartupPage();
    }

//    @Test
//    public void testReinstallEx() throws Exception {
//
//        String appPackageName = "com.lufax.android";
//        Boolean isAppInstalled = null;
//
//        logger.info("0) check the app installation status ");
//        isAppInstalled = driver.isAppInstalled(appPackageName);
//        testAssert.assertTrue(isAppInstalled, "check if app is installed.");
//
//        logger.info("1) close the app ");
//        //driver.closeApp();
//        Thread.sleep(5000);
//
//        logger.info("2) check the app installation status ");
//        isAppInstalled = driver.isAppInstalled(appPackageName);
//        testAssert.assertTrue(isAppInstalled, "check if app is installed.");
//
//        driver.launchApp();
//
//    }

    @Test
    public void testSimple2() {
        logger.info("this is a simple test 2");
        StartPage startPage = new StartPage();
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        startPage.swipeStartupPage();
    }

}
