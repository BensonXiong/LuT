package com.lu.mobileat.common.basic;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.GesturePage;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myaccount.PersonalSettingsPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

import static com.lu.mobileafw.app.TestHelper.checkExist;

/**
 * Created by huangyinhuang on 16/4/13.
 */
public class TestLogin extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private NavigationBar navigationBar = new NavigationBar();
    private LoginPage loginPage = new LoginPage();
    private MyAccountPage myAccountPage = new MyAccountPage();
    private GesturePage gesturePage = new GesturePage();
    private PersonalSettingsPage personalSettingsPage = new PersonalSettingsPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myAccountPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), gesturePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), personalSettingsPage);

        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();
    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void testLoginOut() {

        //click the login button on the home page
        testAssert.info("[screen] App开始登录");
        homePage.LoginButton.click();

        // log in
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());
        boolean bExist = driverHelper.checkExist(navigationBar.MyAccountButton);
        testAssert.assertTrue(bExist, "[screen] App登录成功");

        // go to my account page
        navigationBar.MyAccountButton.click();
        testAssert.info("[screen] 切换到我的账号页面");

        // log out
        myAccountPage.LogOut();
        // check if login button is displayed
        testAssert.assertTrue(checkExist(homePage.LoginButton), "[screen] 登出成功");

    }

    @Test
    public void testLoginByGesture() {

        //click the login button on the home page
        testAssert.info("[screen] App开始登录");
        homePage.LoginButton.click();

        // log in
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());
        boolean bExist = driverHelper.checkExist(navigationBar.MyAccountButton);
        testAssert.assertTrue(bExist, "[screen] App登录成功");

        // go to my account page
        navigationBar.MyAccountButton.click();
        testAssert.info("[screen] 切换到我的账号页面");

        // enable gesture
        myAccountPage.SkipGuide();
        myAccountPage.FaviconButton.click();
        testAssert.info("[screen] 切换到我的账号详情");
        personalSettingsPage.GestureSwitchCheckBox.click();

        personalSettingsPage.PopUpUserPwdInput.clear();
        personalSettingsPage.PopUpUserPwdInput.sendKeys(testConf.getUserPwd());
        personalSettingsPage.PopUpUserPwdConfirmButton.click();

        // set gesture
        testAssert.info("[screen] 进入设置手势页面");
        gesturePage.setGesture();
        gesturePage.setGesture();
        gesturePage.GestureReadyOkButton.click();

        // log out
        myAccountPage.LogOut();
        //testAssert.info("[screen] 登出，准备重新使用手势登录");

        // try to re-login with gesture
        homePage.LoginButton.click();
        testAssert.info("[screen] 重新登录，使用手势密码");
        gesturePage.loginGesture();

        // check if login button is not displayed
        testAssert.assertTrue(!checkExist(homePage.LoginButton), "[screen] 手势登录成功");
        logger.info("当前平台：" + testConf.getDevicePlatformName());
//        if(testConf.getDevicePlatformName().equals("ios")){
            closeGestrue();
//        }


    }
    public void closeGestrue(){

        // go to my account page
        navigationBar.MyAccountButton.click();
        testAssert.info("[screen] 切换到我的账号页面");

        // enable gesture
//        myAccountPage.SkipGuide();
        myAccountPage.FaviconButton.click();
        testAssert.info("[screen] 切换到我的账号详情");
        personalSettingsPage.GestureSwitchCheckBox.click();

        personalSettingsPage.PopUpUserPwdInput.clear();
        personalSettingsPage.PopUpUserPwdInput.sendKeys(testConf.getUserPwd());
        personalSettingsPage.PopUpUserPwdConfirmButton.click();


        // set gesture
        gesturePage.GestureReadyOkButton.click();
        testAssert.info("[screen] 手势关闭成功");
    }

}
