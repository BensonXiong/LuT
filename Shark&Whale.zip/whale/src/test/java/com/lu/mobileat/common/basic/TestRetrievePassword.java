package com.lu.mobileat.common.basic;

import com.lu.mobileafw.report.ShareLog;
import com.lu.mobileainfra.be.LuTestBeEnv;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.RetrievePasswordPage;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/5/12.
 *
 * 忘记密码 或 重置登录密码
 *
 */
public class TestRetrievePassword extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();
    private RetrievePasswordPage retrievePasswordPage = new RetrievePasswordPage();
    private LuTestBeEnv luTestBeEnv =  new LuTestBeEnv();

    @BeforeMethod
    public void setup() {

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), retrievePasswordPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), luTestBeEnv);



        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.clickRetrievePassword();

    }

    @AfterMethod
    public void teardown() {

    }

    //mobile2运行
    @Test
    public void testRetrievePassword(){

        ShareLog.getReportLog();
        retrievePasswordPage.RetrievePassword("uia4","10823816641","123", luTestBeEnv,testConf.getUserPwd());

    }

}
