package com.lu.mobileat.common.home;

import com.lu.mobileafw.exception.NoSuchWebElementException;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.*;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myaccount.PersonalSettingsPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.lu.mobileafw.app.TestHelper.for_name;

/**
 * Created by huangyinhuang on 16/4/27.
 */
public class TestHomePage extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private NavigationBar navigationBar = new NavigationBar();
    private LoginPage loginPage = new LoginPage();
    private MyAccountPage myAccountPage = new MyAccountPage();
    private GesturePage gesturePage = new GesturePage();
    private PersonalSettingsPage personalSettingsPage = new PersonalSettingsPage();
    private HeaderBar headerBar = new HeaderBar();

    @BeforeClass
    public void init() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myAccountPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), gesturePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), personalSettingsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), headerBar);
    }

    @BeforeMethod
    public void setup() {
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();
    }

    @AfterMethod
    public void teardown() {


    }

    @Test
    public void testBanner() {

        testLogger.info("[screen] 切换到首页");

        homePage.AdvertiseBanner.click();
        testAssert.assertTrue(true, "[screen] 广告栏页面");
        //TODO：跳到投资页面－》检测

    }


    @Test
    public void testRecommendProductNewbie() {

        testLogger.info("[screen] 切换到首页");

        //新手福利
        homePage.ProductRecommendItem1.click();

        // 跳到新手专区，检查页面标题
        WebElement newBieTitle = headerBar.MiddleContainer.findElement(for_name("新手专区"));
        testAssert.assertNotNull(newBieTitle,"[screen] 新手页面的标题不为空");
        testAssert.assertEquals( "新手专区", newBieTitle.getText(),"当前页面的标题应为－新手专区");

    }

    @Test
    public void testQuickProductHuoqi() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到首页");

        boolean bFound = driverHelper.trySearchElementByScroll(homePage.HuoQiProduct, true, 5);
        if (!bFound) {
            throw new NoSuchWebElementException("The huoqi product is not found. Please check the product is on the home page.");
        }
        testAssert.info("[screen] 滑动到快速投资模块");
        homePage.selectQuickProductHuoqi();

        List l = driver.findElementsByName("灵活赎回");
        testAssert.assertTrue( l.size() > 0,"[screen] 列表中灵活赎回的产品个数大于0");

    }

    @Test
    public void testQuickProductThreeMonth() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到首页");

        boolean bFound = driverHelper.trySearchElementByScroll(homePage.ThreeMonthProduct, true, 5);
        if (!bFound) {
            throw new NoSuchWebElementException("The year product is not found. Please check the product is on the home page.");
        }
        
        testAssert.info("[screen] 滑动到快速投资模块");
        homePage.selectQuickProductThreeMonth();

        List l0 = driver.findElementsByName("灵活赎回");
        List l14 = driver.findElementsByName("14天锁定期");
        List l28 = driver.findElementsByName("28天锁定期");

        testAssert.info("灵活赎回的产品个数：" + l0.size());
        testAssert.info("14天锁定期的产品个数：" + l14.size());
        testAssert.info("28天的产品个数：" + l28.size());

        int count = l0.size() + l14.size() + l28.size();
        testAssert.assertTrue( count > 0,"[screen] 列表中3个月周期的产品个数大于0");

    }

    @Test
    public void testQuickProductSixMonth() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到首页");

        boolean bFound = driverHelper.trySearchElementByScroll(homePage.SixMonthProduct, true, 5);
        if (!bFound) {
            throw new NoSuchWebElementException("The year product is not found. Please check the product is on the home page.");
        }

        testAssert.info("[screen] 滑动到快速投资模块");
        homePage.selectQuickProductSixMonth();

        List l100 = driver.findElementsByName("100天");
        List l180 = driver.findElementsByName("180天");
        List l3m = driver.findElementsByName("3个月");
        List l6m = driver.findElementsByName("6个月");
        List l24m = driver.findElementsByName("24个月");
        List l360m = driver.findElementsByName("360个月");

        testAssert.info("100天的产品个数：" + l100.size());
        testAssert.info("180天的产品个数：" + l180.size());
        testAssert.info("3个月的产品个数：" + l3m.size());
        testAssert.info("12个月的产品个数：" + l6m.size());
        testAssert.info("24个月的产品个数：" + l24m.size());
        testAssert.info("360个月的产品个数：" + l360m.size());

        int count = l100.size() + l180.size() + l3m.size() + l6m.size() + l24m.size() + l360m.size();
        testAssert.assertTrue( count > 0,"[screen] 列表中12个月周期的产品个数大于0");

    }

    @Test
    public void testQuickProductYear() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到首页");

        boolean bFound = driverHelper.trySearchElementByScroll(homePage.YearProduct, true, 5);
        if (!bFound) {
            throw new NoSuchWebElementException("The year product is not found. Please check the product is on the home page.");
        }

        testAssert.info("[screen] 滑动到快速投资模块");
        homePage.selectQuickProductYear();

        List l180 = driver.findElementsByName("180天");
        List l12m = driver.findElementsByName("12个月");

        testAssert.info("180天的产品个数：" + l180.size());
        testAssert.info("12个月的产品个数：" + l12m.size());

        int count = l180.size() + l12m.size();
        testAssert.assertTrue( count > 0,"[screen] 列表中12个月周期的产品个数大于0");

    }

    @Test
    public void testQuickProductLongPeriod() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到首页");

        boolean bFound = driverHelper.trySearchElementByScroll(homePage.LongPeriodProduct, true, 5);
        if (!bFound) {
            throw new NoSuchWebElementException("The long period product is not found. Please check the product is on the home page.");
        }

        testAssert.info("[screen] 滑动到快速投资模块");
        homePage.selectQuickProductLongPeriod();

        List l365 = driver.findElementsByName("365天");
        List l12m = driver.findElementsByName("12个月");
        List l24m = driver.findElementsByName("24个月");
        List l36m = driver.findElementsByName("36个月");

        testAssert.info("365天的产品个数：" + l365.size());
        testAssert.info("12个月的产品个数：" + l12m.size());
        testAssert.info("24个月的产品个数：" + l24m.size());
        testAssert.info("36个月的产品个数：" + l36m.size());

        int count = l365.size() + l12m.size() + l24m.size() + l36m.size();
        testAssert.assertTrue( count > 0,"[screen] 列表中36个月周期的产品个数大于0");

    }

}
