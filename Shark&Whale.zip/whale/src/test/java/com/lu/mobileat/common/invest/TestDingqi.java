package com.lu.mobileat.common.invest;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.*;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/5/18.
 *
 * 定期
 *产品－（财富汇，安鑫，彩虹，安盈－票据，粤股交，信托理财）
 *
 *
 */
public class TestDingqi extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private DingqiPage dingqiPage= new DingqiPage();
    private InvestInsurancePage investInsurancePage = new InvestInsurancePage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();
    private InvestmentConfirmPage investmentConfirmPage = new InvestmentConfirmPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), dingqiPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investInsurancePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentConfirmPage);


        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        logger.info("debug: 00");
        loginPage.Login(testConf.getInvestorUserName(), testConf.getUserPwd());
        logger.info("debug: 01");
        navigationBar.InvestmentButton.click();
        logger.info("投资理财");
    }
    @AfterMethod
    public void teardown() {

    }

    /**
     *
     * mobile9环境
     *
     */

    //财富汇--ok
    @Test
    public void testCaiFuHui(){


        //点击定期
        driverHelper.sleep(5000);
        investmentPage.DingqiButton.click();

        //筛选条件：财富汇
        dingqiPage.clickCaifuhui();

        //项目详情
        projectDetailsPage.dingqiCaifuhui(20000);

        //投资
        investmentConfirmPage.confirmCaifuhui("pwd123");

        //完成
        investmentViewPage.clickCompleteButton();


    }

    //安鑫--ok
    @Test
    public void testAnXin(){

        //点击定期
        driverHelper.sleep(5000);
        investmentPage.DingqiButton.click();

        //筛选条件：安鑫
        dingqiPage.clickAnXin();

        //项目详情
        projectDetailsPage.dingqiAnXin();

        //投资
        investmentConfirmPage.confirmAnXin("pwd123");

        //完成
        investmentViewPage.clickCompleteButton();


    }
    //彩虹--ok
    @Test
    public void testCaiHong(){

        //点击定期
        driverHelper.sleep(5000);
        investmentPage.DingqiButton.click();

        //筛选条件：彩虹
        dingqiPage.clickCaiHong();

        //项目详情
        projectDetailsPage.dingqiCaiHong(20000);

        //投资
        investmentConfirmPage.confirmCaiHong("pwd123");

        //完成
        investmentViewPage.clickCompleteButton();


    }

    //安盈－安盈－票据--ok
    @Test
    public void testPiaoJu(){

        //点击定期
        driverHelper.sleep(5000);
        investmentPage.DingqiButton.click();

        //筛选条件：安盈－票据
        dingqiPage.clickDingqiPiaoJu();

        //项目详情
        projectDetailsPage.dingqiAnyingPiaoJu(20000);

        //投资
        investmentConfirmPage.confirmAnyingPiaoJu("pwd123");

        //完成
        investmentViewPage.clickCompleteButton();


    }

    //粤股交--ok
    @Test
    public void testYueGuJiao(){

        //点击定期
        driverHelper.sleep(5000);
        investmentPage.DingqiButton.click();

        //筛选条件：粤股交
        dingqiPage.clickDingqiYueGuJiao();

        //项目详情
        projectDetailsPage.dingqiYueGuJiao(20000);

        //投资
        investmentConfirmPage.confirmYueGuJiao("pwd123");

        //完成
        investmentViewPage.clickCompleteButton();


    }

    //信托理财--ok
    @Test
    public void testDingqiTrustInvestment(){

        //点击定期
        driverHelper.sleep(5000);
        logger.info("debug: 1");
        investmentPage.DingqiButton.click();
        logger.info("debug: 2");

        //筛选条件：粤股交
        logger.info("debug: 3");
        dingqiPage.clickDingqiTrustInvestment();
        logger.info("debug: 4");

        //项目详情
        projectDetailsPage.dingqiTrustInvestment(30000);

        //投资
        investmentConfirmPage.confirmTrustInvestment("pwd123");

        //完成
        investmentViewPage.clickCompleteButton();


    }

}
