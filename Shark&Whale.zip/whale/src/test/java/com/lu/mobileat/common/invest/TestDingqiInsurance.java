package com.lu.mobileat.common.invest;

import com.google.gson.JsonObject;
import com.lu.mobileafw.enumer.LuProductType;
import com.lu.mobileafw.exception.NoSuchWebElementException;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.*;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/5/5.
 *
 * 定期－－保险案例(理享＋)
 *
 */
public class TestDingqiInsurance extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private DingqiPage dingqiPage= new DingqiPage();
    private InvestInsurancePage investInsurancePage = new InvestInsurancePage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();
    private InvestmentConfirmPage investmentConfirmPage = new InvestmentConfirmPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), dingqiPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investInsurancePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentConfirmPage);


        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getInvestorUserName(), testConf.getUserPwd());
        navigationBar.clickInvestmentButton();
    }
    @AfterMethod
    public void teardown() {

    }

    //定期－－国华人寿保险－－本地跑通过
    @Test
    public void testGuoHualife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.GHRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "国华人寿6个月nus";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiGuoHualife(1000);

        //投保
        investInsurancePage.investGuoHualife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();

    }

    //定期－－阳光人寿保险－－本地跑通过
    @Test
    public void testYangGuanglife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.YGRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "阳光人寿6个月vgw";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiYangGuanglife(1000);

        //投保
        investInsurancePage.investYangGuanglife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();

    }

    //定期－－生命人寿保险－－本地跑通过
    @Test
    public void testShengMinglife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.SMRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "生命人寿6个月du6";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiShengMinglife(1000);

        //投保
        investInsurancePage.investShengMinglife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();

    }

    //定期－－天安人寿保险－－本地跑通过
    @Test
    public void testTianAnlife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.TARS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "天安人寿6个月44o";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiTianAnlife(1000);

        //投保
        investInsurancePage.investTianAnlife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();

    }

    //定期－－平安人寿保险－－本地跑通过
    @Test
    public void testPingAnlife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.PARS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "平安人寿6个月41f";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiPingAnlife(1000);

        //投保
        investInsurancePage.investPingAnlife("pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();

    }

    //定期－－渤海人寿保险--本地无产品
    @Test
    public void testBoHailife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期;
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.BHRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "渤海人寿6个月q18";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiBoHailife(1000);

        //投保
        investInsurancePage.investBoHailife("pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();

    }

    //定期－－信泰人寿保险－－本地跑通过
    @Test
    public void testXinTailife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.XTRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "信泰人寿6个月xfc";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiXinTailife(1000);

        //投保
        investInsurancePage.investXinTailife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();

    }

    //定期－－君康人寿保险－－本地跑通过
    @Test
    public void testJunKanglife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.JKRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "君康人寿6个月mhv";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiJunKanglife(1000);

        //投保
        investInsurancePage.investJunKanglife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();

    }

    //定期－－恒大人寿保险－－本地跑通过
    @Test
    public void testHengDalife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.HDRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "恒大人寿6个月cn1";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiHengDalife(1000);

        //投保
        investInsurancePage.investHengDalife("pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();

    }

    //定期－－百年人寿保险
    @Test
    public void testBaiNianlife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.BNRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "百年人寿6个月lm2";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiBaiNianlife(1000);

        //投保
        investInsurancePage.investBaiNianlife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();
        testAssert.assertTrue(investmentViewPage.CompleteButton.isDisplayed(), "投保完成按钮显示在页面上");

        //完成
        investmentViewPage.clickCompleteButton();
        //testLogger.info("[screen] 购买成功");

    }

    //定期－－新珠江人寿保险－－产品信息审核不通过
    @Test
    public void testZhuJianglife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.XZJRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "新珠江人寿6个月017";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiZhuJianglife(1000);

        //投保
        investInsurancePage.investZhuJianglife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();
    }

    //定期－－中融人寿保险－－本地跑通过
    @Test
    public void testZhongRonglife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.ZRRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "中融人寿6个月gkq";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiZhongRonglife(1000);

        //投保
        investInsurancePage.investZhongRonglife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();
    }

    //定期－－前海人寿保险－－本地跑通过
    @Test
    public void testQianHailife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.QHRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "前海人寿6个月rs4";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiQianHailife(1000);

        //投保
        investInsurancePage.investQianHailife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();

    }

    //定期－－华夏人寿保险－－本地跑通过
    @Test
    public void testHuaXialife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.HXRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "华夏人寿6个月miy";
        testAssert.info("[screen] 产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiHuaXialife(1000);

        //投保
        investInsurancePage.investHuaXialife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();

        //完成
        investmentViewPage.clickCompleteButton();

    }

    //定期－－合众人寿保险
    @Test
    public void testHeZhonglife() throws NoSuchWebElementException {

        testLogger.info("[screen] 切换到投资理财页面");

        //点击定期
        investmentPage.selectDingqi();
        checkDingqiTitle();

        //按产品名字精确查找
        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.HZRS);
        String productName = ghrs.get("displayName").getAsString();
        //String productName = "合众人寿6个月cue";
        testAssert.info("产品名称：" + productName);
        dingqiPage.clickInsuranceProduct(productName);

        //项目详情
        projectDetailsPage.dingqiHeZhonglife(1000);

        //投保
        investInsurancePage.investHeZhonglife("上海市黄浦区永新广场陆金所十楼", "pwd123");
        checkInvestmentViewPage();
        testAssert.assertTrue(investmentViewPage.CompleteButton.isDisplayed(), "投保完成按钮显示在页面上");

        //完成
        investmentViewPage.clickCompleteButton();
        //testLogger.info("[screen] 购买成功");

    }

//    //定期－－富盈人寿保险－－本地未找到
//    @Test
//    public void testFuYinglife() throws NoSuchWebElementException {

//        testLogger.info("[screen] 切换到投资理财页面");
//
//        //点击定期
//        investmentPage.selectDingqi();
//        checkDingqiTitle();
//
//        //按产品名字精确查找
//        JsonObject ghrs = testBeEnv.getProuductName(LuProductType.FYRS);
//        String productName = ghrs.get("displayName").getAsString();
//        //String productName = "富盈人寿";
//        testAssert.info("[screen] 产品名称：" + productName);
//        dingqiPage.clickInsuranceProduct(productName);
//
//        //项目详情
//        projectDetailsPage.dingqiFuYinglife(20000);
//
//        //投资
//        investmentConfirmPage.confirmFuYingLife("pwd123");
//        checkInvestmentViewPage();
//
//        //完成
//        investmentViewPage.clickCompleteButton();
//    }

    public void checkInvestmentViewPage() {

        // 检查标题
        boolean prompttitle = investmentViewPage.PromptTitle.isDisplayed();
        testAssert.assertTrue(prompttitle, "[screen] 检查页面标题");
        testLogger.info("提示标题是否存在?" + prompttitle);
        testLogger.info("当前是" + investmentViewPage.PromptTitle.getText() + "页面");

        //检查投资申请已提交文字是否存在
        String investmentview = investmentViewPage.InvestmentTBView.getText();
        testAssert.assertNotNull(investmentview, "检查投资申请已提交信息");
        testLogger.info("投资申请已提交文字是否存在?" + investmentview);

    }

    //检查定期标题
    public void checkDingqiTitle(){

        //先检查标题是否存在
        boolean dingqititle = dingqiPage.DingqiTitle.isDisplayed();
        testAssert.assertTrue(dingqititle, "[screen] 检查页面标题");
        testLogger.info("定期标题是否存在?" + dingqititle);
        testLogger.info("当前是" + dingqiPage.DingqiTitle.getText() + "页面");

    }


}
