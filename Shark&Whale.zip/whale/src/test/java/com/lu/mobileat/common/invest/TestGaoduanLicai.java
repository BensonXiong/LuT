package com.lu.mobileat.common.invest;

import com.lu.mobileainfra.be.LuTestBeEnv;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.*;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/5/17.
 *
 * 高端理财
 *
 */
public class TestGaoduanLicai extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private InvestmentConfirmPage investmentConfirmPage = new InvestmentConfirmPage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();
    private GaoduanLicaiPage gaoduanLicaiPage = new GaoduanLicaiPage();
    private TrustDirectPage trustDirectPage = new TrustDirectPage();
    private FixedIncomePage fixedIncomePage = new FixedIncomePage();
    private FloatingProfitPage floatingProfitPage = new FloatingProfitPage();
    private LuTestBeEnv luTestBeEnv =  new LuTestBeEnv();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentConfirmPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), gaoduanLicaiPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), trustDirectPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), fixedIncomePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), floatingProfitPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), luTestBeEnv);




        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login("chenjie003", testConf.getUserPwd());
        navigationBar.InvestmentButton.click();
    }
    @AfterMethod
    public void teardown() {

    }

    /**
     *
     * mobile9环境，账户chenjie005
     *
     */

    //高端理财－－信托直营--ok
    @Test
    public void testGaoduanLicaiTrustDirect(){
        //点击高端理财
        investmentPage.clickGaoduanlicaiButton();

        //点击信托
        gaoduanLicaiPage.clickTrustButton();

        //信托直营
        trustDirectPage.clickTrustFirstProduct();

        //项目详情
        projectDetailsPage.TrustDirect(10000);

        //投资
        investmentConfirmPage.confirmInvestTrustDirect("pwd123");

        //提交申请
        investmentViewPage.clickCompleteButton();

    }

    //高端理财－－私募基金--固定收益类--ok
    @Test
    public void testGaoduanLicaiFixedIncome(){

        //点击高端理财
        investmentPage.clickGaoduanlicaiButton();

        //点击私募
        gaoduanLicaiPage.clickPrivateplacementButton();

        //固定收益类
        fixedIncomePage.clickFixedIncomeFiveProduct();

        //项目详情
        projectDetailsPage.FixedIncome(2000000);

        //投资
        investmentConfirmPage.confirmInvestFixedIncome("pwd123", luTestBeEnv);

        //提交申请
        investmentViewPage.clickCompleteButton();

    }

    //高端理财－－私募基金--浮动收益类--ok
    @Test
    public void testGaoduanLicaiFloatingProfit(){

        //点击高端理财
        investmentPage.clickGaoduanlicaiButton();

        //点击私募
        gaoduanLicaiPage.clickPrivateplacementButton();

        //浮动收益类
        floatingProfitPage.clickFloatingProfitFirstProduct();

        //项目详情
        projectDetailsPage.FloatingProfit(100000);

        //投资
        investmentConfirmPage.confirmInvestFloatingProfit("pwd123", luTestBeEnv);

        //提交申请
        investmentViewPage.clickCompleteButton();

    }

}
