package com.lu.mobileat.common.invest;

import com.lu.mobileafw.exception.NoSuchWebElementException;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.*;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/4/28.
 *
 * 活期
 *
 */
public class TestHuoqi extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private HuoqiPage huoqiPage = new HuoqiPage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentConfirmPage investmentConfirmPage = new InvestmentConfirmPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();
    private DingqiInvestPlanPage dingqiInvestPlanPage = new DingqiInvestPlanPage();
    private PlanDetailsPage planDetailsPage = new PlanDetailsPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), huoqiPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentConfirmPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), dingqiInvestPlanPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), planDetailsPage);


        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();
        testLogger.info("[screen] 进入首页");


    }
    @AfterMethod
    public void teardown() {

    }

    //活期－零活宝
    @Test
    public void testPurchaseLinghuobao() {
        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());
        testLogger.info("[screen] 登录成功");
        navigationBar.InvestmentButton.click();
        testLogger.info("[screen] 进入投资理财页面");

        //等待数据加载
        driverHelper.checkExist(investmentPage.HuoqiNumButton);
        // 点击活期
        investmentPage.selectHuoqi();
        testLogger.info("[screen] 进入产品列表页面");

        //活期--零活宝
        huoqiPage.clickHuoqiLinghuobao();

        // 项目详情页
        projectDetailsPage.investLinghuobao(1);

        // 投资页面
        investmentConfirmPage.confirmLinghuobao("pwd123");

        // 提示页面
        investmentViewPage.clickCompleteButton();

    }

    //活期－智能宝 investOnLinghuobao
    @Test
    public void testPurchaseZhinengbao() throws InterruptedException, NoSuchWebElementException {
        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());
        testLogger.info("[screen] 登录成功");
        navigationBar.InvestmentButton.click();
        testLogger.info("[screen] 进入投资理财页面");

        //等待数据加载
        driverHelper.checkExist(investmentPage.HuoqiNumButton);
        // 点击活期
        investmentPage.selectHuoqi();
        testLogger.info("[screen] 进入产品列表页面");

//        Thread.sleep(3000);
//
//        projectDetailsPage.topSwipe();

        //活期--智能宝
        huoqiPage.clickHuoqiZhinengbao();

        // 项目详情页
        logger.info("debug projectDetailsPage");
        projectDetailsPage.investZhinengbao(500);

        // 投资页面
        investmentConfirmPage.confirmZhinengbao("pwd123");

        // 提示页面
        investmentViewPage.clickCompleteButton();

    }

    //活期－零活宝-定期投资－－制定定期投资计划
    @Test
    public void testInvestDingqiLinghuobao() {

        // 登录
        homePage.clickLoginButton();
        String newuser = testBeEnv.createTestAccount();
        loginPage.Login(newuser, testConf.getUserPwd());
        testLogger.info("[screen] 登录成功");
        navigationBar.InvestmentButton.click();
        testLogger.info("[screen] 进入投资理财页面");

        // 点击活期
        investmentPage.selectHuoqi();
        testLogger.info("[screen] 进入产品列表页面");

        //活期--零活宝
        huoqiPage.clickHuoqiLinghuobao();

        // 点击定期投资
        logger.info("debug projectDetailsPage");
        projectDetailsPage.investDingqiLinghuobao();

        //定期投资计划
        dingqiInvestPlanPage.clickDingqiInvestPlan("1", "pwd123");

    }

    //活期－零活宝-定期投资－－修改定期投资计划--ok
    @Test
    public void testModifyDingqiInvestPlan() {

        // 登录
        homePage.clickLoginButton();
        loginPage.Login("uia4", testConf.getUserPwd());
        testLogger.info("[screen] 登录成功");
        navigationBar.InvestmentButton.click();
        testLogger.info("[screen] 进入投资理财页面");

        // 点击活期
        investmentPage.selectHuoqi();
        testLogger.info("[screen] 进入产品列表页面");

        //活期--零活宝
        huoqiPage.clickHuoqiLinghuobao();

        // 点击，查看定期投资
        logger.info("debug projectDetailsPage");
        projectDetailsPage.modifyDingqiInvestPlan();

        //修改计划
        planDetailsPage.clickPlanDetails();

        //定期投资计划
        dingqiInvestPlanPage.modifyDingqiInvestPlan("2", "pwd123");

    }

    //活期－富盈宝宝--ok
    @Test
    public void testFuYingBaoBao() throws NoSuchWebElementException {

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getInvestorUserName(), testConf.getUserPwd());
        testLogger.info("[screen] 登录成功");
        navigationBar.InvestmentButton.click();
        testLogger.info("[screen] 进入投资理财页面");

        // 点击活期
        investmentPage.selectHuoqi();
        testLogger.info("[screen] 进入产品列表页面");

        //活期--富盈宝宝
        huoqiPage.clickFuyingbao();

        // 项目详情页
        projectDetailsPage.investFuyingbaobao(500);

        // 投资页面
        investmentConfirmPage.confirmFuyingbao("pwd123");

        // 提示页面
        investmentViewPage.clickCompleteButton();
    }

    //货币基金--ok
    @Test
    public void testMonetaryFund() throws NoSuchWebElementException {

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getInvestorUserName(), testConf.getUserPwd());
        testLogger.info("[screen] 登录成功");
        navigationBar.InvestmentButton.click();
        testLogger.info("[screen] 进入投资理财页面");

        // 点击活期
        investmentPage.selectHuoqi();
        testLogger.info("[screen] 进入产品列表页面");

        //活期--货币基金
        huoqiPage.clickMonetaryFund();

        // 项目详情页
        projectDetailsPage.investMonetaryFund(500);

        // 投资页面
        investmentConfirmPage.confirmMonetaryFund("pwd123");

        // 提示页面
        investmentViewPage.clickCompleteButton();

    }

}
