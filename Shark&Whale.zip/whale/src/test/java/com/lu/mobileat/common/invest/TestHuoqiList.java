package com.lu.mobileat.common.invest;

//import com.lu.mobileaui.android.AdLoginPage;
//import com.lu.mobileaui.android.AdNavigationBar;
//import com.lu.mobileaui.android.AdStartPage;
//import com.lu.mobileaui.android.home.AdHomePage;
//import com.lu.mobileaui.android.invest.*;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.HuoqiPage;
import com.lu.mobileaui.common.invest.InvestmentPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/4/27.
 */
public class TestHuoqiList extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private HuoqiPage huoqiPage = new HuoqiPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), huoqiPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());
        //投资理财
        navigationBar.InvestmentButton.click();
    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void testCheckPlate() {


        //点击活期
        investmentPage.HuoqiButton.click();


        //driver.scrollTo("零活宝");
        driverHelper.trySearchElementByScroll(huoqiPage.flexiblePoTextView, true, 10);
        huoqiPage.flexiblePoTextView.isDisplayed();
//        driver.scrollTo("智能宝");
        driverHelper.trySearchElementByScroll(huoqiPage.intellectPoTextView, true, 10);
        huoqiPage.intellectPoTextView.isDisplayed();

        driverHelper.trySearchElementByScroll(huoqiPage.fuyingPoPoTextView, true, 10);
        huoqiPage.fuyingPoPoTextView.isDisplayed();

        driverHelper.trySearchElementByScroll(huoqiPage.moneyFundTextView, true, 10);
        huoqiPage.moneyFundTextView.isDisplayed();

        //检查四个模块
//        currentListPage.checkFourPlateIsDisplayed();


    }


}
