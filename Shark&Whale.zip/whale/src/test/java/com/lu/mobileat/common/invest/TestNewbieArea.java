package com.lu.mobileat.common.invest;

import com.lu.mobileafw.exception.NoSuchWebElementException;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.*;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/5/16.
 *
 * 新手专区
 *
 */
public class TestNewbieArea extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private InvestInsurancePage investInsurancePage = new InvestInsurancePage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();
    private NewbieAreaPage newbieAreaPage = new NewbieAreaPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investInsurancePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), newbieAreaPage);



        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login("chenjie005", testConf.getUserPwd());
        navigationBar.InvestmentButton.click();
    }
    @AfterMethod
    public void teardown() {

    }

    /**
     *
     * qa7环境，账户chenjie005
     *
     */

    //新手专区－－平安人寿--有问题，需要新账户，待修改
    @Test
    public void testNewbieArea() throws NoSuchWebElementException {

        //点击新手专区
        investmentPage.clickNewbieArea();

        //点击平安人寿
        newbieAreaPage.clickNewbieAreaProduct();

        //项目详情
        projectDetailsPage.NewbieAreaPingAnlife(1000);

        //投保
        investInsurancePage.NewbieAreaPingAnlife("上海市黄埔区永新广场陆金所十楼","pwd123");

        //提交申请
        investmentViewPage.clickCompleteButton();

    }

}
