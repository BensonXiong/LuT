package com.lu.mobileat.common.invest;

import com.lu.mobileafw.exception.NoSuchWebElementException;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.*;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/4/26.
 *
 * P2P
 *
 */
public class TestP2P extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private P2PPage p2PPage = new P2PPage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentConfirmPage investmentConfirmPage = new InvestmentConfirmPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), p2PPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentConfirmPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login("chenjie005", testConf.getUserPwd());
        navigationBar.InvestmentButton.click();
    }

    @AfterMethod
    public void teardown() {

    }

    /**
     *
     * mobile9环境
     */

    //稳赢安e（901）--ok
    @Test
    public void testP2PWenYingAnYi901() throws InterruptedException, NoSuchWebElementException {

        // 点击P2P
        investmentPage.selectP2p();

        //稳盈保障类-一口价
        p2PPage.clickWenyingAnyiYikoujia();

        //项目详情
        projectDetailsPage.wenYingAnyiYiKouJia();

        //投资
        investmentConfirmPage.confirmP2PWenyingAnyi("pwd123");

        //提示
        investmentViewPage.clickCompleteButton();

    }

    //稳赢安e（保障类）--ok
    @Test
    public void testP2PWenYingAnYi() throws InterruptedException, NoSuchWebElementException {

        // 点击P2P
        investmentPage.selectP2p();

        //稳盈保障类
        p2PPage.selectWenYingProduct();

        //项目详情
        projectDetailsPage.wenYingAnyiGuarantee("35554");

        //投资
        investmentConfirmPage.confirmP2PWenying("pwd123");

        //提示
        investmentViewPage.clickCompleteButton();

    }

    //点金计划901--ok
    @Test
    public void testDianjinJihua901(){

        // 点击P2P
        investmentPage.selectP2p();

        //点金计划901
        p2PPage.clickDianjinJihua901();

        //项目详情
        projectDetailsPage.DianjinJihua901();

        //投资
        investmentConfirmPage.confirmP2PDianjinJihua901("pwd123");

        //提示
        investmentViewPage.clickCompleteButton();

    }

    //点金计划902--ok
    @Test
    public void testDianjinJihua902(){

        // 点击P2P
        investmentPage.selectP2p();

        //点金计划902
        p2PPage.clickDianjinJihua902();

        //项目详情
        projectDetailsPage.DianjinJihua902();

        //投资
        investmentConfirmPage.confirmP2PDianjinJihua902("pwd123");

        //提示
        investmentViewPage.clickCompleteButton();

    }

}
