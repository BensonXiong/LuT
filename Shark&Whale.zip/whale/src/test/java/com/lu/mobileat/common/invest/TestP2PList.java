package com.lu.mobileat.common.invest;

//import com.lu.mobileaui.android.AdLoginPage;
//import com.lu.mobileaui.android.AdNavigationBar;
//import com.lu.mobileaui.android.AdStartPage;
//import com.lu.mobileaui.android.home.AdHomePage;
//import com.lu.mobileaui.android.invest.*;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.InvestmentPage;
import com.lu.mobileaui.common.invest.P2PPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/4/27.
 */
public class TestP2PList extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private P2PPage p2pPage = new P2PPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), p2pPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());

        //投资理财
        navigationBar.InvestmentButton.click();
    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void testClick() {

        //点击p2p
        investmentPage.P2pButton.click();

        //验证标题是否存在
//        driver.scrollTo("点金计划");
        driverHelper.trySearchElementByScroll(p2pPage.titleGoldPlanTextView, true, 10);
        p2pPage.titleGoldPlanTextView.isDisplayed();

//        driver.scrollTo("稳盈-保障类");
        driverHelper.trySearchElementByScroll(p2pPage.titleWenyingTextView, true, 10);
        p2pPage.titleWenyingTextView.isDisplayed();
    }


}
