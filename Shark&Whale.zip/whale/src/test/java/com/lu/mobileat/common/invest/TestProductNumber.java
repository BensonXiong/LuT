package com.lu.mobileat.common.invest;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.*;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinpig on 16/5/3.
 *
 * 投资理财页－－产品数量检查
 *
 */
public class TestProductNumber extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private HuoqiPage huoqiPage = new HuoqiPage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentConfirmPage investmentConfirmPage = new InvestmentConfirmPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), huoqiPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentConfirmPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());
        navigationBar.InvestmentButton.click();
    }
    @AfterMethod
    public void teardown() {

    }

    //检查产品数量
    @Test
    public void testNumber() {

        logger.info("活期数量" + investmentPage.HuoqiNumButton.getText());

        logger.info("定期数量" + investmentPage.DingqiNumButton.getText());

        driverHelper.trySearchElementByScroll(investmentPage.P2PNumButton, true, 10);
        logger.info("P2P数量" + investmentPage.P2PNumButton.getText());

        driverHelper.trySearchElementByScroll(investmentPage.NewbieAreaNumButton, true, 10);
        logger.info("新手专区数量" + investmentPage.NewbieAreaNumButton.getText());

        driverHelper.trySearchElementByScroll(investmentPage.GaoduanlicaiNumButton, true, 10);
        logger.info("高端理财数量" + investmentPage.GaoduanlicaiNumButton.getText());

//        driver.scrollTo("会员交易区");
        driverHelper.trySearchElementByScroll(investmentPage.VipNumButton, true, 10);
        logger.info("会员交易区数量" + investmentPage.VipNumButton.getText());

//        driver.scrollTo("VIP专属投资项目");
        driverHelper.trySearchElementByScroll(investmentPage.VipExclusiveNumButton, true, 10);
        logger.info("VIP专属投资项目数量" + investmentPage.VipExclusiveNumButton.getText());

    }

}
