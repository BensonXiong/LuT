package com.lu.mobileat.common.invest;

import com.lu.mobileafw.exception.NoSuchWebElementException;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.*;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/5/16.
 *
 * 会员交易区
 *
 */
public class TestVIP extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private InvestmentConfirmPage investmentConfirmPage = new InvestmentConfirmPage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();
    private VIPPage vipPage = new VIPPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentConfirmPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), vipPage);



        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getInvestorUserName(), testConf.getUserPwd());
        navigationBar.InvestmentButton.click();
    }
    @AfterMethod
    public void teardown() {

    }

    /**
     *
     * mobile9环境，账户chenjie006
     *
     */

    //会员交易区--定期转让--财富汇--ok
    @Test
    public void testDingqiCaiFuHuiVIP() throws NoSuchWebElementException {

        //点击会员交易区
        investmentPage.selectVIPTradArea();

        //点击安鑫产品
        vipPage.clickDingqiAssignmentCaiFuHuiProduct();

        //项目详情
        projectDetailsPage.clickCaiFuHuiProduct();

        //投资
        investmentConfirmPage.confirmCaiFuHuiProduct("pwd123");

        //提交申请
        investmentViewPage.clickCompleteButton();

    }

    //会员交易区--定期转让--安鑫--ok
    @Test
    public void testDingqiAnXinVIP() throws NoSuchWebElementException {

        //点击会员交易区
        investmentPage.selectVIPTradArea();

        //点击安鑫产品
        vipPage.clickDingqiAssignmentAnxinProduct();

        //项目详情
        projectDetailsPage.clickAnxinProduct();

        //投资
        investmentConfirmPage.confirmAnxinProduct("pwd123");

        //提交申请
        investmentViewPage.clickCompleteButton();

    }

    //会员交易区--定期转让--彩虹--ok
    @Test
    public void testDingqiCaiHongVIP() throws NoSuchWebElementException {

        //点击会员交易区
        investmentPage.selectVIPTradArea();

        //点击安鑫产品
        vipPage.clickDingqiAssignmentCaiHongProduct();

        //项目详情
        projectDetailsPage.clickCaiHongProduct();

        //投资
        investmentConfirmPage.confirmCaiHongProduct("pwd123");

        //提交申请
        investmentViewPage.clickCompleteButton();

    }

    //会员交易区--P2P转让--ok
    @Test
    public void testP2PAssignment() throws NoSuchWebElementException {

        //点击会员交易区
        investmentPage.selectVIPTradArea();

        //筛选条件：一口价，稳盈安e
        vipPage.clickP2PAssignmentWenYingAnYi();

        //项目详情
        projectDetailsPage.clickP2PWenYingAnYi();

        //投资
        investmentConfirmPage.confirmP2PWenYingAnYi("pwd123");

        //提交申请
        investmentViewPage.clickCompleteButton();


    }

}
