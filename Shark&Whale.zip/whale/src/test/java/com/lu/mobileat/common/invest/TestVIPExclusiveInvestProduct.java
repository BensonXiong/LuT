package com.lu.mobileat.common.invest;

import com.lu.mobileafw.exception.NoSuchWebElementException;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.*;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/5/16.
 *
 * VIP专属投资项目
 *
 */
public class TestVIPExclusiveInvestProduct extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private InvestInsurancePage investInsurancePage = new InvestInsurancePage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();
    private VIPExclusiveInvestProductPage vipExclusiveInvestProductPage = new VIPExclusiveInvestProductPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investInsurancePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), vipExclusiveInvestProductPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login("chenjie005", testConf.getUserPwd());
        navigationBar.InvestmentButton.click();
    }
    @AfterMethod
    public void teardown() {

    }

    /**
     *
     * qa7环境，账户chenjie005
     *
     */

    //vip专属投资项目－－国华人寿--ok
    @Test
    public void testvipExclusiveInvestProduct() throws NoSuchWebElementException {

        //点击vip专属项目投资
        investmentPage.selectVIPExclusiveInvestProduct();

        //选择产品
        vipExclusiveInvestProductPage.clickVIPExclusiveInvestProductBtn();

        //项目详情
        projectDetailsPage.VIPGuoHualife(1000);

        //投保
        investInsurancePage.investGuoHualife("上海市黄埔区永新广场陆金所十楼", "pwd123");

        //提示页
        checkInvestmentViewPage();
        investmentViewPage.clickCompleteButton();

    }

    public void checkInvestmentViewPage() {

        // 检查标题
        boolean prompttitle = investmentViewPage.PromptTitle.isDisplayed();
        testAssert.assertTrue(prompttitle);
        logger.info("提示标题是否存在?" + prompttitle);
        logger.info("当前是" + investmentViewPage.PromptTitle.getText() + "页面");

        //检查投资申请已提交文字是否存在
        String investmentview = investmentViewPage.InvestmentTBView.getText();
        testAssert.assertNotNull(investmentview);
        logger.info("投资申请已提交文字是否存在?" + investmentview);

    }


}
