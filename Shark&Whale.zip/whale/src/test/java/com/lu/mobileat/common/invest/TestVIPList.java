package com.lu.mobileat.common.invest;

//import com.lu.mobileaui.android.AdLoginPage;
//import com.lu.mobileaui.android.AdNavigationBar;
//import com.lu.mobileaui.android.AdStartPage;
//import com.lu.mobileaui.android.home.AdHomePage;
//import com.lu.mobileaui.android.invest.*;

import com.lu.mobileafw.exception.NoSuchWebElementException;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.InvestmentPage;
import com.lu.mobileaui.common.invest.VIPPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/4/27.
 */
public class TestVIPList extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private InvestmentPage investmentPage = new InvestmentPage();
    private VIPPage vipPage = new VIPPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), vipPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());
        //投资理财
        navigationBar.InvestmentButton.click();
    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void testClickFilter() throws NoSuchWebElementException {


//        driver.scrollTo("会员交易区");
        boolean bFound = driverHelper.trySearchElementByScroll(investmentPage.VipButton,true,5);
        if (!bFound) {
            throw new NoSuchWebElementException("The DingqiGuoHualife is not found. Please check the product is on the page.");
        }
        //点击会员交易区
        investmentPage.VipButton.click();


        //点击稳赢 处理弹窗
        if (driverHelper.checkExist(vipPage.TipsEXiang)){
            vipPage.TipsEXiang.click();
        }

        //综合排序
        //点击定期（转让）
        vipPage.topFixeAssignmentTextView.click();

        //点击所有的筛选条件，未验证筛选条件的结果，只做了点击
        vipPage.clickSynthetically();
        vipPage.clickAssignmentPrice();
        vipPage.clickResidualMaturity();
        vipPage.clickFilter();

        //点击稳赢
        vipPage.topWenyinPlanTextView.click();

        //点击p2p（转让）
        vipPage.topP2PAssignmentTextView.click();

    }


}
