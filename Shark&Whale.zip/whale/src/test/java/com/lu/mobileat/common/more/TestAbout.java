package com.lu.mobileat.common.more;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.more.AboutPage;
import com.lu.mobileaui.common.more.MorePage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/4/21.
 */
public class TestAbout extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private NavigationBar navigationBar = new NavigationBar();
    private LoginPage loginPage = new LoginPage();

    private MorePage morePage = new MorePage();
    private AboutPage aboutPage = new AboutPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(),TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(),TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(),TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(),TimeUnit.SECONDS), morePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(),TimeUnit.SECONDS), aboutPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());
        navigationBar.clickMoreInfoButton();
    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void testAboutPage(){

        testLogger.info("[screen] 切换到《更多》页面");

        testLogger.info("点击按钮－关于");
        morePage.ForwardAboutButton.click();

        testLogger.info("[screen] 切换到《关于》页面");
        checkPage();
    }

    public void checkPage(){
        String title = aboutPage.Title.getText();
        testAssert.assertNotNull(title, "检查页面标题：" + title);

        String version = aboutPage.LuAppVersion.getText();
        testAssert.assertNotNull(version, "检查App版本：" + version);

        String website = aboutPage.LuAppWebsite.getText();
        testAssert.assertNotNull(website, "检查官方网站：" + website);

        String wechat = aboutPage.LuWechat.getText();
        testAssert.assertNotNull(wechat, "检查微信号：" + wechat);

        String tel = aboutPage.LuCSTel.getText();
        testAssert.assertNotNull(tel, "检查客服电话：" + tel);

        String servicetime = aboutPage.LuCSServiceTime.getText();
        testAssert.assertNotNull(servicetime, "检查人工服务时间：" + servicetime);

        String luCSWebchat = aboutPage.LuCSWebchat.getText();
        testAssert.assertNotNull(luCSWebchat, "检查微信公众号：" + luCSWebchat);
    }
}
