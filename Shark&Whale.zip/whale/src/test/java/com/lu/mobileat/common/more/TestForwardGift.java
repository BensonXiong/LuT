package com.lu.mobileat.common.more;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.more.ForwardGiftPage;
import com.lu.mobileaui.common.more.InvitationPage;
import com.lu.mobileaui.common.more.MorePage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/4/21.
 */
public class TestForwardGift extends BaseTestCase {
    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private NavigationBar navigationBar = new NavigationBar();
    private LoginPage loginPage = new LoginPage();

    private MorePage morePage = new MorePage();
    private ForwardGiftPage forwardGiftPage = new ForwardGiftPage();
    private InvitationPage invitationPage = new InvitationPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), morePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), forwardGiftPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), invitationPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());
        navigationBar.clickMoreInfoButton();
    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void TestForwardGift(){

        testLogger.info("[screen] 切换到《更多》页面");

        testLogger.info("点击按钮－天天发礼包");
        morePage.ForwardGiftButton.click();

        testLogger.info("[screen] 切换到《发礼包》页面");

        //验证标题是否正确
        String title = forwardGiftPage.Title.getText();
        testAssert.assertEquals(title, "发礼包", "检查当前页面标题");

        //验证文字是否存在
        String text = forwardGiftPage.TypeText.getText();
        testAssert.assertNotNull(text, "检查当前页面消息");

        testLogger.info("这是礼包文字:" + text);

    }
}
