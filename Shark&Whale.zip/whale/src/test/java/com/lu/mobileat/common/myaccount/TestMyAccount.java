package com.lu.mobileat.common.myaccount;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myaccount.PersonalSettingsPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by huangyinhuang on 16/4/14.
 */
public class TestMyAccount extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();
    private MyAccountPage myAccountPage = new MyAccountPage();
    private PersonalSettingsPage personalSettingsPage = new PersonalSettingsPage();

    @BeforeMethod
    public void setup() {

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myAccountPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), personalSettingsPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());

    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void testMyAccountInfo() {

        testLogger.info("[screen] 在App首页，点击导航栏中的《我的账号》按钮");
        navigationBar.clickMyAccountButton();

        testLogger.info("[screen] 切换到《我的账户》页面，跳过新手引导页");
        myAccountPage.SkipGuide();

        testLogger.info("[screen] 我的账户页面，点击资金信息隐藏按钮，隐藏资金信息");
        myAccountPage.showHideAssets();
        driverHelper.sleep(2000);
        testLogger.info("[screen] 资金信息已隐藏");


        // 获取用户信息并打印出来
        String accountName = myAccountPage.AccountNameText.getText();
        String totalAssetsText = myAccountPage.TotalAssetsText.getText();
        String totoalCashText = myAccountPage.TotoalCashText.getText();
        String availableCashText = myAccountPage.AvailableCashText.getText();

        // 检查资金已隐藏，变为******  //ios版的元素值为空  因此取消断言
//        testAssert.assertNotNull(accountName, "当前账号：" + accountName);
        testAssert.info("当前账号：" + accountName);
        testAssert.assertEquals("******", totalAssetsText, "当前资产总额显示：" + totalAssetsText);
        //ios版的元素值为空  因此取消断言
//        testAssert.assertTrue(totoalCashText.startsWith("******"), "现金管理总价值显示：" + totoalCashText);
//        testAssert.assertTrue(availableCashText.startsWith("******"), "可用余额显示：" + totoalCashText);
        testAssert.info( "现金管理总价值显示：" + totoalCashText);
        testAssert.info("可用余额显示：" + totoalCashText);


        // 资金信息显示
        testLogger.info("[screen] 点击隐藏按钮");
        myAccountPage.showHideAssets();
        driverHelper.sleep(2000);
        testLogger.info("[screen] 资金信息已显示");

        // 获取用户信息并打印出来
        accountName = myAccountPage.AccountNameText.getText();
        totalAssetsText = myAccountPage.TotalAssetsText.getText();
        totoalCashText = myAccountPage.TotoalCashText.getText();
        availableCashText = myAccountPage.AvailableCashText.getText();

        //ios版的元素值为空  因此取消断言
//        testAssert.assertNotNull(accountName, "当前账号：" + accountName);
        testAssert.info("当前账号：" + accountName);
        testLogger.info("当前资产总额 = " + totalAssetsText);

        testLogger.info("现金管理总价值= " + totoalCashText);
        testLogger.info("可用余额= " + availableCashText);

    }

    @Test
    public void testRefreshTradePwd() {

        testLogger.info("[screen] 在App首页，点击导航栏中的《我的账号》按钮");
        navigationBar.clickMyAccountButton();

        testLogger.info("[screen] 切换到《我的账户》页面，跳过新手引导页，并点击标题");
        myAccountPage.SkipGuide();

        myAccountPage.FaviconButton.click();

        testLogger.info("[screen] 进入账号详情，点击个人设置按钮，设置新交易密码");
        personalSettingsPage.modifyTradePwd("pwd123", "pwd123");

        String msg = personalSettingsPage.TradePwdModifiedBySuccessMsg.getText();
        testAssert.assertEquals(msg, "交易密码修改成功", "[screen] 检查页面上是否显示交易成功消息");

    }

    //可用投资券
    @Test
    public void testAvailableFoun(){

        testLogger.info("[screen] 在App首页，点击导航栏中的《我的账号》按钮");
        navigationBar.clickMyAccountButton();

        testLogger.info("[screen] 切换到《我的账户》页面，跳过新手引导页");
        myAccountPage.SkipGuide();

        testLogger.info("[screen] 点击可用投资券");
        myAccountPage.AvailableCouponText.click();
        driverHelper.sleep(2000);

        testLogger.info("点击已使用按钮，查看已使用的投资券");
        myAccountPage.UseButton.click();
        driverHelper.sleep(2000);

        testLogger.info("点击已失效按钮，查看已失效的投资券");
        myAccountPage.ExpiredButton.click();
        driverHelper.sleep(2000);

        testLogger.info("点击返回按钮");
        myAccountPage.Backbtn.click();

    }

    //当前资产总价值－检查我的资产
    @Test
    public void testCheckMyAssets(){

        testLogger.info("[screen] 在App首页，点击导航栏中的《我的账号》按钮");
        navigationBar.clickMyAccountButton();

        testLogger.info("[screen] 切换到《我的账户》页面，跳过新手引导页");
        myAccountPage.SkipGuide();

        //点击当前资产总价值
        testLogger.info("[screen] 点击当前资产总价值按钮");
        myAccountPage.TotalAssetsText.click();

        testLogger.info("[screen] 校验我的资产信息");

        //总资产
        String totalAssets = myAccountPage.TotalAssetsText.getText();
        testAssert.assertNotNull(totalAssets, "检查总资产：" + totalAssets);

        //可用余额
        String availableBalance = myAccountPage.AvailableBalanceText.getText();
        testAssert.assertNotNull(availableBalance, "检查可用余额：" + availableBalance);

        //委托中项目
        String delegateProject = myAccountPage.DelegateProjectText.getText();
        testAssert.assertNotNull(delegateProject, "检查委托的项目：" + delegateProject);

    }

    //我的投资项目
    @Test
    public  void testMyInvestProject(){

        testLogger.info("[screen] 在App首页，点击导航栏中的《我的账号》按钮");
        navigationBar.clickMyAccountButton();

        testLogger.info("[screen] 切换到《我的账户》页面，跳过新手引导页");
        myAccountPage.SkipGuide();

        testLogger.info("[screen] 校验我的投资项目信息");

        // 持有中
        String ongoing = myAccountPage.OngoingButton.getText();
        testAssert.assertNotNull(ongoing, "检查持有中项目：" + ongoing);

        // 申请中
        String applying = myAccountPage.ApplyingButton.getText();
        testAssert.assertNotNull(applying, "检查申请中项目：" + applying);

        // 可转让
        String transferable = myAccountPage.TransferableButton.getText();
        testAssert.assertNotNull(transferable, "检查可转让项目：" + transferable);

        // 可变现
        String cash = myAccountPage.CashButton.getText();
        testAssert.assertNotNull(cash, "检查可变现项目：" + cash);


    }

    //投资统计
    @Test
    public void testInvestCount(){

        testLogger.info("[screen] 在App首页，点击导航栏中的《我的账号》按钮");
        navigationBar.clickMyAccountButton();

        testLogger.info("[screen] 切换到《我的账户》页面，跳过新手引导页");
        myAccountPage.SkipGuide();

        //点击投资统计
        myAccountPage.InvestCountButton.click();

        //投资总额
        String investAmount = myAccountPage.InvestAmountButton.getText();
        testAssert.assertNotNull(investAmount, "检查投资总额");

        //已收款总额
        String moneyReceipt = myAccountPage.MoneyReceiptButton.getText();
        testAssert.assertNotNull(moneyReceipt, "检查已收款总额");

        //待收款总额
        String agencyReceipt = myAccountPage.AgencyReceiptButton.getText();
        testAssert.assertNotNull(agencyReceipt, "检查待收款总额");

    }

}
