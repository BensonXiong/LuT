package com.lu.mobileat.common.myaccount;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myaccount.MyAccountViewPage;
import com.lu.mobileaui.common.myaccount.RechargePage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/4/29.
 *
 * 充值案例
 *
 */
public class TestRecharge extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();
    private MyAccountPage myAccountPage = new MyAccountPage();
    private RechargePage rechargePage = new RechargePage();
    private MyAccountViewPage myAccountViewPage = new MyAccountViewPage();

    @BeforeMethod
    public void setup() {

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myAccountPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), rechargePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myAccountViewPage);


        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());

    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void testRecharge(){

        testLogger.info("[screen] 登录成功到App首页");

        testLogger.info("点击导航栏的《我的账号》按钮");
        navigationBar.clickMyAccountButton();

        testLogger.info("[screen] 切换到《我的账号》页面");

        testLogger.info("点击新手引导页");
        myAccountPage.SkipGuide();

        testLogger.info("点击充值按钮");
        rechargePage.clickRechargeButton();

        testLogger.info("[screen] 切换到充值页面，填写充值金额，输入短信验证码");
        rechargePage.ChargeAmountInput.sendKeys("1");

        //点击获取验证码按钮
        rechargePage.RefreshCodeButton.click();
        driverHelper.sleep(2000);

        //从数据库查询验证码
        String otp_code = testBeEnv.getSms();
        logger.info("短信验证码为：" + otp_code);

        //输入金额，密码点击充值按钮进行充值,从数据库拿到验证码，通过参数传进来
        rechargePage.rechargeAccount(otp_code, "pwd123");

        testLogger.info("[screen] 切换到充值页面，点击右上角完成按钮");
        myAccountViewPage.clickCompleteButton();
        testLogger.info("[screen] 充值流程完毕");

    }
}
