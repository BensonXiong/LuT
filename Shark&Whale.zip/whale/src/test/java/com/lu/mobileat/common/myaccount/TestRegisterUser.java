package com.lu.mobileat.common.myaccount;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.myaccount.InvestmentPreparationPage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myaccount.RegisterPage;
import com.lufax.laf.biz.domain.NewUserParameters;
import com.lufax.laf.core.utils.lang.StringUtils;
import com.lufax.laf.payment.app.fundapp.entity.BankCardEnum;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/4/22.
 *
 * 用户注册
 *
 */
public class TestRegisterUser extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private NavigationBar navigationBar = new NavigationBar();
    private LoginPage loginPage = new LoginPage();
    private MyAccountPage myAccountPage = new MyAccountPage();
    private RegisterPage registerPage = new RegisterPage();
    private InvestmentPreparationPage investmentPreparationPage = new InvestmentPreparationPage();


    @BeforeMethod
    public void setup() {

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(),TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(),TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(),TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(),TimeUnit.SECONDS), myAccountPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(),TimeUnit.SECONDS), registerPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(),TimeUnit.SECONDS), investmentPreparationPage);


        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

    }

    @AfterMethod
    public void teardown() {

    }


    //用户注册
    @Test
    public void TestRegisterUser() throws InterruptedException {

        testLogger.info("获取新用户账号");
        NewUserParameters newUserParameters = new NewUserParameters();

        String username = newUserParameters.getUserName();
        String loginpwd = newUserParameters.getLoginPwd();
        String mobileNo = newUserParameters.getMobileNo();

        // 登录
        testLogger.info("点击App首页登录按钮，切换到登录页面");
        homePage.clickLoginButton();

        // 注册页面，禁止截屏
        //testLogger.info("[screen] 当前为登录页面");
        testLogger.info("当前为登录页面，点击新用户注册按钮");
        loginPage.RegisterNewAccountBtn.click();

        // 注册页面，禁止截屏
        // testLogger.info("[screen] 注册页面");
        testLogger.info("切换到注册页面，填写用户名，登录密码，用户手机号码，短信验证码");

        testLogger.info("新用户用户名: " + username);
        registerPage.Textloginname.clear();
        registerPage.Textloginname.sendKeys(username);

        testLogger.info("新用户密码: " + loginpwd);
        registerPage.Textloginpwd.sendKeys(loginpwd);

        testLogger.info("新用户密码（确认）: " + loginpwd);
        registerPage.Textloginvalidator.sendKeys(loginpwd);

        testLogger.info("新用户手机号码: " + mobileNo);
        registerPage.TextmobileNo.sendKeys(mobileNo);

        // 获取验证码
        registerPage.refreshDynCodeButton();
        Thread.sleep(5000);

        String otpCode = testBeEnv.getSms(mobileNo);
        testLogger.info("输入短信验证码：" + otpCode);
        registerPage.InputTextDyncode(otpCode);

        // 注册页面，禁止截屏
//        testLogger.info("[screen] 注册页面－信息填写完毕");

        testLogger.info("点击注册按钮");
        registerPage.clickRegisterButton();
        Thread.sleep(5000);

        testLogger.info("[screen] 到达投资前准备页面");
    }


    //用户注册+实名认证
    @Test
    public void TestRegisterUserWithAuthentication() {

        testLogger.info("获取新用户账号");
        NewUserParameters newUserParameters = new NewUserParameters();

        String username = newUserParameters.getUserName();
        String loginpwd = newUserParameters.getLoginPwd();
        String mobileNo = newUserParameters.getMobileNo();
        String realname = newUserParameters.getRealName();
        String CardNo = newUserParameters.getCredentialsNo();
        //String banknumber= newUserParameters.getBankCode();
        String banknumber = BankCardEnum.ZHAOSHANG.getCardBin() + StringUtils.getRandomString("0123456789", 10);
        //banknumber = banknumber.replaceFirst("\\d{5}","623058");
        //banknumber = banknumber.replace("\\d{5}", "623058");

        // 登录
        testLogger.info("点击App首页登录按钮，切换到登录页面");
        homePage.clickLoginButton();

        // 注册页面，禁止截屏
        //testLogger.info("[screen] 当前为登录页面");
        testLogger.info("当前为登录页面，点击新用户注册按钮");
        loginPage.RegisterNewAccountBtn.click();

        // 注册页面，禁止截屏
        // testLogger.info("[screen] 注册页面");
        testLogger.info("切换到注册页面，填写用户名，登录密码，用户手机号码，短信验证码");

        testLogger.info("新用户用户名: " + username);
        registerPage.Textloginname.clear();
        registerPage.Textloginname.sendKeys(username);

        testLogger.info("新用户密码: " + loginpwd);
        registerPage.Textloginpwd.sendKeys(loginpwd);

        testLogger.info("新用户密码（确认）: " + loginpwd);
        registerPage.Textloginvalidator.sendKeys(loginpwd);

        testLogger.info("新用户手机号码: " + mobileNo);
        registerPage.TextmobileNo.sendKeys(mobileNo);

        registerPage.refreshDynCodeButton();
        driverHelper.sleep(5000);

        String otpCode = testBeEnv.getSms(mobileNo);
        testLogger.info("输入短信验证码：" + otpCode);
        registerPage.InputTextDyncode(otpCode);

        // 注册页面，禁止截屏
        //testLogger.info("[screen] 注册页面－信息填写完毕");

        testLogger.info("点击注册按钮");
        registerPage.clickRegisterButton();

        testLogger.info("到达投资前准备页面");

        //投资前准备--> 实名认证 --> 设置交易密码 --> 银行卡认证
        testLogger.info("[screen] 实名认证，用户名：" + realname + " 身份证号码：" + CardNo);
        investmentPreparationPage.investmentPreparation(realname, CardNo);

        testLogger.info("[screen] 设置交易密码");
        investmentPreparationPage.setTradPwd("pwd123");


        testLogger.info("[screen] 银行卡认证");
        if(testConf.getDevicePlatformName().equals("android")) {
            testLogger.info("banknumber  " + banknumber);
            investmentPreparationPage.realBankNo(banknumber);

            testLogger.info("[screen] 绑定银行卡页面");

            // 检查
            boolean isDisplayed;
            isDisplayed = investmentPreparationPage.StartBankAppButton.isDisplayed();
            testAssert.assertTrue(isDisplayed, "检查启动银行App按钮可用");
            isDisplayed = investmentPreparationPage.BankNameText.isDisplayed();
            testAssert.assertTrue(isDisplayed, "检查银行名称显示在UI上");
            isDisplayed = investmentPreparationPage.BankCardNumberText.isDisplayed();
            testAssert.assertTrue(isDisplayed, "检查银行卡号显示在UI上");
            testLogger.info("银行名称: " + investmentPreparationPage.BankNameText.getText());
            testLogger.info("银行卡号: " + investmentPreparationPage.BankCardNumberText.getText());

            // testBeEnv.activationBankCard(username);
        }

    }


}
