package com.lu.mobileat.common.myaccount;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myaccount.WithdrawPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by yuyongsong001 on 16/4/15.
 */
public class TestWithdraw extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();

    private MyAccountPage myaccountpage = new MyAccountPage();
    private WithdrawPage withdrawPage = new WithdrawPage();


    @BeforeMethod
    public void setup(){

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myaccountpage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), withdrawPage);


        // 跳过启动页
        startPage.swipeStartupPage();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());

    }

    @AfterMethod
    public void teardown(){

    }

    @Test
    public void testWithdraw() throws InterruptedException{

        testLogger.info("[screen] 登录成功进入App首页");

        testLogger.info("点击导航栏中的《我的账号》按钮");
        navigationBar.clickMyAccountButton();
        myaccountpage.SkipGuide();

        testLogger.info("[screen] 切换到《我的账户》页面");
        testLogger.info("点击取现按钮");
        myaccountpage.clickWithdrawButton();

        testLogger.info("[screen] 切换到《取现》页面");
        testLogger.info("输入取现金额1，并点击下一步");
        withdrawPage.fillAmount(1);
        withdrawPage.clickNextButton();

        testLogger.info("[screen] 确认详情，点击下一步");
        withdrawPage.clickNextButton();

        // 密码页面，禁止截屏
        //testLogger.info("[screen] 切换到《取现2》页面");
        testLogger.info("切换到确认页面，输入交易密码和短信动态码，确定");
        withdrawPage.fillTradePwd("pwd123");

        withdrawPage.refreshDynCode();
        String sms = testBeEnv.getSms();
        logger.info("短信动态码: " + sms);
        withdrawPage.fillDynCode(sms);

        withdrawPage.confirmWithdraw();

        // 检查
        checkWithdraw();
    }

    public void checkWithdraw() {

        // 取现成功消息
        boolean hasSuccessMessage = withdrawPage.SuccessMsgText.isDisplayed();
        testAssert.assertTrue(hasSuccessMessage, "[screen] 检查页面上显示：取现成功消息");
        logger.info("成功消息为：" + withdrawPage.SuccessMsgText.getText());
        logger.info("消息元素属性：" + withdrawPage.SuccessMsgText);

    }


}
