package com.lu.mobileat.common.myinvest;

import com.lu.mobileafw.exception.NoSuchWebElementException;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.HuoqiPage;
import com.lu.mobileaui.common.invest.InvestmentConfirmPage;
import com.lu.mobileaui.common.invest.InvestmentViewPage;
import com.lu.mobileaui.common.invest.ProjectDetailsPage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myinvest.AddZhinengbaoPage;
import com.lu.mobileaui.common.myinvest.MyInvestPage;
import com.lu.mobileaui.common.myinvest.RedemptionFundPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/5/17.
 * 继续投资 基金
 *
 */
public class TestFundInvestment extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();
    private MyAccountPage myAccountPage = new MyAccountPage();
    private MyInvestPage myInvestPage = new MyInvestPage();
    private AddZhinengbaoPage addZhinengbaoPage = new AddZhinengbaoPage();
    private HuoqiPage huoqiPage = new HuoqiPage();
    private RedemptionFundPage redemptionFundPage = new RedemptionFundPage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentConfirmPage investmentConfirmPage = new InvestmentConfirmPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myAccountPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myInvestPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), addZhinengbaoPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), huoqiPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), redemptionFundPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentConfirmPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testBeEnv.getUserNameFound(), "password001");


    }
    @AfterMethod
    public void teardown() {

    }

    //基金 －追加
    @Test
    public void testAddFund() {

        //点击导航
        navigationBar.MyAccountButton.click();
        myAccountPage.SkipGuide();

        //点击 持有中
        myAccountPage.OngoingButton.click();

        // 点击 基金
        driverHelper.trySearchElementByScroll(myInvestPage.FundButton, true, 30);
        myInvestPage.FundButton.click();

        //点击  追加投资
        addZhinengbaoPage.InvestAddButton.click();


        // 项目详情页
//        projectDetailsPage.investZhinengbao(500);
        projectDetailsPage.InvestmentAmountInputEx.clear();
        projectDetailsPage.InvestmentAmountInputEx.sendKeys("500");
        projectDetailsPage.InvestNowButtonET.click();
        if (driverHelper.checkExist(projectDetailsPage.InvestConfirmButton)){
            projectDetailsPage.InvestConfirmButton.click();
        }


        // 投资页面
        investmentConfirmPage.confirmMonetaryFund("pwd123");

        // 提示页面
        investmentViewPage.clickCompleteButton();

    }

    //基金 赎回
    @Test
    public void testRedemptionFund() throws NoSuchWebElementException {

        //点击导航
        navigationBar.MyAccountButton.click();
        myAccountPage.SkipGuide();

        //点击 持有中
        myAccountPage.OngoingButton.click();
        // 点击 基金
        boolean bFound = driverHelper.trySearchElementByScroll(myInvestPage.FundButton, true, 30);
        if (!bFound) {
            throw new NoSuchWebElementException("The WebElement is not found. Please check the product is on the page.");
        }
        myInvestPage.FundButton.click();

        //点击  赎回
        addZhinengbaoPage.RedemptionButton.click();

        //输入金额
        if (driverHelper.checkExist(redemptionFundPage.AllRedeemButton)){
            redemptionFundPage.AllRedeemButton.click();
        }else {
            redemptionFundPage.RedemptioAmountEditText.sendKeys(redemptionFundPage.RedemptioBottomAmountButton.getText());
        }
        redemptionFundPage.TpwdEditText.clear();
        redemptionFundPage.TpwdEditText.sendKeys(testConf.getUserTradePwd());

        redemptionFundPage.ConfirmButton.click();

        redemptionFundPage.CheckButton.click();



    }



}
