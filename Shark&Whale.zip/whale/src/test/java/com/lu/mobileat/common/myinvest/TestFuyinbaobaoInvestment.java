package com.lu.mobileat.common.myinvest;

import com.lu.mobileafw.exception.NoSuchWebElementException;
import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.HuoqiPage;
import com.lu.mobileaui.common.invest.InvestmentConfirmPage;
import com.lu.mobileaui.common.invest.InvestmentViewPage;
import com.lu.mobileaui.common.invest.ProjectDetailsPage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myinvest.AddZhinengbaoPage;
import com.lu.mobileaui.common.myinvest.MyInvestPage;
import com.lu.mobileaui.common.myinvest.RedemptionZhinengbaoPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/5/17.
 * 继续投资 富盈宝宝
 *
 */
public class TestFuyinbaobaoInvestment extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();
    private MyAccountPage myAccountPage = new MyAccountPage();
    private MyInvestPage myInvestPage = new MyInvestPage();
    private AddZhinengbaoPage addZhinengbaoPage = new AddZhinengbaoPage();
    private HuoqiPage huoqiPage = new HuoqiPage();
    private RedemptionZhinengbaoPage redemptionZhinengbaoPage = new RedemptionZhinengbaoPage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentConfirmPage investmentConfirmPage = new InvestmentConfirmPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myAccountPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myInvestPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), addZhinengbaoPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), huoqiPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), redemptionZhinengbaoPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentConfirmPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testBeEnv.getUserNameFuYinBaoBao(), "password001");


    }
    @AfterMethod
    public void teardown() {

    }

    //富盈宝宝 －追加
    @Test
    public void testAddFuyinbaobao() {

        //点击导航
        navigationBar.MyAccountButton.click();
        myAccountPage.SkipGuide();

        //点击 持有中
        myAccountPage.OngoingButton.click();

        // 点击 富盈宝宝
        driverHelper.trySearchElementByScroll(myInvestPage.FuyinbaobaoButton,true,30);
        myInvestPage.FuyinbaobaoButton.click();

        //点击  继续投资
        addZhinengbaoPage.InvestButton.click();


//        //活期--富盈宝宝
//        huoqiPage.clickFuyingbao();

        // 项目详情页
        logger.info("debug projectDetailsPage");
        projectDetailsPage.investFuyingbaobao(1);

        // 投资页面
        investmentConfirmPage.confirmFuyingbao(testConf.getUserTradePwd());

        // 提示页面
        investmentViewPage.clickCompleteButton();

    }

    //富盈宝宝 赎回
    @Test
    public void testRedemptionFuyinbaobao() throws NoSuchWebElementException {

        //点击导航
        navigationBar.MyAccountButton.click();
        myAccountPage.SkipGuide();

        //点击 持有中
        myAccountPage.OngoingButton.click();
        // 点击 富盈宝宝
        boolean bFound = driverHelper.trySearchElementByScroll(myInvestPage.FuyinbaobaoButton,true,30);
        if (!bFound) {
            throw new NoSuchWebElementException("The WebElement is not found. Please check the product is on the page.");
        }
        myInvestPage.FuyinbaobaoButton.click();

        //点击  赎回
        addZhinengbaoPage.RedemptionButton.click();


        // 点击全部赎回
        if(driverHelper.checkExist(redemptionZhinengbaoPage.AllRedeemButton)){
            redemptionZhinengbaoPage.AllRedeemButton.click();
        }else {
            //输入金额
            redemptionZhinengbaoPage.RedemptioAmountButton.clear();
            redemptionZhinengbaoPage.RedemptioAmountButton.sendKeys("1");
        }

        redemptionZhinengbaoPage.TpwdButton.clear();
        redemptionZhinengbaoPage.TpwdButton.sendKeys(testConf.getUserTradePwd());

        redemptionZhinengbaoPage.ConfirmButton.click();

        redemptionZhinengbaoPage.SuccessView.isDisplayed();



    }



}
