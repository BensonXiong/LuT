package com.lu.mobileat.common.myinvest;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.HuoqiPage;
import com.lu.mobileaui.common.invest.InvestmentConfirmPage;
import com.lu.mobileaui.common.invest.InvestmentViewPage;
import com.lu.mobileaui.common.invest.ProjectDetailsPage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myinvest.AddLinghuobaoPage;
import com.lu.mobileaui.common.myinvest.MyInvestPage;
import com.lu.mobileaui.common.myinvest.RedemptionLinghuobaoPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/5/17.
 * 继续投资 灵活宝
 *
 */
public class TestLinghuobaoInvestment extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();
    private MyAccountPage myAccountPage = new MyAccountPage();
    private MyInvestPage myInvestPage = new MyInvestPage();
    private AddLinghuobaoPage addLinghuobaoPage = new AddLinghuobaoPage();
    private HuoqiPage huoqiPage = new HuoqiPage();
    private RedemptionLinghuobaoPage redemptionLinghuobaoPage = new RedemptionLinghuobaoPage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentConfirmPage investmentConfirmPage = new InvestmentConfirmPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myAccountPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myInvestPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), addLinghuobaoPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), huoqiPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), redemptionLinghuobaoPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentConfirmPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testBeEnv.getUserNameLingHuoBao(), "password001");


    }
    @AfterMethod
    public void teardown() {

    }

    //零活宝 －追加
    @Test
    public void testAddLinghuobao() {

        //点击导航
        navigationBar.MyAccountButton.click();
        myAccountPage.SkipGuide();

        //点击 持有中
        myAccountPage.OngoingButton.click();
        // 点击 灵活宝
        driverHelper.trySearchElementByScroll( myInvestPage.LinghuobaoButton,true,5);
        myInvestPage.LinghuobaoButton.click();
        //点击  继续投资
        addLinghuobaoPage.InvestButton.click();

        //活期--零活宝
        huoqiPage.clickHuoqiLinghuobao();

        logger.info("debug projectDetailsPage");
        // 项目详情页
        projectDetailsPage.investLinghuobao(1);

        // 投资页面
        investmentConfirmPage.confirmLinghuobao("pwd123");

        // 提示页面d
        investmentViewPage.clickCompleteButton();

    }

    //零活宝 赎回
    @Test
    public void testRedemptionLinghuobao() {

        //点击导航
        navigationBar.MyAccountButton.click();
        myAccountPage.SkipGuide();

        //点击 持有中
        myAccountPage.OngoingButton.click();
        // 点击 灵活宝
        driverHelper.trySearchElementByScroll(myInvestPage.LinghuobaoButton, true, 5);
        myInvestPage.LinghuobaoButton.click();
        //点击  赎回
        addLinghuobaoPage.RedemptionButton.click();

        //输入金额
        redemptionLinghuobaoPage.RedemptioAmountButton.clear();
        redemptionLinghuobaoPage.RedemptioAmountButton.sendKeys("1");


        redemptionLinghuobaoPage.TpwdButton.clear();
        redemptionLinghuobaoPage.TpwdButton.sendKeys(testConf.getUserTradePwd());

        redemptionLinghuobaoPage.ConfirmButton.click();

        redemptionLinghuobaoPage.SuccessView.isDisplayed();
        redemptionLinghuobaoPage.CheckButton.click();



    }



}
