package com.lu.mobileat.common.myinvest;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.invest.HuoqiPage;
import com.lu.mobileaui.common.invest.InvestmentConfirmPage;
import com.lu.mobileaui.common.invest.InvestmentViewPage;
import com.lu.mobileaui.common.invest.ProjectDetailsPage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myinvest.AddZhinengbaoPage;
import com.lu.mobileaui.common.myinvest.MyInvestPage;
import com.lu.mobileaui.common.myinvest.RedemptionFundPage;
import com.lu.mobileaui.common.myinvest.TransferPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/5/23.
 * 转让
 *
 */
public class TestTransfer extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();
    private MyAccountPage myAccountPage = new MyAccountPage();
    private MyInvestPage myInvestPage = new MyInvestPage();
    private AddZhinengbaoPage addZhinengbaoPage = new AddZhinengbaoPage();
    private HuoqiPage huoqiPage = new HuoqiPage();
    private RedemptionFundPage redemptionFundPage = new RedemptionFundPage();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InvestmentConfirmPage investmentConfirmPage = new InvestmentConfirmPage();
    private InvestmentViewPage investmentViewPage = new InvestmentViewPage();
    private TransferPage transferPage = new TransferPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myAccountPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myInvestPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), addZhinengbaoPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), huoqiPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), redemptionFundPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), projectDetailsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentConfirmPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentViewPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), transferPage);


        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();




    }
    @AfterMethod
    public void teardown() {

    }

    //彩虹  转让
    @Test
    public void testTransferCaihong() {
        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testBeEnv.getUserNameCaiHongTransfer(), "password001");

        //点击导航
        navigationBar.MyAccountButton.click();
        myAccountPage.SkipGuide();

        //点击 转让
        myAccountPage.TransferableButton.click();

        // 点击 彩虹
        transferPage.CaihongButton.click();

        //点击
        transferPage.transfer(testConf.getUserTradePwd());

        logger.info("彩虹  转让");


    }

    //安鑫  转让
    @Test
    public void testTransferAnxin() {

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testBeEnv.getUserNameAnXinTransfer(), "password001");

        //点击导航
        navigationBar.MyAccountButton.click();
        myAccountPage.SkipGuide();

        //点击 转让
        myAccountPage.TransferableButton.click();

        // 点击 安鑫
        transferPage.AnXinButton.click();

        //点击
        transferPage.transfer(testConf.getUserTradePwd());

        logger.info("安鑫   转让");


    }


    //财富汇  转让
    @Test
    public void testTransferCaifuhui() {

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testBeEnv.getUserNameCaiHuHuiTransfer(), "password001");

        //点击导航
        navigationBar.MyAccountButton.click();
        myAccountPage.SkipGuide();

        //点击 转让
        myAccountPage.TransferableButton.click();

        // 点击 财富汇
        transferPage.CaiFuHuiButton.click();


        //点击
        transferPage.transferCaiFuHui(testConf.getUserTradePwd());

        logger.info("财富汇  转让");


    }





}