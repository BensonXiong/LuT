package com.lu.mobileat.common.vip;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.vip.AuctionPage;
import com.lu.mobileaui.common.vip.ProductListPage;
import com.lu.mobileaui.common.vip.VipClubPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/5/16.
 *
 * 竞拍
 *
 */
public class TestAuction extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();


    private VipClubPage vipClubPage = new VipClubPage();
    private ProductListPage productListPage = new ProductListPage();
    private AuctionPage auctionPage = new AuctionPage();



    @BeforeMethod
    public void setup(){

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), vipClubPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), productListPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), auctionPage);


        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());

        //点击 会员俱乐部
        navigationBar.VipClubButton.click();
    }

    @AfterMethod
    public void teardown(){

    }


    /**
     *竞拍
     * @throws InterruptedException
     */
    @Test
    public void testAuction() throws InterruptedException {

        //兑换刮刮乐竞拍
//        driverHelper.trySearchElementByScroll(vipClubPage.MoreButton, true, 20);

        driver.scrollTo("查看更多兑换商品");
        vipClubPage.MoreButton.click();

        int x = productListPage.TitleButton.getLocation().getX();
        int y = productListPage.TitleButton.getLocation().getY();
        int w = productListPage.TitleButton.getSize().getWidth();
        int h = productListPage.TitleButton.getSize().getHeight();

        //点击竞拍
        driver.tap(1, x + w / 6 * 5 , y + h / 2, 100);
        productListPage.TitleButton.isDisplayed();

        //产品列表－－竞拍－－第一个产品
        productListPage.NowPriceButton.click();

        //竞拍
        auctionPage.PriceEdit.clear();
        auctionPage.PriceEdit.sendKeys("110");
        auctionPage.PriceButton.click();



    }
}
