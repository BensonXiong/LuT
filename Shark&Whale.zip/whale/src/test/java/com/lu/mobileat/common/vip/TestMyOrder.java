package com.lu.mobileat.common.vip;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.vip.MyOrderPage;
import com.lu.mobileaui.common.vip.VipClubPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/5/13.
 *
 * 我的订单
 *
 */
public class TestMyOrder extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();


    private VipClubPage vipClubPage = new VipClubPage();
    private MyOrderPage myOrderPage = new MyOrderPage();



    @BeforeMethod
    public void setup(){

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), vipClubPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myOrderPage);


        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());

        //点击 会员俱乐部
        navigationBar.VipClubButton.click();
    }

    @AfterMethod
    public void teardown(){

    }

    /**
     * 我的订单
     * @throws InterruptedException
     */
    @Test
    public void testMyOrder() throws InterruptedException{
        //点击我的订单
        vipClubPage.MyOrderButton.click();

        //点击筛选条件
        myOrderPage.ProjectNameButton.click();
        myOrderPage.PickConfirmButton.click();

        //点击筛选条件
        myOrderPage.ProjectStatusButton.click();
        myOrderPage.PickConfirmButton.click();

    }

}
