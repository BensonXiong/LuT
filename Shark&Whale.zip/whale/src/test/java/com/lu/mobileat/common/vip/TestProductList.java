package com.lu.mobileat.common.vip;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.vip.ProductListPage;
import com.lu.mobileaui.common.vip.VipClubPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/5/16.
 * 会员俱乐部－－更多－－产品列表
 *
 */
public class TestProductList extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();


    private VipClubPage vipClubPage = new VipClubPage();
    private ProductListPage productListPage  = new ProductListPage();



    @BeforeMethod
    public void setup(){

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), vipClubPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), productListPage);


        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());

        //点击 会员俱乐部
        navigationBar.VipClubButton.click();


    }

    @AfterMethod
    public void teardown(){

    }

    /**
     * 兑换－－全部分类
     *
     */
    @Test
    public void testCategory() throws InterruptedException{
        //兑换刮刮乐竞拍
        driverHelper.trySearchElementByScroll(vipClubPage.MoreButton, false, 200);
        vipClubPage.MoreButton.click();

        int x = productListPage.TitleButton.getLocation().getX();
        int y = productListPage.TitleButton.getLocation().getY();
        int w = productListPage.TitleButton.getSize().getWidth();
        int h = productListPage.TitleButton.getSize().getHeight();

        //点击兑换
        driver.tap(1, x + w / 6, y + h / 2, 100);
        productListPage.TitleButton.isDisplayed();

        //点击不同的筛选条件
        productListPage.CategoryButton.click();
        productListPage.CategoryOneButton.click();
        productListPage.CategoryButton.click();
        productListPage.CategoryAllButton.click();

    }

    /**
     *
     * 刮刮乐－－综合排序
     * @throws InterruptedException
     */
    @Test
    public void testSort() throws InterruptedException {
        //兑换刮刮乐竞拍
        driverHelper.trySearchElementByScroll(vipClubPage.MoreButton, false, 200);
        vipClubPage.MoreButton.click();

        int x = productListPage.TitleButton.getLocation().getX();
        int y = productListPage.TitleButton.getLocation().getY();
        int w = productListPage.TitleButton.getSize().getWidth();
        int h = productListPage.TitleButton.getSize().getHeight();

        //点击刮刮乐
        driver.tap(1, x + w / 2, y + h / 2, 100);
        productListPage.TitleButton.isDisplayed();

        //点击不同的筛选条件
        productListPage.SortButton.click();
        productListPage.SortOneButton.click();
        productListPage.SortButton.click();
        productListPage.SortAllButton.click();

    }


    /**
     *竞拍－－筛选
     *
     */
    @Test
    public void testFilter() throws InterruptedException {
        //兑换刮刮乐竞拍
        driverHelper.trySearchElementByScroll(vipClubPage.MoreButton, false, 200);
        vipClubPage.MoreButton.click();

        int x = productListPage.TitleButton.getLocation().getX();
        int y = productListPage.TitleButton.getLocation().getY();
        int w = productListPage.TitleButton.getSize().getWidth();
        int h = productListPage.TitleButton.getSize().getHeight();

        //竞拍
        driver.tap(1, x + w / 6 * 5, y + h / 2, 100);
        productListPage.TitleButton.isDisplayed();

        //点击不同的筛选条件
        productListPage.FilterButton.click();
        productListPage.FilterTwoButton.click();
        productListPage.FilterCompleteButton.click();

    }

}
