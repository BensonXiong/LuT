package com.lu.mobileat.common.vip;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.vip.SiginPage;
import com.lu.mobileaui.common.vip.VipClubPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/5/12.
 *
 * 会员俱乐部－签到
 */
public class TestSigin extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();


    private VipClubPage vipClubPage = new VipClubPage();
    private SiginPage siginPage = new SiginPage();



    @BeforeMethod
    public void setup(){

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), vipClubPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), siginPage);


        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());

        //点击 会员俱乐部
        navigationBar.VipClubButton.click();
    }

    @AfterMethod
    public void teardown(){

    }

    /**
     * 会员俱乐部首页右上角的点击签到按钮
     * @throws InterruptedException
     */
    @Test
    public void testSigin() throws InterruptedException{

        //点击签到
        vipClubPage.SignInButton.click();

        //今日签到成功
        testAssert.assertTrue(siginPage.TodaySignInButton.isDisplayed());

//        //获得的金币
//        logger.info(vipClubPage.GetMoney.getText());
//        testAssert.assertEquals(vipClubPage.GetMoney.getText(),"获得[3-15]通币");
//        //签到天数
//        logger.info(vipClubPage.SigninDays.getText());


    }

    /**
     * 会员俱乐部首页左侧的点击签到按钮
     * @throws InterruptedException
     */
    @Test
    public void testLeftSigin() throws InterruptedException{

        //点击签到
        vipClubPage.LeftButton.click();

        //今日已签到
        testAssert.assertTrue(siginPage.TodaySignInOkButton.isDisplayed());

        siginPage.BackButton.click();


    }

}
