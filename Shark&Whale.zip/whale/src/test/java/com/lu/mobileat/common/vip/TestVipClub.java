package com.lu.mobileat.common.vip;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.vip.ProductListPage;
import com.lu.mobileaui.common.vip.SiginPage;
import com.lu.mobileaui.common.vip.VipClubPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by liuyinping on 16/5/12.
 *
 * 会员俱乐部首页
 */
public class TestVipClub extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private LoginPage loginPage = new LoginPage();
    private NavigationBar navigationBar = new NavigationBar();


    private VipClubPage vipClubPage = new VipClubPage();
    private SiginPage siginPage = new SiginPage();
    private ProductListPage productListPage = new ProductListPage();




    @BeforeMethod
    public void setup(){

        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), vipClubPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), siginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), productListPage);


        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

        // 登录
        homePage.clickLoginButton();
        loginPage.Login(testConf.getUserName(), testConf.getUserPwd());

        //点击 会员俱乐部
        navigationBar.VipClubButton.click();
    }

    @AfterMethod
    public void teardown(){

    }

    /**
     * 顶部 滚动
     * @throws InterruptedException
     */
    @Test
    public void testTop() throws InterruptedException{

        //点击滚动的当前
        vipClubPage.TopViewButton.click();
    }

    /**
     * 第一个按钮 兑换
     * @throws InterruptedException
     */
    @Test
    public void testOne() throws InterruptedException{

        //点击兑换
        vipClubPage.OneButton.click();
        productListPage.BackButton.click();
    }

    /**
     * 第二个按钮
     * @throws InterruptedException
     */
    @Test
    public void testTwo() throws InterruptedException{

        //点击兑换
        vipClubPage.TwoButton.click();
        productListPage.BackButton.click();
    }

    /**
     * 第三个按钮
     * @throws InterruptedException
     */
    @Test
    public void testThree() throws InterruptedException{

        //点击兑换
        vipClubPage.ThreeButton.click();
        productListPage.BackButton.click();
    }

    /**
     * 第四个按钮
     * @throws InterruptedException
     */
    @Test
    public void testFour() throws InterruptedException{

        //点击兑换
        vipClubPage.FourButton.click();
        productListPage.BackButton.click();
    }

    /**
     * 右边 拍下美好
     * @throws InterruptedException
     */
    @Test
    public void testRight() throws InterruptedException{

        //点击兑换
        vipClubPage.RightButton.click();
        productListPage.BackButton.click();
    }




}
