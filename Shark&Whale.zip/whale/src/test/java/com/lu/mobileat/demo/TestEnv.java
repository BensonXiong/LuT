package com.lu.mobileat.demo;

import com.google.gson.JsonObject;
import com.lu.mobileafw.enumer.LuProductType;
import com.lu.mobileainfra.lma.BaseTestCase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by huangyinhuang on 16/5/10.
 */
public class TestEnv extends BaseTestCase {
    Logger logger = LoggerFactory.getLogger(this.getClass().getName());


    @BeforeClass
    public void init() {
    }

    @BeforeMethod
    public void setup() {
    }

    @AfterMethod
    public void teardown() {


    }
    @Test
    public void test() {

        logger.info("fetch product list");
        HashMap productMap = testBeEnv.getProductList();

        logger.info("print product list");
        Iterator iter = productMap.entrySet().iterator();

        Integer i = 1;
        while (iter.hasNext()) {
            Map.Entry entry = (Map.Entry) iter.next();

            Object key = entry.getKey();
            JsonObject product = (JsonObject) entry.getValue();

            logger.info("");
            logger.info("[" + i + "]");
            logger.info("id=" + product.get("id").getAsString());
            logger.info("code=" + product.get("code").getAsString());
            logger.info("productCategory=" + product.get("productCategory").getAsString());
            logger.info("displayName=" + product.get("displayName").getAsString());
            logger.info("listType=" + product.get("listType").getAsString());
            logger.info("listTypeName=" + product.get("listTypeName").getAsString());

            i++;
        }

        logger.info("get a specific product - 君康人寿");
        JsonObject jkrs = testBeEnv.getProuductName(LuProductType.JKRS);
        logger.info("");
        logger.info("jkrs's info");
        logger.info("id=" + jkrs.get("id").getAsString());
        logger.info("code=" + jkrs.get("code").getAsString());
        logger.info("productCategory=" + jkrs.get("productCategory").getAsString());
        logger.info("displayName=" + jkrs.get("displayName").getAsString());
        logger.info("listType=" + jkrs.get("listType").getAsString());
        logger.info("listTypeName=" + jkrs.get("listTypeName").getAsString());

    }

}
