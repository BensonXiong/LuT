package com.lu.mobileat.demo;

import com.lufax.laf.biz.domain.NewUserParameters;
import com.lufax.laf.biz.generator.UserGenerator;
import com.lufax.laf.core.utils.lang.QaException;
import com.lufax.laf.user.app.userapp.IdentityType;
import com.lufax.laf.user.domain.User;
import org.apache.log4j.Logger;
import org.testng.annotations.Test;

/**
 * Created by huangyinhuang on 16/4/13.
 */
public class TestNewAccount {

    private Logger logger = Logger.getLogger(this.getClass().getName());

    protected UserGenerator userGenerator = new UserGenerator();

    @Test
    public void genUser() {
        User user = userGenerator.createOTUser(true, true, true, true, false, "mobiletest");
    }

    @Test
    public void test_CreateNewUser() throws QaException {
        int flag = 0;

        NewUserParameters newUserParameters = new NewUserParameters();
        //newUserParameters.setUserName("app" + StringUtils.getRandomInt1to9(4));
        newUserParameters.setUserName("mobileuitest3");
        newUserParameters.setLoginPwd("mima123");
        newUserParameters.setMobileNo("14878530020");
        switch (flag) {
            case 0:
                break;
            case 1:
                newUserParameters.setIdentityType(IdentityType.HONGKONG);
                break;
            case 2:
                newUserParameters.setIdentityType(IdentityType.MACAO);
                break;
            case 3:
                newUserParameters.setIdentityType(IdentityType.TAIWAN_PASSPORT);
                break;
            case 4:
                newUserParameters.setIdentityType(IdentityType.PASSPORT);
                break;
            default:
                break;
        }

        newUserParameters.setIsSetTradePwd(true);
        newUserParameters.setSetSaveQuestion(true);
        newUserParameters.setIdentityAuth(true);
        newUserParameters.setBindCard(true);
        User p2pUsersDto = userGenerator.generateLufaxUser(newUserParameters);

    }


    /**
     * 创建一个随机用户
     */

    @Test
    public String createRandomUser() {
        NewUserParameters newUserParameters = new NewUserParameters();

        logger.info("user name: " + newUserParameters.getUserName());
        logger.info("user password: " + newUserParameters.getLoginPwd());
        logger.info("user phoneNo: " + newUserParameters.getMobileNo());
        logger.info("user real name: " + newUserParameters.getRealName());
        logger.info("user card number: " + newUserParameters.getCardNo());
        logger.info("user bank: " + newUserParameters.getBank());
        logger.info("user bank code: " + newUserParameters.getBankCode());
        logger.info("user birthday: " + newUserParameters.getBirthday());
        logger.info("user answer: " + newUserParameters.getAnswer());
        logger.info("user credential: " + newUserParameters.getCredentialsNo());
        logger.info("user ip address: " + newUserParameters.getIpAddress());
        logger.info("user market cookie: " + newUserParameters.getMarketCookie());
        return null;
    }


    /**
     * create test accounts
     */

    @Test
    public void createTestAccount() {

        String userNamePrefix = "uia";
        String loginPwd = "mima123";
        String tradePwd = "pwd123";
        String userRealName = "测试用户";

        for(int i=0; i<1; i++) {

            String userName = String.format("%s%s", userNamePrefix, i);

            try{

                NewUserParameters newUserParas = new NewUserParameters();
                newUserParas.setUserName(userName);
                newUserParas.setLoginPwd(loginPwd);
                newUserParas.setTradePwd(tradePwd);
                newUserParas.setRealName(userRealName);
                newUserParas.setIsSetTradePwd(true);
                newUserParas.setSetSaveQuestion(true);
                newUserParas.setIdentityAuth(true);
                newUserParas.setBindCard(true);

                User p2pUsersDto = userGenerator.generateLufaxUser(newUserParas);


                logger.info(userName + " is created.");

            }
            catch(Exception e) {
                logger.info("failed to create " + userName);
            }

        }

    }

}
