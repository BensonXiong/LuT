package com.lu.mobileat.demo;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.GesturePage;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myaccount.PersonalSettingsPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by huangyinhuang on 16/5/10.
 */
public class TestSimple extends BaseTestCase {
    Logger logger = LoggerFactory.getLogger(this.getClass().getName());


    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private NavigationBar navigationBar = new NavigationBar();
    private LoginPage loginPage = new LoginPage();
    private MyAccountPage myAccountPage = new MyAccountPage();
    private GesturePage gesturePage = new GesturePage();
    private PersonalSettingsPage personalSettingsPage = new PersonalSettingsPage();

    @BeforeClass
    public void init() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myAccountPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), gesturePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), personalSettingsPage);


    }

    @BeforeMethod
    public void setup() {

        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();

    }

    @AfterMethod
    public void teardown() {


    }

    @Test
    public void test1() {

        logger.info("debug1");
        testAssert.assertFalse(false, "assert false");
        logger.info("debug2");
        testAssert.assertTrue(true, "assert true");
        logger.info("debug3");

    }

    @Test
    public void test2() {

        logger.info("debug1");
        testAssert.assertFalse(false, "[screen] assert false");
        logger.info("debug2");
        testAssert.assertTrue(true, "[screen] assert true");
        logger.info("debug3");

    }

    @Test
    public void test3() {

        logger.info("debug1");
        testAssert.assertFalse(true, "[screen] assert false");
        logger.info("debug2");
        testAssert.assertTrue(true, "[screen] assert true");
        logger.info("debug3");

    }

    @Test
    public void test4() {

        //click the login button on the home page
        //homePage.LoginButton.click();

        testLogger.info("[screen] hello,world");
        testAssert.assertTrue(true, "[screen] assert true");

    }

}
