package com.lu.mobileat.ios;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.LoginPage;
import com.lu.mobileaui.common.NavigationBar;
import com.lu.mobileaui.common.StartPage;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

import static com.lu.mobileafw.app.TestHelper.checkExist;

/**
 * Created by huangyinhuang on 16/3/31.
 */
public class TestLogin extends BaseTestCase {

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private NavigationBar navigationBar = new NavigationBar();
    private LoginPage loginPage = new LoginPage();
    private MyAccountPage myAccountPage = new MyAccountPage();

    @BeforeMethod
    public void setup() {
        PageFactory.initElements(new AppiumFieldDecorator(driver, 5, TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, 5, TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, 5, TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, 5, TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, 5, TimeUnit.SECONDS), myAccountPage);

        startPage.skipUpgradeInfo();
    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void testLogin() {

        //click the login button on the home page
        homePage.LoginButton.click();

        // login
        loginPage.Login("mobileuitest1", "mima123");

        // go to my account page
        navigationBar.MyAccountButton.click();

        // exit
        myAccountPage.LogOut();

        // check the login button
        testAssert.assertTrue(checkExist(homePage.LoginButton), "check the login button which should be displayed");

    }

}
