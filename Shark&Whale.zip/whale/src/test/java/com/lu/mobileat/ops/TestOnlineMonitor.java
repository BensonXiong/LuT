package com.lu.mobileat.ops;

import com.lu.mobileainfra.lma.BaseTestCase;
import com.lu.mobileaui.common.*;
import com.lu.mobileaui.common.home.HomePage;
import com.lu.mobileaui.common.insurance.InsurancePage;
import com.lu.mobileaui.common.invest.*;
import com.lu.mobileaui.common.myaccount.MyAccountPage;
import com.lu.mobileaui.common.myaccount.PersonalSettingsPage;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by huangyinhuang on 16/6/16.
 */
public class TestOnlineMonitor extends BaseTestCase {

    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private StartPage startPage = new StartPage();
    private HomePage homePage = new HomePage();
    private NavigationBar navigationBar = new NavigationBar();
    private LoginPage loginPage = new LoginPage();
    private MyAccountPage myAccountPage = new MyAccountPage();
    private GesturePage gesturePage = new GesturePage();
    private PersonalSettingsPage personalSettingsPage = new PersonalSettingsPage();
    private HeaderBar headerBar = new HeaderBar();
    private InvestmentPage investmentPage = new InvestmentPage();
    private HuoqiPage huoqiPage = new HuoqiPage();
    private DingqiPage dingqiPage= new DingqiPage();
    private P2PPage p2PPage = new P2PPage();
    private InvestCommonLayout investCommonLayout = new InvestCommonLayout();
    private ProjectDetailsPage projectDetailsPage = new ProjectDetailsPage();
    private InsurancePage insurancePage = new InsurancePage();


    @BeforeClass
    public void init() throws Exception {
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), startPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), homePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), loginPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), navigationBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), myAccountPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), gesturePage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), personalSettingsPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), headerBar);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investmentPage);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), investCommonLayout);
        PageFactory.initElements(new AppiumFieldDecorator(driver, testConf.getAppiumWaitTimeout(), TimeUnit.SECONDS), insurancePage);

        // 跳过启动页
        startPage.swipeStartupPage();
        startPage.skipUpgradeInfo();
        // 登录
        loginApp();
    }

    @BeforeMethod
    public void setup() {

        // 跳过启动页
//        startPage.swipeStartupPage();
//        startPage.skipUpgradeInfo();

    }

    @AfterMethod
    public void teardown() {

    }

    @Test
    public void testMyAccountInfo() throws Exception {

        // 登录
//        loginApp();

        testLogger.info("[screen] 在App首页，点击导航栏中的《我的账号》按钮");
        navigationBar.clickMyAccountButton();

        testLogger.info("[screen] 切换到《我的账户》页面，跳过新手引导页");
        myAccountPage.SkipGuide();
        testLogger.info("[screen] 当前为《我的账户》页面");
        
        // 获取用户信息并打印出来
        boolean bExist = driverHelper.checkExist(myAccountPage.AccountNameText);
        testAssert.assertTrue(bExist, "能够正常获取账号信息");
        String accountName = myAccountPage.AccountNameText.getText();
        testAssert.assertNotNull(accountName, "当前账号：" + accountName);

        bExist = driverHelper.checkExist(myAccountPage.TotalAssetsText);
        testAssert.assertTrue(bExist, "能够正常获取当前资产总额");
        String totalAssetsText = myAccountPage.TotalAssetsText.getText();
        testAssert.assertNotNull(totalAssetsText, "当前资产总额 = " + totalAssetsText);

        bExist = driverHelper.checkExist(myAccountPage.TotoalCashText);
        testAssert.assertTrue(bExist, "能够正常获取现金管理总价值");
        String totoalCashText = myAccountPage.TotoalCashText.getText();
        testAssert.assertNotNull(totoalCashText, "现金管理总价值 = " + totoalCashText);

        bExist = driverHelper.checkExist(myAccountPage.AvailableCashText);
        testAssert.assertTrue(bExist, "能够正常获取可用余额");
        String availableCashText = myAccountPage.AvailableCashText.getText();
        testAssert.assertNotNull(availableCashText, "可用余额 = " + availableCashText);

    }

    @Test
    public void testInvestment() throws Exception {

        // App首页
//        goBackToHomePage();

        testLogger.info("[screen] 在App首页，点击导航栏中的《投资理财》按钮");
        navigationBar.clickInvestmentButton();
        testLogger.info("[screen] 切换到《投资理财》页面");

        // 1 - 活期
        testLogger.info("点击活期理财产品按钮，切换到《活期》页面");
        investmentPage.selectHuoqi();

        testLogger.info("[screen] 检查活期产品列表");
        boolean displayed = investCommonLayout.ProductTitleLayout.isDisplayed();
        testAssert.assertTrue(displayed, "产品标题已显示");
        displayed = investCommonLayout.ProductListLayout.isDisplayed();
        testAssert.assertTrue(displayed, "产品列表已显示");
        List eleLHB = driver.findElementsByXPath("//android.widget.TextView[contains(@text,'零活宝')]");
        testAssert.info("零活宝的产品个数：" + eleLHB.size());
        int count = eleLHB.size();
        testAssert.assertTrue(count > 0, "零活宝的产品个数大于0");

        testLogger.info("点击后退按钮，回到《投资理财》页面");
        headerBar.clickBackButton();

        // 2 - 定期
        testLogger.info("[screen] 点击定期理财产品按钮，切换到《定期》页面");
        investmentPage.selectDingqi();

        testLogger.info("[screen] 检查定期产品列表");
        displayed = investCommonLayout.ProductTitleLayout.isDisplayed();
        testAssert.assertTrue(displayed, "产品标题已显示");
        displayed = investCommonLayout.ProductListLayout.isDisplayed();
        testAssert.assertTrue(displayed, "产品列表已显示");

        testLogger.info("点击后退按钮，回到《投资理财》页面");
        headerBar.clickBackButton();

        // 3 - P2P
        testLogger.info("[screen]点击P2P理财产品按钮, 切换到《P2P》页面");
        investmentPage.selectP2p();

        testLogger.info("[screen] 检查P2P产品列表");
        displayed = investCommonLayout.ProductTitleLayout.isDisplayed();
        testAssert.assertTrue(displayed, "产品标题已显示");
        displayed = investCommonLayout.ProductListLayout.isDisplayed();
        testAssert.assertTrue(displayed, "产品列表已显示");

        testLogger.info("点击后退按钮，回到《投资理财》页面");
        headerBar.clickBackButton();

    }

    @Test
    public void testLinghuobao() throws Exception {

        // 登录
//        loginApp();

        testLogger.info("[screen] 在App首页，点击导航栏中的《投资理财》按钮");
        navigationBar.clickInvestmentButton();
        testLogger.info("[screen] 切换到《投资理财》页面");

        testLogger.info("点击活期理财产品按钮");
        investmentPage.selectHuoqi();
        testLogger.info("[screen] 切换到《活期》页面");

        //活期--零活宝
        List<WebElement> eleLHB = driver.findElementsByXPath("//android.widget.TextView[contains(@text,'零活宝-14日聚财')]");
        testAssert.info("零活宝的产品个数：" + eleLHB.size());
        eleLHB.get(0).click();

        testLogger.info("[screen] 切换到《项目详情》页面");
        // 项目详情页
        //projectDetailsPage.investLinghuobao(1);

        headerBar.clickBackButton();
        testLogger.info("[screen] 回到《活期列表》页面");

        headerBar.clickBackButton();
        testLogger.info("[screen] 回到《投资理财》页面");

    }

    @Test
    public void testInsurance() throws Exception {

        // 登录
//        loginApp();

        testLogger.info("[screen] 在App首页，点击导航栏中的《投资理财》按钮");
        navigationBar.clickInvestmentButton();
        testLogger.info("[screen] 切换到《投资理财》页面");
        navigationBar.InsuranceButton.click();
        testLogger.info("[screen] 切换到《保险》页面");
        insurancePage.CarInsurance.click();
        testLogger.info("[screen] 切换到《平安车险》页面");
        testAssert.assertTrue(insurancePage.Title.isEnabled(), "存在页面标题《车险》");
        insurancePage.Back.click();
        testLogger.info("[screen] 切换到《保险》页面");
        insurancePage.AccidentInsurance.click();
        testLogger.info("[screen] 切换到《一年期综合意外保险》页面");
        testAssert.assertTrue(insurancePage.AccidentInsuranceTitle.isEnabled(), "存在页面标题《一年期综合意外险》");
        insurancePage.Back.click();
        testLogger.info("[screen] 切换到《保险》页面");
        navigationBar.LiCaiButton.click();
        testLogger.info("[screen] 切换到《理财》页面");





    }

    public void loginApp() throws Exception {

        // App先切换到首页
        goBackToHomePage();

        // 使用账号登录
        if (driverHelper.checkExist(homePage.LoginButton)) {
            testLogger.info("[screen] 点击登录按钮，输入用户名和密码登录");
            homePage.clickLoginButton();
            loginPage.Login(testConf.getUserName(), testConf.getUserPwd());
            startPage.skipPreInvestment();
        }

        // App当前必须是首页，已登录后，登录按钮不可见
        boolean bIsLogin = ( driverHelper.checkExist(navigationBar.HomeButton) && (!driverHelper.checkExist(homePage.LoginButton)) );
        if (bIsLogin) {
            testLogger.info("[screen] 登录成功。");
        }else {
            throw new Exception("Failed to login app");
        }

    }

    public void goBackToHomePage() throws Exception {

        // 回到App首页
        if (driverHelper.checkExist(navigationBar.HomeButton)) {

            testLogger.info("点击首页按钮，回到App首页");
            navigationBar.clickHomeButton();

        }
        else {

            // 点击App标题上的回退按钮，尝试回到首页
            int retryTimes = 3;
            int times = 0;
            while (driverHelper.checkExist(headerBar.LeftButton)) {

                testLogger.info("点击后退按钮，回到上一层页面");
                headerBar.clickBackButton();

                if (driverHelper.checkExist(headerBar.Title)) {
                    testLogger.info("[screen] 回到页面: " + headerBar.Title.getText());
                }

                if (driverHelper.checkExist(navigationBar.HomeButton)){
                    testLogger.info("点击首页按钮，回到App首页");
                    navigationBar.clickHomeButton();
                    break;
                }

                times++;
                if (times > retryTimes) {
                    break;
                }

            }

            if (times > retryTimes ) {
                throw new Exception("Failed to go back app home page.");
            }

        }

    }

}
